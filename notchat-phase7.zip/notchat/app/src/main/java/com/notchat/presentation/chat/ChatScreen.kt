package com.notchat.presentation.chat

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.text.format.Formatter
import android.view.WindowManager
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Done
import androidx.compose.material.icons.outlined.DoneAll
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.LooksOne
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcSurface
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.ChatLogic
import com.notchat.domain.MediaRules
import com.notchat.domain.ViewOnceDisplay
import com.notchat.domain.model.Attachment
import com.notchat.domain.model.ChatAppearance
import com.notchat.domain.model.ChatMessage
import com.notchat.domain.model.ConversationType
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.MessageStatus
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.util.formatClock
import com.notchat.presentation.util.formatDayHeader
import com.notchat.presentation.util.formatDuration
import com.notchat.presentation.util.openAttachment
import kotlinx.coroutines.delay

@Composable
fun ChatScreen(
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    onOpenGroupInfo: (String) -> Unit,
    vm: ChatViewModel = hiltViewModel(),
    appearanceVm: AppearanceViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val ui by vm.ui.collectAsState()
    val connected by vm.connected.collectAsState()
    val viewOnce by vm.viewOnce.collectAsState()
    val appearance by appearanceVm.appearance.collectAsState()
    var text by rememberSaveable { mutableStateOf("") }
    var viewerUrl by remember { mutableStateOf<String?>(null) }
    var showAppearance by remember { mutableStateOf(false) }
    var sendNextAsViewOnce by remember { mutableStateOf(false) }
    var micDenied by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var recordMs by remember { mutableIntStateOf(0) }
    val listState = rememberLazyListState()
    val recorder = remember { VoiceRecorder(context) }

    DisposableEffect(Unit) { onDispose { recorder.cancel() } }

    fun finishRecording(send: Boolean) {
        recording = false
        if (send) recorder.stop()?.let { vm.sendVoice(it.file, it.durationMs) } else recorder.cancel()
    }

    fun startRecording() {
        micDenied = false
        if (recorder.start()) {
            recordMs = 0
            recording = true
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else micDenied = true
    }
    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) vm.sendMedia(uri, viewOnce = sendNextAsViewOnce)
        sendNextAsViewOnce = false
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.sendMedia(uri)
    }

    LaunchedEffect(recording) {
        while (recording) {
            delay(250)
            recordMs = recorder.elapsedMs()
            if (recordMs >= MediaRules.MAX_VOICE_MS) finishRecording(send = true)
        }
    }

    val nearOldest by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            ui.messages.isNotEmpty() && last >= ui.messages.size - 5
        }
    }
    LaunchedEffect(nearOldest, ui.messages.size) {
        if (nearOldest) vm.loadOlder()
    }
    val newestKey = ui.messages.firstOrNull()?.message?.clientId
    LaunchedEffect(newestKey) {
        if (listState.firstVisibleItemIndex <= 2) listState.animateScrollToItem(0)
    }

    Box(Modifier.fillMaxSize()) {
        ChatBackgroundLayer(appearance.background)
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding(),
        ) {
            val header = ui.header
            ChatTopBar(
                name = header?.title.orEmpty(),
                avatarUrl = header?.otherAvatarUrl,
                subtitle = when {
                    !connected -> stringResource(R.string.chat_connecting)
                    header?.type == ConversationType.GROUP ->
                        stringResource(R.string.members_count, header.memberCount)
                    header?.otherUsername != null -> "@${header.otherUsername}"
                    else -> ""
                },
                onBack = onBack,
                onTitleClick = {
                    when {
                        header == null -> Unit
                        header.type == ConversationType.GROUP -> onOpenGroupInfo(vm.conversationId)
                        header.otherUsername != null -> onOpenProfile(header.otherUsername)
                    }
                },
                onAppearance = { showAppearance = true },
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NcPrimary)
                    }
                    ui.error != null && ui.messages.isEmpty() -> Column(
                        Modifier.fillMaxSize().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text(ui.error!!.message(), color = NcError, textAlign = TextAlign.Center)
                        TextButton(onClick = onBack) {
                            Text(stringResource(R.string.back), color = NcSecondary)
                        }
                    }
                    ui.messages.isEmpty() -> Box(
                        Modifier.fillMaxSize().padding(32.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            stringResource(R.string.chat_empty),
                            color = NcTextSecondary, textAlign = TextAlign.Center,
                        )
                    }
                    else -> LazyColumn(
                        state = listState,
                        reverseLayout = true,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        itemsIndexed(ui.messages, key = { _, m -> m.message.clientId }) { index, item ->
                            val older = ui.messages.getOrNull(index + 1)
                            val firstOfDay = older == null ||
                                !ChatLogic.sameDay(older.message.createdAtMillis, item.message.createdAtMillis)
                            Column(Modifier.fillMaxWidth()) {
                                if (firstOfDay) DayHeader(item.message.createdAtMillis)
                                MessageBubble(
                                    item = item,
                                    appearance = appearance,
                                    onRetry = { vm.retry(item.message.clientId) },
                                    onOpenImage = { viewerUrl = it },
                                    onOpenAttachment = { openAttachment(context, it) },
                                    onOpenViewOnce = { vm.openViewOnce(item.message.id) },
                                )
                            }
                        }
                        if (ui.loadingOlder) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(
                                        color = NcPrimary, strokeWidth = 2.dp, modifier = Modifier.size(20.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
            val notice = when {
                micDenied -> stringResource(R.string.err_mic_permission)
                ui.sendError != null -> ui.sendError!!.message()
                else -> null
            }
            notice?.let {
                Text(
                    it,
                    color = NcError, fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
            if (ui.preparingMedia) {
                Text(
                    stringResource(R.string.media_preparing),
                    color = NcTextSecondary, fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
            if (recording) {
                RecordingBar(
                    elapsedMs = recordMs,
                    onCancel = { finishRecording(send = false) },
                    onSend = { finishRecording(send = true) },
                )
            } else {
                MessageInput(
                    text = text,
                    onTextChange = { text = it.take(MAX_LENGTH) },
                    onSend = {
                        vm.send(text)
                        text = ""
                    },
                    onPickMedia = {
                        sendNextAsViewOnce = false
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    onPickViewOnce = {
                        sendNextAsViewOnce = true
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    onPickFile = { pickFile.launch(arrayOf("*/*")) },
                    onMic = {
                        val granted = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.RECORD_AUDIO,
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) startRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                )
            }
        }
    }

    if (showAppearance) AppearanceDialog(onDismiss = { showAppearance = false })

    viewerUrl?.let { url ->
        Dialog(
            onDismissRequest = { viewerUrl = null },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Box(
                Modifier.fillMaxSize().background(Color.Black).clickable { viewerUrl = null },
                contentAlignment = Alignment.Center,
            ) {
                AsyncImage(
                    model = url,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }

    if (viewOnce !is ViewOnceUi.None) {
        ViewOnceViewer(state = viewOnce, onClose = vm::closeViewOnce)
    }
}

private const val MAX_LENGTH = 4000

@Composable
private fun ChatTopBar(
    name: String,
    avatarUrl: String?,
    subtitle: String,
    onBack: () -> Unit,
    onTitleClick: () -> Unit,
    onAppearance: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcSurface)
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(
                Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = stringResource(R.string.back),
                tint = NcTextPrimary,
            )
        }
        Row(
            modifier = Modifier.weight(1f).clickable(onClick = onTitleClick),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AvatarInitial(name.ifEmpty { "?" }, size = 40.dp, imageUrl = avatarUrl)
            Column(Modifier.padding(start = 12.dp)) {
                Text(name, color = NcTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(subtitle, color = NcTextSecondary, fontSize = 12.sp, maxLines = 1)
            }
        }
        IconButton(onClick = onAppearance) {
            Icon(
                Icons.Outlined.Palette,
                contentDescription = stringResource(R.string.chat_appearance),
                tint = NcTextSecondary,
            )
        }
    }
}

@Composable
private fun DayHeader(millis: Long) {
    val context = LocalContext.current
    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
        Text(
            formatDayHeader(context, millis),
            color = NcTextSecondary, fontSize = 12.sp,
            modifier = Modifier
                .background(NcCard, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun MessageBubble(
    item: ChatMessage,
    appearance: ChatAppearance,
    onRetry: () -> Unit,
    onOpenImage: (String) -> Unit,
    onOpenAttachment: (Attachment) -> Unit,
    onOpenViewOnce: () -> Unit,
) {
    val mine = item.mine
    val failed = item.status == MessageStatus.FAILED
    val shape = appearance.shape.bubble(mine)
    val fill = if (mine) appearance.theme.brush() else SolidColor(NcCard)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(fill, shape)
                .then(if (failed) Modifier.clickable(onClick = onRetry) else Modifier)
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            item.senderName?.let {
                Text(
                    it,
                    color = NcSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 2.dp),
                )
            }
            val attachment = item.message.attachments.firstOrNull()
            when {
                item.message.deleted -> Text(
                    stringResource(R.string.message_deleted),
                    color = if (mine) Color.White.copy(alpha = 0.8f) else NcTextSecondary,
                    fontStyle = FontStyle.Italic, fontSize = 15.sp,
                )
                item.message.viewOnce -> ViewOnceBubble(item, onOpenViewOnce)
                attachment == null && item.message.kind != MessageKind.TEXT -> Text(
                    stringResource(R.string.media_unavailable),
                    color = NcTextSecondary, fontStyle = FontStyle.Italic, fontSize = 14.sp,
                )
                attachment != null && item.message.kind == MessageKind.IMAGE ->
                    ImageContent(attachment, onOpenImage)
                attachment != null && item.message.kind == MessageKind.AUDIO ->
                    AudioContent(attachment)
                attachment != null && item.message.kind == MessageKind.VIDEO ->
                    FileContent(attachment, video = true) { onOpenAttachment(attachment) }
                attachment != null ->
                    FileContent(attachment, video = false) { onOpenAttachment(attachment) }
                else -> Text(item.message.body, color = NcTextPrimary, fontSize = 16.sp)
            }
            Row(
                modifier = Modifier.align(Alignment.End).padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (failed) {
                    Text(stringResource(R.string.message_not_sent), color = Color.White, fontSize = 11.sp)
                } else if (item.message.createdAtRaw.isNotEmpty()) {
                    Text(
                        formatClock(item.message.createdAtMillis),
                        color = NcTextPrimary.copy(alpha = 0.7f), fontSize = 11.sp,
                    )
                }
                if (mine) {
                    Spacer(Modifier.size(4.dp))
                    StatusIcon(item.status)
                }
            }
        }
    }
}

/** Bubble for a photo/video that can be opened only once. The content itself is never shown here. */
@Composable
private fun ViewOnceBubble(item: ChatMessage, onOpen: () -> Unit) {
    val isVideo = item.message.kind == MessageKind.VIDEO
    val display = ChatLogic.viewOnceDisplay(item.mine, item.viewedByMe, item.viewedByOther)
    val label = stringResource(
        when (display) {
            ViewOnceDisplay.TAP_TO_VIEW ->
                if (isVideo) R.string.view_once_tap_video else R.string.view_once_tap_photo
            ViewOnceDisplay.OPENED_BY_ME -> R.string.view_once_opened
            ViewOnceDisplay.SENT_NOT_OPENED ->
                if (isVideo) R.string.view_once_sent_video else R.string.view_once_sent_photo
            ViewOnceDisplay.SENT_OPENED -> R.string.view_once_opened_by_other
        },
    )
    val opened = display == ViewOnceDisplay.OPENED_BY_ME || display == ViewOnceDisplay.SENT_OPENED
    Row(
        modifier = Modifier
            .widthIn(min = 180.dp)
            .clickable(enabled = display == ViewOnceDisplay.TAP_TO_VIEW, onClick = onOpen)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (opened) Icons.Outlined.Done else Icons.Outlined.LooksOne,
            contentDescription = null,
            tint = NcTextPrimary.copy(alpha = if (opened) 0.6f else 1f),
            modifier = Modifier.size(28.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            label,
            color = NcTextPrimary.copy(alpha = if (opened) 0.6f else 1f),
            fontStyle = if (opened) FontStyle.Italic else FontStyle.Normal,
            fontSize = 15.sp,
        )
    }
}

/**
 * Full-screen viewer for a view-once photo/video.
 * Screenshots and screen recording are blocked while it is open (FLAG_SECURE), and the
 * image is never written to the disk or memory cache.
 */
@Composable
private fun ViewOnceViewer(state: ViewOnceUi, onClose: () -> Unit) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect { window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE) }

        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            when (state) {
                ViewOnceUi.None, ViewOnceUi.Loading -> CircularProgressIndicator(color = NcPrimary)
                is ViewOnceUi.Failed -> Text(
                    state.error.message(),
                    color = NcTextPrimary, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp),
                )
                is ViewOnceUi.Ready -> {
                    val content = state.content
                    if (content.kind == MessageKind.VIDEO) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    val controller = MediaController(ctx)
                                    controller.setAnchorView(this)
                                    setMediaController(controller)
                                    setVideoURI(Uri.parse(content.url))
                                    setOnPreparedListener { start() }
                                }
                            },
                            onRelease = { it.stopPlayback() },
                        )
                    } else {
                        val ctx = LocalContext.current
                        AsyncImage(
                            model = ImageRequest.Builder(ctx)
                                .data(content.url)
                                .diskCachePolicy(CachePolicy.DISABLED)
                                .memoryCachePolicy(CachePolicy.DISABLED)
                                .build(),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }
            IconButton(
                onClick = onClose,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 32.dp, end = 8.dp),
            ) {
                Icon(
                    Icons.Outlined.Close,
                    contentDescription = stringResource(R.string.close),
                    tint = NcTextPrimary,
                )
            }
            Text(
                stringResource(R.string.view_once_hint),
                color = NcTextSecondary, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
            )
        }
    }
}

@Composable
private fun ImageContent(a: Attachment, onOpen: (String) -> Unit) {
    val ratio = if (a.width != null && a.height != null && a.height > 0) {
        (a.width.toFloat() / a.height).coerceIn(0.6f, 1.8f)
    } else {
        1f
    }
    Box(
        modifier = Modifier
            .width(240.dp)
            .aspectRatio(ratio)
            .clip(RoundedCornerShape(12.dp))
            .background(NcSurface)
            .clickable(enabled = a.url != null) { a.url?.let(onOpen) },
        contentAlignment = Alignment.Center,
    ) {
        if (a.url != null) {
            AsyncImage(
                model = a.url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            CircularProgressIndicator(color = NcTextSecondary, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun FileContent(a: Attachment, video: Boolean, onOpen: () -> Unit) {
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .widthIn(min = 200.dp)
            .clickable(enabled = a.url != null, onClick = onOpen),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (video) Icons.Outlined.PlayCircle else Icons.Outlined.InsertDriveFile,
            contentDescription = null, tint = NcTextPrimary, modifier = Modifier.size(36.dp),
        )
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                a.fileName, color = NcTextPrimary, fontSize = 15.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            val details = buildList {
                add(Formatter.formatShortFileSize(context, a.sizeBytes))
                if (video && a.durationMs != null) add(formatDuration(a.durationMs))
            }.joinToString(" · ")
            Text(details, color = NcTextPrimary.copy(alpha = 0.7f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun AudioContent(a: Attachment) {
    val context = LocalContext.current
    var playing by remember { mutableStateOf(false) }
    var prepared by remember(a.url) { mutableStateOf(false) }
    val player = remember { MediaPlayer() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    fun toggle() {
        val url = a.url ?: return
        if (!prepared) {
            try {
                player.reset()
                player.setDataSource(context, Uri.parse(url))
                player.setOnPreparedListener {
                    prepared = true
                    it.start()
                    playing = true
                }
                player.setOnCompletionListener {
                    playing = false
                    it.seekTo(0)
                }
                player.setOnErrorListener { _, _, _ ->
                    playing = false
                    prepared = false
                    true
                }
                player.prepareAsync()
            } catch (e: Exception) {
                playing = false
                prepared = false
            }
        } else if (playing) {
            player.pause()
            playing = false
        } else {
            player.start()
            playing = true
        }
    }

    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.widthIn(min = 160.dp)) {
        IconButton(onClick = { toggle() }, enabled = a.url != null) {
            Icon(
                if (playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                contentDescription = null, tint = NcTextPrimary, modifier = Modifier.size(32.dp),
            )
        }
        Text(
            formatDuration(a.durationMs ?: 0),
            color = NcTextPrimary, fontSize = 14.sp,
        )
    }
}

@Composable
private fun StatusIcon(status: MessageStatus) {
    val (icon, tint) = when (status) {
        MessageStatus.SENDING -> Icons.Outlined.Schedule to NcTextPrimary.copy(alpha = 0.7f)
        MessageStatus.FAILED -> Icons.Outlined.ErrorOutline to NcError
        MessageStatus.SENT -> Icons.Outlined.Done to NcTextPrimary.copy(alpha = 0.7f)
        MessageStatus.DELIVERED -> Icons.Outlined.DoneAll to NcTextPrimary.copy(alpha = 0.7f)
        MessageStatus.READ -> Icons.Outlined.DoneAll to NcSecondary
    }
    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
}

@Composable
private fun MessageInput(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onPickMedia: () -> Unit,
    onPickViewOnce: () -> Unit,
    onPickFile: () -> Unit,
    onMic: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcSurface)
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(
                    Icons.Outlined.AttachFile,
                    contentDescription = stringResource(R.string.attach),
                    tint = NcTextSecondary,
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.attach_photo_video)) },
                    onClick = {
                        menuOpen = false
                        onPickMedia()
                    },
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.attach_photo_video_once)) },
                    leadingIcon = { Icon(Icons.Outlined.LooksOne, contentDescription = null) },
                    onClick = {
                        menuOpen = false
                        onPickViewOnce()
                    },
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.attach_file)) },
                    onClick = {
                        menuOpen = false
                        onPickFile()
                    },
                )
            }
        }
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text(stringResource(R.string.chat_input_hint), color = NcTextSecondary) },
            maxLines = 4,
            shape = RoundedCornerShape(24.dp),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = NcTextPrimary,
                unfocusedTextColor = NcTextPrimary,
                focusedContainerColor = NcCard,
                unfocusedContainerColor = NcCard,
                cursorColor = NcPrimary,
                focusedBorderColor = NcPrimary,
                unfocusedBorderColor = NcOutline,
            ),
        )
        if (text.isBlank()) {
            IconButton(onClick = onMic) {
                Icon(
                    Icons.Outlined.Mic,
                    contentDescription = stringResource(R.string.voice_record),
                    tint = NcPrimary,
                )
            }
        } else {
            IconButton(onClick = onSend) {
                Icon(
                    Icons.AutoMirrored.Outlined.Send,
                    contentDescription = stringResource(R.string.send),
                    tint = NcPrimary,
                )
            }
        }
    }
}

@Composable
private fun RecordingBar(elapsedMs: Int, onCancel: () -> Unit, onSend: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcSurface)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onCancel) {
            Icon(
                Icons.Outlined.Delete,
                contentDescription = stringResource(R.string.cancel),
                tint = NcError,
            )
        }
        Icon(Icons.Filled.FiberManualRecord, contentDescription = null, tint = NcError, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            stringResource(R.string.voice_recording) + "  " + formatDuration(elapsedMs),
            color = NcTextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f),
        )
        IconButton(onClick = onSend) {
            Icon(
                Icons.AutoMirrored.Outlined.Send,
                contentDescription = stringResource(R.string.send),
                tint = NcPrimary,
            )
        }
    }
}

package com.notchat.data.remote

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatJsonTest {
    @Test fun parsesMessageWithMicrosecondTimestamp() {
        val o = JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"hello",
               "reply_to":null,"edited_at":null,"deleted_at":null,
               "created_at":"2026-11-07T10:00:00.123456+00:00"}""",
        )
        val m = o.toMessage()
        assertEquals("hello", m.body)
        assertEquals(1_794_045_600_123L, m.createdAtMillis)
        assertEquals("2026-11-07T10:00:00.123456+00:00", m.createdAtRaw)
        assertNull(m.replyTo)
        assertFalse(m.edited)
        assertFalse(m.deleted)
    }

    @Test fun flagsEditedAndDeleted() {
        val o = JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"",
               "reply_to":"m0","edited_at":"2026-11-07T10:01:00+00:00","deleted_at":"2026-11-07T10:02:00+00:00",
               "created_at":"2026-11-07T10:00:00+00:00"}""",
        )
        val m = o.toMessage()
        assertTrue(m.edited)
        assertTrue(m.deleted)
        assertEquals("m0", m.replyTo)
    }

    @Test fun parsesDirectConversationList() {
        val arr = JSONArray(
            """[{"conversation_id":"c1","conversation_type":"direct","title":"Sara",
                 "other_user_id":"u2","other_username":"sara_k","other_avatar_url":null,
                 "last_message_id":"m1","last_message_body":"hi","last_message_kind":"text",
                 "last_message_deleted":false,"last_message_sender_id":"u2","last_message_sender_name":"Sara",
                 "last_message_at":"2026-11-07T10:00:00.5+00:00","unread_count":3,"muted":false,"member_count":2}]""",
        )
        val c = arr.toConversations().single()
        assertEquals(com.notchat.domain.model.ConversationType.DIRECT, c.type)
        assertEquals("Sara", c.title)
        assertEquals("sara_k", c.otherUsername)
        assertEquals(3, c.unreadCount)
        assertNull(c.otherAvatarUrl)
        assertTrue(c.hasMessages)
        assertEquals(1_794_045_600_500L, c.lastMessageAtMillis)
    }

    @Test fun parsesEmptyGroupWithoutMessages() {
        val arr = JSONArray(
            """[{"conversation_id":"g1","conversation_type":"group","title":"Friends",
                 "other_user_id":null,"other_username":null,"other_avatar_url":null,
                 "last_message_id":null,"last_message_body":null,"last_message_kind":null,
                 "last_message_deleted":false,"last_message_sender_id":null,"last_message_sender_name":null,
                 "last_message_at":"2026-11-07T10:00:00+00:00","unread_count":0,"muted":false,"member_count":4}]""",
        )
        val c = arr.toConversations().single()
        assertEquals(com.notchat.domain.model.ConversationType.GROUP, c.type)
        assertEquals("Friends", c.title)
        assertEquals(4, c.memberCount)
        assertFalse(c.hasMessages)
        assertNull(c.otherUserId)
        assertNull(c.lastMessageSenderId)
    }

    @Test fun parsesHeaderAndMembers() {
        val h = JSONObject(
            """{"conversation_type":"group","title":"Friends","other_user_id":null,"other_username":null,
                "other_avatar_url":null,"member_count":3,"my_role":"admin"}""",
        ).toHeader()
        assertEquals(com.notchat.domain.model.MemberRole.ADMIN, h.myRole)
        assertEquals(3, h.memberCount)

        val members = JSONArray(
            """[{"user_id":"u1","username":"ali","display_name":"Ali","avatar_url":null,"role":"admin"},
                {"user_id":"u2","username":"sara","display_name":"Sara","avatar_url":"https://x/a.jpg","role":"member"}]""",
        ).toGroupMembers()
        assertEquals(2, members.size)
        assertEquals(com.notchat.domain.model.MemberRole.MEMBER, members[1].role)
        assertEquals("https://x/a.jpg", members[1].avatarUrl)
    }

    @Test fun parsesReceipts() {
        val r = JSONObject(
            """{"last_delivered_at":"2026-11-07T10:00:05+00:00","last_read_at":"2026-11-07T10:00:01+00:00"}""",
        ).toReceipts()
        assertEquals(1_794_045_605_000L, r.deliveredAtMillis)
        assertEquals(1_794_045_601_000L, r.readAtMillis)
    }
}

class MediaJsonTest {
    @Test fun parsesMessageWithAttachment() {
        val o = org.json.JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"","kind":"image",
               "reply_to":null,"edited_at":null,"deleted_at":null,"created_at":"2026-11-07T10:00:00+00:00",
               "message_attachments":[{"id":"a1","kind":"image","storage_path":"c1/k1/file.jpg",
               "file_name":"cat.jpg","mime_type":"image/jpeg","size_bytes":12345,"width":800,"height":600,"duration_ms":null}]}""",
        )
        val m = o.toMessage()
        org.junit.Assert.assertEquals(com.notchat.domain.model.MessageKind.IMAGE, m.kind)
        val a = m.attachments.single()
        org.junit.Assert.assertEquals("c1/k1/file.jpg", a.storagePath)
        org.junit.Assert.assertEquals(800, a.width)
        org.junit.Assert.assertNull(a.durationMs)
        org.junit.Assert.assertNull(a.url)
    }

    @Test fun textMessageWithoutKindDefaultsToText() {
        val o = org.json.JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"hi",
               "created_at":"2026-11-07T10:00:00+00:00"}""",
        )
        val m = o.toMessage()
        org.junit.Assert.assertEquals(com.notchat.domain.model.MessageKind.TEXT, m.kind)
        org.junit.Assert.assertTrue(m.attachments.isEmpty())
    }

    @Test fun parsesSignedUrlBatch() {
        val body = """[{"error":null,"path":"c1/k1/file.jpg","signedURL":"/object/sign/chat-media/c1/k1/file.jpg?token=abc"},
                       {"error":"Object not found","path":"c1/k2/file.jpg","signedURL":null}]"""
        val map = parseSignedUrls(body, "https://x.supabase.co/")
        org.junit.Assert.assertEquals(1, map.size)
        org.junit.Assert.assertEquals(
            "https://x.supabase.co/storage/v1/object/sign/chat-media/c1/k1/file.jpg?token=abc",
            map["c1/k1/file.jpg"],
        )
    }
}

class ViewOnceJsonTest {
    @Test fun parsesViewOnceAndWhoOpenedIt() {
        val m = org.json.JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"","kind":"image",
               "view_once":true,"message_views":[{"viewer_id":"u2"}],
               "created_at":"2026-11-07T10:00:00+00:00","message_attachments":[]}""",
        ).toMessage()
        org.junit.Assert.assertTrue(m.viewOnce)
        org.junit.Assert.assertEquals(setOf("u2"), m.viewedBy)
    }

    @Test fun normalMessageIsNotViewOnce() {
        val m = org.json.JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"hi",
               "created_at":"2026-11-07T10:00:00+00:00"}""",
        ).toMessage()
        org.junit.Assert.assertFalse(m.viewOnce)
        org.junit.Assert.assertTrue(m.viewedBy.isEmpty())
    }
}

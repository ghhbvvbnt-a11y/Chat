package com.notchat.data.remote

import com.notchat.domain.repository.AuthRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Supabase Realtime over a raw WebSocket (Phoenix protocol).
 * It only emits a "something changed" hint on [changes]; the app then re-fetches real data
 * through the normal REST calls, so row-level security is always enforced by the server.
 * Reconnects automatically with backoff and keeps the access token fresh.
 */
@Singleton
class RealtimeClient @Inject constructor(
    private val http: SupabaseHttp,
    private val auth: AuthRepository,
) {
    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    private val _changes = MutableSharedFlow<Unit>(
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val changes: SharedFlow<Unit> = _changes.asSharedFlow()

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    @Synchronized
    fun start() {
        if (!http.configured || job?.isActive == true) return
        job = scope.launch { loop() }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        _connected.value = false
    }

    private suspend fun loop() {
        var failures = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val token = auth.validAccessToken()
            if (token == null) {
                delay(5_000)
                continue
            }
            val joined = try {
                connectOnce(token)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                false
            }
            _connected.value = false
            failures = if (joined) 0 else minOf(failures + 1, 5)
            delay(minOf(1_000L shl failures, 30_000L))
        }
    }

    /** Suspends until the socket closes. Returns true if the channel had been joined successfully. */
    private suspend fun connectOnce(initialToken: String): Boolean = coroutineScope {
        val done = CompletableDeferred<Unit>()
        val joined = AtomicBoolean(false)
        val acked = AtomicBoolean(true)
        val refs = AtomicInteger(1)

        val ws = okHttp.newWebSocket(
            Request.Builder().url(http.realtimeUrl()).build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    webSocket.send(joinMessage(initialToken))
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    val o = try {
                        JSONObject(text)
                    } catch (e: JSONException) {
                        return
                    }
                    when (o.optString("event")) {
                        "phx_reply" -> {
                            val status = o.optJSONObject("payload")?.optString("status").orEmpty()
                            if (o.optString("ref") == JOIN_REF) {
                                if (status == "ok") {
                                    joined.set(true)
                                    _connected.value = true
                                    _changes.tryEmit(Unit) // resync after (re)connect
                                } else {
                                    webSocket.cancel()
                                }
                            } else {
                                acked.set(true)
                            }
                        }
                        "postgres_changes" -> _changes.tryEmit(Unit)
                        "phx_error", "phx_close" -> webSocket.cancel()
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(code, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    done.complete(Unit)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    done.complete(Unit)
                }
            },
        )

        val heartbeat = launch {
            var lastToken = initialToken
            while (true) {
                delay(HEARTBEAT_MS)
                if (!acked.get()) { // no reply to the previous heartbeat: connection is dead
                    ws.cancel()
                    break
                }
                acked.set(false)
                ws.send(heartbeatMessage(refs.incrementAndGet()))
                val fresh = auth.validAccessToken()
                if (fresh != null && fresh != lastToken) {
                    ws.send(accessTokenMessage(fresh))
                    lastToken = fresh
                }
            }
        }

        try {
            done.await()
        } finally {
            heartbeat.cancel()
            ws.cancel()
        }
        joined.get()
    }

    private fun postgresChange(event: String, table: String) =
        JSONObject().put("event", event).put("schema", "public").put("table", table)

    private fun joinMessage(token: String): String {
        val config = JSONObject()
            .put("broadcast", JSONObject().put("ack", false).put("self", false))
            .put("presence", JSONObject().put("key", ""))
            .put(
                "postgres_changes",
                JSONArray()
                    .put(postgresChange("INSERT", "messages"))
                    .put(postgresChange("UPDATE", "messages"))
                    .put(postgresChange("INSERT", "conversation_members"))
                    .put(postgresChange("UPDATE", "conversation_members"))
                    .put(postgresChange("INSERT", "message_views")),
            )
            .put("private", false)
        return JSONObject()
            .put("topic", TOPIC)
            .put("event", "phx_join")
            .put("ref", JOIN_REF)
            .put("join_ref", JOIN_REF)
            .put("payload", JSONObject().put("config", config).put("access_token", token))
            .toString()
    }

    private fun heartbeatMessage(ref: Int): String = JSONObject()
        .put("topic", "phoenix")
        .put("event", "heartbeat")
        .put("payload", JSONObject())
        .put("ref", ref.toString())
        .toString()

    private fun accessTokenMessage(token: String): String = JSONObject()
        .put("topic", TOPIC)
        .put("event", "access_token")
        .put("payload", JSONObject().put("access_token", token))
        .put("ref", "token")
        .toString()

    private companion object {
        const val TOPIC = "realtime:notchat-feed"
        const val JOIN_REF = "1"
        const val HEARTBEAT_MS = 25_000L
    }
}

package com.notchat.data.repository

import com.notchat.data.remote.AuthorizedApi
import com.notchat.data.remote.toProfile
import com.notchat.data.remote.toProfiles
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.UserRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val api: AuthorizedApi,
    private val auth: AuthRepository,
) : UserRepository {

    private val http get() = api.http

    private val _updates = MutableSharedFlow<Profile>(extraBufferCapacity = 1)
    override val profileUpdates: SharedFlow<Profile> = _updates.asSharedFlow()

    override suspend fun searchProfiles(query: String): Outcome<List<Profile>> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/search_profiles",
            JSONObject().put("p_query", query).put("p_limit", 20),
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(JSONArray(r.body).toProfiles()) else api.failure(r)
    }

    override suspend fun profileByUsername(username: String): Outcome<Profile?> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/get_profile_by_username",
            JSONObject().put("p_username", username),
            accessToken = token,
        )
        if (r.code in 200..299) {
            Outcome.Success(JSONArray(r.body).toProfiles().firstOrNull())
        } else {
            api.failure(r)
        }
    }

    override suspend fun updateProfile(
        displayName: String,
        bio: String,
        country: String?,
    ): Outcome<Profile> = api.call { token ->
        val fields = JSONObject()
            .put("display_name", displayName.trim())
            .put("bio", bio.trim())
            .put("country", country?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
        patchProfile(token, fields)
    }

    override suspend fun uploadAvatar(file: File): Outcome<Profile> = api.call { token ->
        val id = myId() ?: return@call Outcome.Failure(AuthError.SESSION_EXPIRED)
        val path = "$id/avatar.jpg"
        val up = http.upload("/storage/v1/object/avatars/$path", file, "image/jpeg", token)
        if (up.code !in 200..299) return@call api.failure(up)
        // "?v=" busts image caches when the photo is replaced; the database only accepts this exact shape.
        val url = "${http.publicBaseUrl().trimEnd('/')}/storage/v1/object/public/avatars/$path?v=${System.currentTimeMillis()}"
        patchProfile(token, JSONObject().put("avatar_url", url))
    }

    override suspend fun removeAvatar(): Outcome<Profile> = api.call { token ->
        val id = myId() ?: return@call Outcome.Failure(AuthError.SESSION_EXPIRED)
        val result = patchProfile(token, JSONObject().put("avatar_url", JSONObject.NULL))
        if (result is Outcome.Success) {
            // Best effort: remove the stored file too.
            http.request("DELETE", "/storage/v1/object/avatars/$id/avatar.jpg", accessToken = token)
        }
        result
    }

    private fun myId(): String? = (auth.sessionState.value as? SessionState.SignedIn)?.userId

    private suspend fun patchProfile(token: String, fields: JSONObject): Outcome<Profile> {
        val id = myId() ?: return Outcome.Failure(AuthError.SESSION_EXPIRED)
        val r = http.request(
            "PATCH",
            "/rest/v1/profiles?id=eq.$id&select=id,username,display_name,avatar_url,bio,country",
            fields,
            accessToken = token,
            headers = mapOf("Prefer" to "return=representation"),
        )
        if (r.code !in 200..299) return api.failure(r)
        val rows = JSONArray(r.body)
        if (rows.length() == 0) return Outcome.Failure(AuthError.UNKNOWN)
        val profile = rows.getJSONObject(0).toProfile()
        _updates.tryEmit(profile)
        return Outcome.Success(profile)
    }
}

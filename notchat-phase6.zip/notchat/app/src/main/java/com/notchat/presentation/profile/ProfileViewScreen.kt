package com.notchat.presentation.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.util.shareAccount

@Composable
fun ProfileViewScreen(
    onBack: () -> Unit,
    onOpenChat: (conversationId: String, username: String) -> Unit,
    vm: ProfileViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        vm.chatReady.collect { id -> onOpenChat(id, vm.ui.value.profile?.username.orEmpty()) }
    }

    Scaffold(containerColor = NcBackground) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = NcTextPrimary,
                    )
                }
            }
            val profile = ui.profile
            when {
                ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NcPrimary)
                }
                profile != null -> Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    AvatarInitial(profile.displayName, size = 96.dp, imageUrl = profile.avatarUrl)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        profile.displayName,
                        color = NcTextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    Text("@${profile.username}", color = NcSecondary, fontSize = 16.sp)
                    profile.country?.let { Text(it, color = NcTextSecondary, fontSize = 13.sp) }
                    if (profile.bio.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            profile.bio,
                            color = NcTextPrimary, fontSize = 15.sp, textAlign = TextAlign.Center,
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    GradientButton(
                        text = stringResource(R.string.profile_message),
                        loading = ui.starting,
                        onClick = vm::startChat,
                    )
                    ui.chatError?.let {
                        Text(it.message(), color = NcError, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                    TextButton(onClick = { shareAccount(context, profile.username) }) {
                        Text(stringResource(R.string.share_account), color = NcSecondary)
                    }
                }
                else -> Column(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        if (ui.notFound) stringResource(R.string.profile_not_found)
                        else ui.error?.message() ?: stringResource(R.string.profile_load_failed),
                        color = if (ui.notFound) NcTextSecondary else NcError,
                        textAlign = TextAlign.Center,
                    )
                    if (!ui.notFound) {
                        TextButton(onClick = vm::load) {
                            Text(stringResource(R.string.retry), color = NcSecondary)
                        }
                    }
                }
            }
        }
    }
}

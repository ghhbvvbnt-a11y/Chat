package com.notchat.domain.repository

import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import kotlinx.coroutines.flow.SharedFlow
import java.io.File

interface UserRepository {
    /** Emits my profile every time I change it, so other screens can refresh. */
    val profileUpdates: SharedFlow<Profile>

    /** Searches by @username or display name. Never includes the caller. */
    suspend fun searchProfiles(query: String): Outcome<List<Profile>>

    /** Success(null) when no such user exists. */
    suspend fun profileByUsername(username: String): Outcome<Profile?>

    suspend fun updateProfile(displayName: String, bio: String, country: String?): Outcome<Profile>

    /** Uploads a prepared square JPEG as my profile photo. */
    suspend fun uploadAvatar(file: File): Outcome<Profile>

    suspend fun removeAvatar(): Outcome<Profile>
}

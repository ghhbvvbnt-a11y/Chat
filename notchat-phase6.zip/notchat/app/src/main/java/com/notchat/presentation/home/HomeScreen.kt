package com.notchat.presentation.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcSurface
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.core.util.NetworkMonitor
import com.notchat.domain.model.Profile
import com.notchat.presentation.auth.message
import com.notchat.presentation.auth.messageRes
import com.notchat.presentation.chat.AppearanceDialog
import com.notchat.presentation.components.EmptyState
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.SearchBarButton
import com.notchat.presentation.util.shareAccount
import com.notchat.presentation.components.NotChatLogo

private data class Tab(val labelRes: Int, val icon: ImageVector)

private val tabs = listOf(
    Tab(R.string.tab_chats, Icons.Outlined.ChatBubbleOutline),
    Tab(R.string.tab_contacts, Icons.Outlined.People),
    Tab(R.string.tab_settings, Icons.Outlined.Settings),
)

@Composable
fun HomeScreen(
    onSignedOut: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenChat: (conversationId: String, username: String) -> Unit,
    onEditProfile: () -> Unit,
    convVm: ConversationsViewModel = hiltViewModel(),
    vm: HomeViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val monitor = remember { NetworkMonitor(context.applicationContext) }
    val online by monitor.isOnline.collectAsState(initial = true)
    val ui by vm.ui.collectAsState()
    val convUi by convVm.ui.collectAsState()
    val signedOut by vm.signedOut.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(signedOut) {
        if (signedOut) onSignedOut()
    }
    LaunchedEffect(Unit) {
        vm.errors.collect { error -> snackbar.showSnackbar(context.getString(error.messageRes())) }
    }

    Scaffold(
        containerColor = NcBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { HomeTopBar(online, ui.profile) },
        bottomBar = {
            NavigationBar(containerColor = NcSurface) {
                tabs.forEachIndexed { index, t ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(stringResource(t.labelRes)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NcPrimary,
                            selectedTextColor = NcPrimary,
                            indicatorColor = NcPrimary.copy(alpha = 0.15f),
                            unselectedIconColor = NcTextSecondary,
                            unselectedTextColor = NcTextSecondary,
                        ),
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(
                    onClick = onOpenSearch,
                    containerColor = NcPrimary,
                    contentColor = Color.White,
                ) {
                    Icon(Icons.Outlined.Edit, contentDescription = stringResource(R.string.new_chat))
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> {
                    SearchBarButton(
                        hint = stringResource(R.string.search_hint),
                        onClick = onOpenSearch,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                    ConversationsList(
                        state = convUi,
                        onOpen = onOpenChat,
                        onRetry = convVm::refresh,
                    )
                }
                1 -> EmptyState(
                    icon = Icons.Outlined.People,
                    title = stringResource(R.string.soon_title),
                    body = stringResource(R.string.soon_body),
                )
                else -> SettingsTab(
                    state = ui,
                    onRetry = vm::loadProfile,
                    onEditProfile = onEditProfile,
                    onSignOut = vm::signOut,
                    onDeleteAccount = vm::deleteAccount,
                )
            }
        }
    }
}

@Composable
private fun SettingsTab(
    state: HomeUiState,
    onRetry: () -> Unit,
    onEditProfile: () -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit,
) {
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var showAppearance by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        val profile = state.profile
        when {
            profile != null -> ProfileCard(profile, onShare = { shareAccount(context, profile.username) })
            state.loading -> Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NcPrimary)
            }
            else -> Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcCard, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    state.error?.message() ?: stringResource(R.string.profile_load_failed),
                    color = NcError, fontSize = 14.sp,
                )
                TextButton(onClick = onRetry) {
                    Text(stringResource(R.string.retry), color = NcSecondary)
                }
            }
        }

        GradientButton(
            text = stringResource(R.string.edit_profile),
            onClick = onEditProfile,
            enabled = state.profile != null,
        )
        OutlinedButton(
            onClick = { showAppearance = true },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NcOutline),
        ) {
            Text(stringResource(R.string.chat_appearance), color = NcTextPrimary)
        }
        OutlinedButton(
            onClick = onSignOut,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NcOutline),
        ) {
            Text(stringResource(R.string.sign_out), color = NcTextPrimary)
        }
        OutlinedButton(
            onClick = { confirmDelete = true },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NcError.copy(alpha = 0.5f)),
        ) {
            Text(stringResource(R.string.delete_account), color = NcError)
        }
    }

    if (showAppearance) AppearanceDialog(onDismiss = { showAppearance = false })

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            textContentColor = NcTextSecondary,
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDeleteAccount()
                }) { Text(stringResource(R.string.delete), color = NcError) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(stringResource(R.string.cancel), color = NcTextPrimary)
                }
            },
        )
    }
}

@Composable
private fun ProfileCard(profile: Profile, onShare: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcCard, RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AvatarInitial(profile.displayName, size = 56.dp, imageUrl = profile.avatarUrl)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                profile.displayName,
                color = NcTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
            )
            Text("@${profile.username}", color = NcSecondary, fontSize = 14.sp)
            profile.country?.let {
                Text(it, color = NcTextSecondary, fontSize = 12.sp)
            }
        }
        IconButton(onClick = onShare) {
            Icon(
                Icons.Outlined.Share,
                contentDescription = stringResource(R.string.share_account),
                tint = NcSecondary,
            )
        }
    }
}

@Composable
private fun HomeTopBar(online: Boolean, profile: Profile?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NotChatLogo(size = 38.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.app_name),
                color = NcTextPrimary, fontSize = 18.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(8.dp)
                        .background(if (online) NcSecondary else NcError, CircleShape),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    stringResource(if (online) R.string.online else R.string.offline),
                    color = NcTextSecondary, fontSize = 12.sp,
                )
            }
        }
        if (profile != null) {
            AvatarInitial(profile.displayName, size = 40.dp, imageUrl = profile.avatarUrl)
        } else {
            Box(Modifier.size(40.dp).background(NcCard, CircleShape))
        }
    }
}

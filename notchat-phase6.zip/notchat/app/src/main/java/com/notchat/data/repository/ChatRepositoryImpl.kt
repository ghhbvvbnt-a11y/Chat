package com.notchat.data.repository

import com.notchat.data.remote.AuthorizedApi
import com.notchat.data.remote.RealtimeClient
import com.notchat.data.remote.toConversations
import com.notchat.data.remote.toMessage
import com.notchat.data.remote.toMessages
import com.notchat.data.remote.parseSignedUrls
import com.notchat.data.remote.toReceipts
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.LocalMedia
import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Receipts
import com.notchat.domain.model.ViewOnceContent
import com.notchat.domain.repository.ChatRepository
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val api: AuthorizedApi,
    private val realtime: RealtimeClient,
) : ChatRepository {

    private val http get() = api.http

    private class SignedUrl(val url: String, val expiresAtMillis: Long)

    private val signedUrls = ConcurrentHashMap<String, SignedUrl>()

    override val changes: SharedFlow<Unit> = realtime.changes
    override val realtimeConnected: StateFlow<Boolean> = realtime.connected

    override fun startRealtime() = realtime.start()
    override fun stopRealtime() = realtime.stop()

    override suspend fun startConversation(otherUserId: String): Outcome<String> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/get_or_create_direct_conversation",
            JSONObject().put("p_other", otherUserId),
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(r.body.trim().trim('"')) else api.failure(r)
    }

    override suspend fun conversations(): Outcome<List<Conversation>> = api.call { token ->
        val r = http.request("POST", "/rest/v1/rpc/list_conversations", accessToken = token)
        if (r.code in 200..299) Outcome.Success(JSONArray(r.body).toConversations()) else api.failure(r)
    }

    override suspend fun messages(
        conversationId: String,
        beforeRaw: String?,
        limit: Int,
    ): Outcome<List<Message>> = api.call { token ->
        val before = beforeRaw?.let { "&created_at=lt." + URLEncoder.encode(it, "UTF-8") }.orEmpty()
        val path = "/rest/v1/messages?conversation_id=eq.$conversationId" +
            "&select=id,conversation_id,sender_id,client_id,body,kind,view_once,reply_to,edited_at,deleted_at,created_at," +
            "message_views(viewer_id),message_attachments(id,kind,storage_path,file_name,mime_type,size_bytes,width,height,duration_ms)" +
            "&order=created_at.desc,id.desc&limit=$limit$before"
        val r = http.request("GET", path, accessToken = token)
        if (r.code in 200..299) {
            Outcome.Success(withSignedUrls(JSONArray(r.body).toMessages(), token))
        } else {
            api.failure(r)
        }
    }

    override suspend fun partnerReceipts(conversationId: String, myUserId: String): Outcome<Receipts?> =
        api.call { token ->
            val path = "/rest/v1/conversation_members?conversation_id=eq.$conversationId" +
                "&user_id=neq.$myUserId&select=last_delivered_at,last_read_at&limit=1"
            val r = http.request("GET", path, accessToken = token)
            if (r.code in 200..299) {
                val arr = JSONArray(r.body)
                Outcome.Success(if (arr.length() == 0) null else arr.getJSONObject(0).toReceipts())
            } else {
                api.failure(r)
            }
        }

    override suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        clientId: String,
        body: String,
    ): Outcome<Message?> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/messages",
            JSONObject()
                .put("conversation_id", conversationId)
                .put("sender_id", senderId)
                .put("client_id", clientId)
                .put("body", body),
            accessToken = token,
            headers = mapOf("Prefer" to "return=representation"),
        )
        when {
            r.code in 200..299 -> Outcome.Success(JSONArray(r.body).getJSONObject(0).toMessage())
            // 409 = unique (sender_id, client_id): this exact send was already stored earlier.
            r.code == 409 -> Outcome.Success(null)
            else -> api.failure(r)
        }
    }

    override suspend fun sendMedia(
        conversationId: String,
        clientId: String,
        media: LocalMedia,
        viewOnce: Boolean,
    ): Outcome<Unit> = api.call { token ->
        val ext = media.fileName.substringAfterLast('.', "").lowercase()
            .filter { it.isLetterOrDigit() }.take(8).ifEmpty { "bin" }
        // Deterministic path: a retry overwrites the same object instead of leaving orphans.
        val path = "$conversationId/$clientId/file.$ext"
        val bucket = if (viewOnce) ONCE_BUCKET else MEDIA_BUCKET
        val up = http.upload("/storage/v1/object/$bucket/$path", media.file, media.mimeType, token)
        if (up.code !in 200..299) return@call api.failure(up)

        val attachment = JSONObject()
            .put("path", path)
            .put("file_name", media.fileName)
            .put("mime_type", media.mimeType)
            .put("size_bytes", media.sizeBytes)
        media.width?.let { attachment.put("width", it) }
        media.height?.let { attachment.put("height", it) }
        media.durationMs?.let { attachment.put("duration_ms", it) }

        val r = http.request(
            "POST",
            "/rest/v1/rpc/send_media_message",
            JSONObject()
                .put("p_conversation", conversationId)
                .put("p_client_id", clientId)
                .put("p_kind", media.kind.wire)
                .put("p_body", "")
                .put("p_attachment", attachment)
                .put("p_view_once", viewOnce),
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
    }

    override suspend fun openViewOnce(messageId: String): Outcome<ViewOnceContent> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/open_view_once_message",
            JSONObject().put("p_message", messageId),
            accessToken = token,
        )
        if (r.code !in 200..299) return@call api.failure(r)
        val info = JSONObject(r.body)
        val path = info.getString("path")
        val s = http.request(
            "POST",
            "/storage/v1/object/sign/$ONCE_BUCKET/$path",
            JSONObject().put("expiresIn", VIEW_ONCE_URL_SECONDS),
            accessToken = token,
        )
        if (s.code !in 200..299) return@call api.failure(s)
        val signed = JSONObject(s.body).getString("signedURL")
        Outcome.Success(
            ViewOnceContent(
                url = http.publicBaseUrl().trimEnd('/') + "/storage/v1" + signed,
                kind = MessageKind.fromWire(info.optString("kind")),
                mimeType = info.optString("mime_type"),
            ),
        )
    }

    /** Attaches short-lived signed URLs (cached) so the UI can load private files. */
    private suspend fun withSignedUrls(messages: List<Message>, token: String): List<Message> {
        val now = System.currentTimeMillis()
        // View-once files live in another bucket and are never pre-signed.
        val needed = messages.filterNot { it.viewOnce }.flatMap { it.attachments }.map { it.storagePath }.distinct()
            .filter { (signedUrls[it]?.expiresAtMillis ?: 0L) - now < REFRESH_MARGIN_MS }
        if (needed.isNotEmpty()) {
            try {
                val body = JSONObject()
                    .put("expiresIn", URL_TTL_SECONDS)
                    .put("paths", JSONArray(needed))
                val r = http.request("POST", "/storage/v1/object/sign/chat-media", body, accessToken = token)
                if (r.code in 200..299) {
                    val expires = now + URL_TTL_SECONDS * 1000L
                    parseSignedUrls(r.body, http.publicBaseUrl()).forEach { (path, url) ->
                        signedUrls[path] = SignedUrl(url, expires)
                    }
                }
            } catch (e: java.io.IOException) {
                // Messages still load; media shows a placeholder until the next refresh.
            } catch (e: org.json.JSONException) {
                // Same as above.
            }
        }
        return messages.map { m ->
            if (m.attachments.isEmpty() || m.viewOnce) m
            else m.copy(attachments = m.attachments.map { a -> a.copy(url = signedUrls[a.storagePath]?.url) })
        }
    }

    override suspend fun markRead(conversationId: String, upToRaw: String): Outcome<Unit> =
        rpcMark("mark_conversation_read", conversationId, upToRaw)

    override suspend fun markDelivered(conversationId: String, upToRaw: String): Outcome<Unit> =
        rpcMark("mark_conversation_delivered", conversationId, upToRaw)

    private suspend fun rpcMark(function: String, conversationId: String, upToRaw: String): Outcome<Unit> =
        api.call { token ->
            val r = http.request(
                "POST",
                "/rest/v1/rpc/$function",
                JSONObject().put("p_conversation", conversationId).put("p_up_to", upToRaw),
                accessToken = token,
            )
            if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
        }

    private companion object {
        const val URL_TTL_SECONDS = 4 * 60 * 60
        const val REFRESH_MARGIN_MS = 10 * 60 * 1000L
        const val VIEW_ONCE_URL_SECONDS = 120
        const val MEDIA_BUCKET = "chat-media"
        const val ONCE_BUCKET = "chat-media-once"
    }
}

package com.notchat.domain.model

enum class BubbleTheme(val id: String) {
    VIOLET("violet"), TEAL("teal"), ROSE("rose"), SUNSET("sunset"), MONO("mono"),
}

enum class BubbleShape(val id: String) {
    ROUNDED("rounded"), PILL("pill"), CLASSIC("classic"), SQUARE("square"),
}

enum class ChatBackground(val id: String) {
    DARK("dark"), VIOLET_GLOW("violet"), TEAL_GLOW("teal"), DOTS("dots"), AURORA("aurora"),
}

/** How chats look on this device: bubble color, bubble shape and background. */
data class ChatAppearance(
    val theme: BubbleTheme = BubbleTheme.VIOLET,
    val shape: BubbleShape = BubbleShape.ROUNDED,
    val background: ChatBackground = ChatBackground.DARK,
) {
    companion object {
        /** Unknown or missing values fall back to the defaults. */
        fun fromIds(theme: String?, shape: String?, background: String?) = ChatAppearance(
            theme = BubbleTheme.entries.firstOrNull { it.id == theme } ?: BubbleTheme.VIOLET,
            shape = BubbleShape.entries.firstOrNull { it.id == shape } ?: BubbleShape.ROUNDED,
            background = ChatBackground.entries.firstOrNull { it.id == background } ?: ChatBackground.DARK,
        )
    }
}

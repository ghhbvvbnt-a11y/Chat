package com.notchat.data.repository

import com.notchat.data.remote.SupabaseHttp
import com.notchat.data.remote.toProfiles
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.UserRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepositoryImpl @Inject constructor(
    private val http: SupabaseHttp,
    private val auth: AuthRepository,
) : UserRepository {

    override suspend fun searchProfiles(query: String): Outcome<List<Profile>> = call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/search_profiles",
            JSONObject().put("p_query", query).put("p_limit", 20),
            accessToken = token,
        )
        when {
            r.code in 200..299 -> Outcome.Success(JSONArray(r.body).toProfiles())
            r.code == 401 -> Outcome.Failure(AuthError.SESSION_EXPIRED)
            r.code == 429 -> Outcome.Failure(AuthError.RATE_LIMITED)
            else -> Outcome.Failure(AuthError.UNKNOWN)
        }
    }

    override suspend fun profileByUsername(username: String): Outcome<Profile?> = call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/get_profile_by_username",
            JSONObject().put("p_username", username),
            accessToken = token,
        )
        when {
            r.code in 200..299 -> Outcome.Success(JSONArray(r.body).toProfiles().firstOrNull())
            r.code == 401 -> Outcome.Failure(AuthError.SESSION_EXPIRED)
            r.code == 429 -> Outcome.Failure(AuthError.RATE_LIMITED)
            else -> Outcome.Failure(AuthError.UNKNOWN)
        }
    }

    private suspend fun <T> call(block: suspend (String) -> Outcome<T>): Outcome<T> {
        if (!http.configured) return Outcome.Failure(AuthError.NOT_CONFIGURED)
        return withContext(Dispatchers.IO) {
            try {
                val token = auth.validAccessToken()
                    ?: return@withContext Outcome.Failure(AuthError.SESSION_EXPIRED)
                block(token)
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                Outcome.Failure(AuthError.NETWORK)
            } catch (e: JSONException) {
                Outcome.Failure(AuthError.UNKNOWN)
            }
        }
    }
}

package com.notchat.presentation.util

import android.content.Context
import android.text.format.DateUtils
import com.notchat.R
import java.text.DateFormat
import java.util.Date

/** Time for a conversation row: clock time today, "Yesterday", otherwise a short date. */
fun formatListTime(context: Context, millis: Long): String = when {
    DateUtils.isToday(millis) -> formatClock(millis)
    DateUtils.isToday(millis + DateUtils.DAY_IN_MILLIS) -> context.getString(R.string.yesterday)
    else -> DateFormat.getDateInstance(DateFormat.SHORT).format(Date(millis))
}

fun formatClock(millis: Long): String =
    DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(millis))

/** Heading above a day of messages. */
fun formatDayHeader(context: Context, millis: Long): String = when {
    DateUtils.isToday(millis) -> context.getString(R.string.today)
    DateUtils.isToday(millis + DateUtils.DAY_IN_MILLIS) -> context.getString(R.string.yesterday)
    else -> DateUtils.formatDateTime(
        context, millis,
        DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_YEAR,
    )
}

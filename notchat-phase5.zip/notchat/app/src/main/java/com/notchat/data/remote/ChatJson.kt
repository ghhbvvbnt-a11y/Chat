package com.notchat.data.remote

import com.notchat.domain.model.Attachment
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.Receipts
import org.json.JSONArray
import org.json.JSONObject
import java.time.OffsetDateTime

internal fun parseMillis(raw: String): Long = OffsetDateTime.parse(raw).toInstant().toEpochMilli()

private fun JSONObject.optNullableInt(key: String): Int? = if (isNull(key)) null else getInt(key)

internal fun JSONObject.toAttachment(): Attachment = Attachment(
    id = getString("id"),
    kind = MessageKind.fromWire(optString("kind")),
    storagePath = getString("storage_path"),
    fileName = optString("file_name", "file"),
    mimeType = optString("mime_type", "application/octet-stream"),
    sizeBytes = optLong("size_bytes", 0L),
    width = optNullableInt("width"),
    height = optNullableInt("height"),
    durationMs = optNullableInt("duration_ms"),
)

internal fun JSONObject.toMessage(): Message {
    val created = getString("created_at")
    val attachments = optJSONArray("message_attachments")?.let { arr ->
        List(arr.length()) { arr.getJSONObject(it).toAttachment() }
    } ?: emptyList()
    return Message(
        id = getString("id"),
        clientId = getString("client_id"),
        conversationId = getString("conversation_id"),
        senderId = getString("sender_id"),
        body = if (isNull("body")) "" else getString("body"),
        createdAtRaw = created,
        createdAtMillis = parseMillis(created),
        replyTo = optNullableString("reply_to"),
        edited = !isNull("edited_at"),
        deleted = !isNull("deleted_at"),
        kind = MessageKind.fromWire(optString("kind", "text")),
        attachments = attachments,
    )
}

internal fun JSONArray.toMessages(): List<Message> =
    List(length()) { getJSONObject(it).toMessage() }

internal fun JSONObject.toConversation(): Conversation {
    val at = getString("last_message_at")
    return Conversation(
        id = getString("conversation_id"),
        otherUserId = getString("other_user_id"),
        otherUsername = getString("other_username"),
        otherDisplayName = getString("other_display_name"),
        otherAvatarUrl = optNullableString("other_avatar_url"),
        lastMessageBody = if (isNull("last_message_body")) "" else getString("last_message_body"),
        lastMessageDeleted = optBoolean("last_message_deleted", false),
        lastMessageSenderId = getString("last_message_sender_id"),
        lastMessageAtRaw = at,
        lastMessageAtMillis = parseMillis(at),
        unreadCount = optInt("unread_count", 0),
        muted = optBoolean("muted", false),
        lastMessageKind = MessageKind.fromWire(optString("last_message_kind", "text")),
    )
}

internal fun JSONArray.toConversations(): List<Conversation> =
    List(length()) { getJSONObject(it).toConversation() }

internal fun JSONObject.toReceipts(): Receipts = Receipts(
    deliveredAtMillis = parseMillis(getString("last_delivered_at")),
    readAtMillis = parseMillis(getString("last_read_at")),
)

/** Parses the batch "sign" response into path -> full signed URL. */
internal fun parseSignedUrls(body: String, baseUrl: String): Map<String, String> {
    val arr = JSONArray(body)
    val out = HashMap<String, String>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val path = o.optString("path")
        val signed = o.optString("signedURL")
        if (path.isNotEmpty() && signed.isNotEmpty() && o.isNull("error")) {
            out[path] = baseUrl.trimEnd('/') + "/storage/v1" + signed
        }
    }
    return out
}

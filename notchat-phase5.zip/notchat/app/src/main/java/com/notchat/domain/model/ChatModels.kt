package com.notchat.domain.model

import java.io.File

enum class MessageStatus { SENDING, FAILED, SENT, DELIVERED, READ }

enum class MessageKind(val wire: String) {
    TEXT("text"),
    IMAGE("image"),
    VIDEO("video"),
    AUDIO("audio"),
    FILE("file");

    companion object {
        fun fromWire(value: String?): MessageKind = entries.firstOrNull { it.wire == value } ?: TEXT

        fun fromMime(mime: String): MessageKind = when {
            mime.startsWith("image/") -> IMAGE
            mime.startsWith("video/") -> VIDEO
            mime.startsWith("audio/") -> AUDIO
            else -> FILE
        }
    }
}

data class Attachment(
    val id: String,
    val kind: MessageKind,
    val storagePath: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val width: Int?,
    val height: Int?,
    val durationMs: Int?,
    /** Short-lived signed URL (or a local file URI while the upload is pending). */
    val url: String? = null,
)

/** A file prepared on this device (compressed / copied to cache) and ready to upload. */
data class LocalMedia(
    val file: File,
    val kind: MessageKind,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val width: Int?,
    val height: Int?,
    val durationMs: Int?,
)

data class Message(
    val id: String,
    val clientId: String,
    val conversationId: String,
    val senderId: String,
    val body: String,
    /** Exact server timestamp text, reused as a pagination cursor (keeps microsecond precision). */
    val createdAtRaw: String,
    val createdAtMillis: Long,
    val replyTo: String?,
    val edited: Boolean,
    val deleted: Boolean,
    val kind: MessageKind = MessageKind.TEXT,
    val attachments: List<Attachment> = emptyList(),
)

/** A message as shown on screen. */
data class ChatMessage(
    val message: Message,
    val status: MessageStatus,
    val mine: Boolean,
)

/** How far the other person's device has received / read, as server times in epoch millis. */
data class Receipts(val deliveredAtMillis: Long, val readAtMillis: Long)

data class Conversation(
    val id: String,
    val otherUserId: String,
    val otherUsername: String,
    val otherDisplayName: String,
    val otherAvatarUrl: String?,
    val lastMessageBody: String,
    val lastMessageDeleted: Boolean,
    val lastMessageSenderId: String,
    val lastMessageAtRaw: String,
    val lastMessageAtMillis: Long,
    val unreadCount: Int,
    val muted: Boolean,
    val lastMessageKind: MessageKind = MessageKind.TEXT,
)

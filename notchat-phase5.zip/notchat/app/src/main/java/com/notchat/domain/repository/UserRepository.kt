package com.notchat.domain.repository

import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile

interface UserRepository {
    /** Searches by @username or display name. Never includes the caller. */
    suspend fun searchProfiles(query: String): Outcome<List<Profile>>

    /** Success(null) when no such user exists. */
    suspend fun profileByUsername(username: String): Outcome<Profile?>
}

package com.notchat.presentation.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.PersonSearch
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Profile
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.EmptyState
import com.notchat.presentation.components.NcTextField

@Composable
fun SearchScreen(
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    vm: SearchViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(Unit) { if (query.isNotBlank()) vm.onQueryChange(query) }

    Scaffold(containerColor = NcBackground) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).systemBarsPadding().imePadding()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = NcTextPrimary,
                    )
                }
                NcTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        vm.onQueryChange(it)
                    },
                    label = stringResource(R.string.search_hint),
                    leadingIcon = Icons.Outlined.Search,
                    imeAction = ImeAction.Search,
                    modifier = Modifier.focusRequester(focus).padding(end = 8.dp),
                )
            }

            Box(Modifier.fillMaxSize()) {
                when {
                    ui.error != null -> EmptyState(
                        icon = Icons.Outlined.WifiOff,
                        title = ui.error!!.message(),
                        body = "",
                    )
                    ui.results.isNotEmpty() -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                    ) {
                        items(ui.results, key = { it.id }) { profile ->
                            ResultRow(profile) { onOpenProfile(profile.username) }
                        }
                    }
                    ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        CircularProgressIndicator(
                            color = NcPrimary,
                            modifier = Modifier.padding(top = 48.dp),
                        )
                    }
                    ui.searched -> EmptyState(
                        icon = Icons.Outlined.PersonSearch,
                        title = stringResource(R.string.search_no_results),
                        body = stringResource(R.string.search_no_results_body),
                    )
                    ui.tooShort -> EmptyState(
                        icon = Icons.Outlined.PersonSearch,
                        title = stringResource(R.string.search_min_chars),
                        body = "",
                    )
                    else -> EmptyState(
                        icon = Icons.Outlined.PersonSearch,
                        title = stringResource(R.string.search_prompt_title),
                        body = stringResource(R.string.search_prompt_body),
                    )
                }
            }
        }
    }
}

@Composable
private fun ResultRow(profile: Profile, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcCard, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AvatarInitial(profile.displayName, size = 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                profile.displayName,
                color = NcTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1,
            )
            Text("@${profile.username}", color = NcSecondary, fontSize = 13.sp, maxLines = 1)
        }
        profile.country?.let {
            Text(it, color = NcTextSecondary, fontSize = 12.sp)
        }
    }
}

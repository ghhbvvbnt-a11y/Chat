package com.notchat.domain.repository

import com.notchat.domain.model.Conversation
import com.notchat.domain.model.LocalMedia
import com.notchat.domain.model.Message
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Receipts
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface ChatRepository {
    /** Emits whenever the server reports a change that may affect my chats (a hint to re-fetch). */
    val changes: SharedFlow<Unit>
    val realtimeConnected: StateFlow<Boolean>

    fun startRealtime()
    fun stopRealtime()

    /** Returns the conversation id (existing or newly created). */
    suspend fun startConversation(otherUserId: String): Outcome<String>

    suspend fun conversations(): Outcome<List<Conversation>>

    /** Newest first. Pass the oldest loaded message's createdAtRaw as [beforeRaw] to page back. */
    suspend fun messages(conversationId: String, beforeRaw: String?, limit: Int): Outcome<List<Message>>

    suspend fun partnerReceipts(conversationId: String, myUserId: String): Outcome<Receipts?>

    /** Success(null) means the message already existed (a retry of an already-stored send). */
    suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        clientId: String,
        body: String,
    ): Outcome<Message?>

    /** Uploads the file, then creates the media message. Safe to retry with the same clientId. */
    suspend fun sendMedia(conversationId: String, clientId: String, media: LocalMedia): Outcome<Unit>

    suspend fun markRead(conversationId: String, upToRaw: String): Outcome<Unit>
    suspend fun markDelivered(conversationId: String, upToRaw: String): Outcome<Unit>
}

package com.notchat.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.notchat.core.theme.NcPrimary

/** Circle with the first letter of the name. Real photos arrive with media upload (Phase 5). */
@Composable
fun AvatarInitial(name: String, size: Dp, modifier: Modifier = Modifier) {
    val fontSize: TextUnit = (size.value * 0.4f).sp
    Box(
        modifier = modifier.size(size).background(NcPrimary.copy(alpha = 0.25f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.trim().take(1).uppercase(),
            color = NcPrimary,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
        )
    }
}

package com.notchat

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.notchat.presence.PresenceManager
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class NotChatApp : Application() {
    @Inject lateinit var presenceManager: PresenceManager

    override fun onCreate() {
        super.onCreate()
        ProcessLifecycleOwner.get().lifecycle.addObserver(presenceManager)
    }
}

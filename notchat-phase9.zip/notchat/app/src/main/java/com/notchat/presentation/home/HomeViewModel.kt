package com.notchat.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.PresenceRepository
import com.notchat.domain.repository.UserRepository
import com.notchat.notify.NotificationController
import com.notchat.notify.NotificationHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val loading: Boolean = true,
    val profile: Profile? = null,
    val error: AuthError? = null,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repo: AuthRepository,
    users: UserRepository,
    private val presence: PresenceRepository,
    private val notifications: NotificationController,
    private val notificationHelper: NotificationHelper,
) : ViewModel() {

    private val _ui = MutableStateFlow(HomeUiState())
    val ui: StateFlow<HomeUiState> = _ui.asStateFlow()

    val signedOut: StateFlow<Boolean> = repo.sessionState
        .map { it is SessionState.SignedOut }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _errors = MutableSharedFlow<AuthError>(extraBufferCapacity = 1)
    val errors: SharedFlow<AuthError> = _errors.asSharedFlow()

    init {
        loadProfile()
        viewModelScope.launch {
            val r = presence.sharing()
            if (r is Outcome.Success) _presenceSharing.value = r.value
        }
        viewModelScope.launch {
            users.profileUpdates.collect { updated ->
                _ui.update { it.copy(profile = updated, error = null) }
            }
        }
    }

    fun loadProfile() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null) }
            when (val r = repo.currentProfile()) {
                is Outcome.Success -> _ui.update { it.copy(loading = false, profile = r.value) }
                is Outcome.Failure -> _ui.update { it.copy(loading = false, error = r.error) }
            }
        }
    }

    private val _presenceSharing = MutableStateFlow(true)
    val presenceSharing: StateFlow<Boolean> = _presenceSharing.asStateFlow()

    fun setPresenceSharing(share: Boolean) {
        val previous = _presenceSharing.value
        _presenceSharing.value = share
        viewModelScope.launch {
            if (presence.setSharing(share) is Outcome.Failure) _presenceSharing.value = previous
        }
    }

    val notificationsEnabled: StateFlow<Boolean> = notifications.enabled

    fun canNotify(): Boolean = notificationHelper.canNotify()

    /** True on Android 13+ when we still need to ask the user for the notification permission. */
    fun needsNotificationPrompt(): Boolean =
        android.os.Build.VERSION.SDK_INT >= 33 &&
            !notificationHelper.canNotify() &&
            !notifications.permissionAsked &&
            notifications.enabled.value

    fun onNotificationPermissionResult(granted: Boolean) {
        notifications.permissionAsked = true
        if (granted) notifications.start()
    }

    fun ensureNotifications() = notifications.start()

    fun setNotificationsEnabled(value: Boolean) = notifications.setEnabled(value)

    fun signOut() {
        notifications.stop()
        viewModelScope.launch { repo.signOut() }
    }

    fun deleteAccount() {
        notifications.stop()
        viewModelScope.launch {
            val r = repo.deleteAccount()
            if (r is Outcome.Failure) {
                _errors.tryEmit(r.error)
                notifications.start()
            }
        }
    }
}

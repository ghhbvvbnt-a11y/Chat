package com.notchat.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.NotificationsOff
import androidx.compose.material3.Icon
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOnPrimary
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationType
import com.notchat.domain.model.MessageKind
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.EmptyState
import com.notchat.presentation.util.formatListTime

@Composable
fun ConversationsList(
    state: ConversationsUiState,
    onOpen: (conversationId: String) -> Unit,
    onRetry: () -> Unit,
) {
    when {
        state.items.isNotEmpty() -> LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(state.items, key = { it.id }) { c ->
                ConversationRow(c, state.myId) { onOpen(c.id) }
            }
        }
        state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            CircularProgressIndicator(color = NcPrimary, modifier = Modifier.padding(top = 48.dp))
        }
        state.error != null -> Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(state.error.message(), color = NcError, fontSize = 14.sp)
            TextButton(onClick = onRetry) { Text(stringResource(R.string.retry), color = NcSecondary) }
        }
        else -> EmptyState(
            icon = Icons.Outlined.ChatBubbleOutline,
            title = stringResource(R.string.empty_chats_title),
            body = stringResource(R.string.empty_chats_body),
        )
    }
}

@Composable
private fun ConversationRow(c: Conversation, myId: String, onClick: () -> Unit) {
    val context = LocalContext.current
    val mine = c.lastMessageSenderId == myId
    val content = when (c.lastMessageKind) {
        MessageKind.TEXT -> c.lastMessageBody
        MessageKind.IMAGE -> stringResource(R.string.media_photo)
        MessageKind.VIDEO -> stringResource(R.string.media_video)
        MessageKind.AUDIO -> stringResource(R.string.media_voice)
        MessageKind.FILE -> stringResource(R.string.media_file)
    }
    val preview = when {
        !c.hasMessages -> stringResource(R.string.group_no_messages)
        c.lastMessageDeleted -> stringResource(R.string.message_deleted)
        mine -> stringResource(R.string.you_prefix) + content
        c.type == ConversationType.GROUP && c.lastMessageSenderName != null ->
            c.lastMessageSenderName + ": " + content
        else -> content
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcCard, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            AvatarInitial(c.title, size = 52.dp, imageUrl = c.otherAvatarUrl)
            if (c.type == ConversationType.DIRECT && c.otherOnline) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(15.dp)
                        .background(NcCard, CircleShape)
                        .padding(2.5.dp)
                        .background(NcPrimary, CircleShape),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                c.title,
                color = NcTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                preview.replace('\n', ' '),
                color = NcTextSecondary, fontSize = 14.sp,
                fontStyle = if (c.lastMessageDeleted) FontStyle.Italic else FontStyle.Normal,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (c.muted) {
                    Icon(
                        Icons.Outlined.NotificationsOff,
                        contentDescription = null,
                        tint = NcTextSecondary,
                        modifier = Modifier.size(14.dp).padding(end = 2.dp),
                    )
                }
                Text(
                    formatListTime(context, c.lastMessageAtMillis),
                    color = if (c.unreadCount > 0) NcSecondary else NcTextSecondary,
                    fontSize = 12.sp,
                )
            }
            if (c.unreadCount > 0) {
                Spacer(Modifier.padding(top = 4.dp))
                Box(
                    modifier = Modifier
                        .background(NcPrimary, CircleShape)
                        .padding(horizontal = 7.dp, vertical = 2.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (c.unreadCount > 99) "99+" else c.unreadCount.toString(),
                        color = NcOnPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

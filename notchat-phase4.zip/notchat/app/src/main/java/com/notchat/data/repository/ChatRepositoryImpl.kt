package com.notchat.data.repository

import com.notchat.data.remote.AuthorizedApi
import com.notchat.data.remote.RealtimeClient
import com.notchat.data.remote.toConversations
import com.notchat.data.remote.toMessage
import com.notchat.data.remote.toMessages
import com.notchat.data.remote.toReceipts
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.Message
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Receipts
import com.notchat.domain.repository.ChatRepository
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val api: AuthorizedApi,
    private val realtime: RealtimeClient,
) : ChatRepository {

    private val http get() = api.http

    override val changes: SharedFlow<Unit> = realtime.changes
    override val realtimeConnected: StateFlow<Boolean> = realtime.connected

    override fun startRealtime() = realtime.start()
    override fun stopRealtime() = realtime.stop()

    override suspend fun startConversation(otherUserId: String): Outcome<String> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/get_or_create_direct_conversation",
            JSONObject().put("p_other", otherUserId),
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(r.body.trim().trim('"')) else api.failure(r)
    }

    override suspend fun conversations(): Outcome<List<Conversation>> = api.call { token ->
        val r = http.request("POST", "/rest/v1/rpc/list_conversations", accessToken = token)
        if (r.code in 200..299) Outcome.Success(JSONArray(r.body).toConversations()) else api.failure(r)
    }

    override suspend fun messages(
        conversationId: String,
        beforeRaw: String?,
        limit: Int,
    ): Outcome<List<Message>> = api.call { token ->
        val before = beforeRaw?.let { "&created_at=lt." + URLEncoder.encode(it, "UTF-8") }.orEmpty()
        val path = "/rest/v1/messages?conversation_id=eq.$conversationId" +
            "&select=id,conversation_id,sender_id,client_id,body,reply_to,edited_at,deleted_at,created_at" +
            "&order=created_at.desc,id.desc&limit=$limit$before"
        val r = http.request("GET", path, accessToken = token)
        if (r.code in 200..299) Outcome.Success(JSONArray(r.body).toMessages()) else api.failure(r)
    }

    override suspend fun partnerReceipts(conversationId: String, myUserId: String): Outcome<Receipts?> =
        api.call { token ->
            val path = "/rest/v1/conversation_members?conversation_id=eq.$conversationId" +
                "&user_id=neq.$myUserId&select=last_delivered_at,last_read_at&limit=1"
            val r = http.request("GET", path, accessToken = token)
            if (r.code in 200..299) {
                val arr = JSONArray(r.body)
                Outcome.Success(if (arr.length() == 0) null else arr.getJSONObject(0).toReceipts())
            } else {
                api.failure(r)
            }
        }

    override suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        clientId: String,
        body: String,
    ): Outcome<Message?> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/messages",
            JSONObject()
                .put("conversation_id", conversationId)
                .put("sender_id", senderId)
                .put("client_id", clientId)
                .put("body", body),
            accessToken = token,
            headers = mapOf("Prefer" to "return=representation"),
        )
        when {
            r.code in 200..299 -> Outcome.Success(JSONArray(r.body).getJSONObject(0).toMessage())
            // 409 = unique (sender_id, client_id): this exact send was already stored earlier.
            r.code == 409 -> Outcome.Success(null)
            else -> api.failure(r)
        }
    }

    override suspend fun markRead(conversationId: String, upToRaw: String): Outcome<Unit> =
        rpcMark("mark_conversation_read", conversationId, upToRaw)

    override suspend fun markDelivered(conversationId: String, upToRaw: String): Outcome<Unit> =
        rpcMark("mark_conversation_delivered", conversationId, upToRaw)

    private suspend fun rpcMark(function: String, conversationId: String, upToRaw: String): Outcome<Unit> =
        api.call { token ->
            val r = http.request(
                "POST",
                "/rest/v1/rpc/$function",
                JSONObject().put("p_conversation", conversationId).put("p_up_to", upToRaw),
                accessToken = token,
            )
            if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
        }
}

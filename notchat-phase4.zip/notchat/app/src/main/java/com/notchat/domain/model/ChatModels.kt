package com.notchat.domain.model

enum class MessageStatus { SENDING, FAILED, SENT, DELIVERED, READ }

data class Message(
    val id: String,
    val clientId: String,
    val conversationId: String,
    val senderId: String,
    val body: String,
    /** Exact server timestamp text, reused as a pagination cursor (keeps microsecond precision). */
    val createdAtRaw: String,
    val createdAtMillis: Long,
    val replyTo: String?,
    val edited: Boolean,
    val deleted: Boolean,
)

/** A message as shown on screen. */
data class ChatMessage(
    val message: Message,
    val status: MessageStatus,
    val mine: Boolean,
)

/** How far the other person's device has received / read, as server times in epoch millis. */
data class Receipts(val deliveredAtMillis: Long, val readAtMillis: Long)

data class Conversation(
    val id: String,
    val otherUserId: String,
    val otherUsername: String,
    val otherDisplayName: String,
    val otherAvatarUrl: String?,
    val lastMessageBody: String,
    val lastMessageDeleted: Boolean,
    val lastMessageSenderId: String,
    val lastMessageAtRaw: String,
    val lastMessageAtMillis: Long,
    val unreadCount: Int,
    val muted: Boolean,
)

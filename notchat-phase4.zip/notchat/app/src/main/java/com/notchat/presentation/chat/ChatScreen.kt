package com.notchat.presentation.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Done
import androidx.compose.material.icons.outlined.DoneAll
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcSurface
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.ChatLogic
import com.notchat.domain.model.ChatMessage
import com.notchat.domain.model.MessageStatus
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.util.formatClock
import com.notchat.presentation.util.formatDayHeader

@Composable
fun ChatScreen(
    onBack: () -> Unit,
    vm: ChatViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    val connected by vm.connected.collectAsState()
    var text by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    val nearOldest by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            ui.messages.isNotEmpty() && last >= ui.messages.size - 5
        }
    }
    LaunchedEffect(nearOldest, ui.messages.size) {
        if (nearOldest) vm.loadOlder()
    }
    val newestKey = ui.messages.firstOrNull()?.message?.clientId
    LaunchedEffect(newestKey) {
        if (listState.firstVisibleItemIndex <= 2) listState.animateScrollToItem(0)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(NcBackground)
            .systemBarsPadding()
            .imePadding(),
    ) {
        ChatTopBar(
            name = ui.partner?.displayName.orEmpty(),
            subtitle = if (!connected) stringResource(R.string.chat_connecting)
            else ui.partner?.let { "@${it.username}" }.orEmpty(),
            onBack = onBack,
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NcPrimary)
                }
                ui.error != null && ui.messages.isEmpty() -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(ui.error!!.message(), color = NcError, textAlign = TextAlign.Center)
                    TextButton(onClick = onBack) {
                        Text(stringResource(R.string.back), color = NcSecondary)
                    }
                }
                ui.messages.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        stringResource(R.string.chat_empty),
                        color = NcTextSecondary, textAlign = TextAlign.Center,
                    )
                }
                else -> LazyColumn(
                    state = listState,
                    reverseLayout = true,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    itemsIndexed(ui.messages, key = { _, m -> m.message.clientId }) { index, item ->
                        val older = ui.messages.getOrNull(index + 1)
                        val firstOfDay = older == null ||
                            !ChatLogic.sameDay(older.message.createdAtMillis, item.message.createdAtMillis)
                        Column(Modifier.fillMaxWidth()) {
                            if (firstOfDay) DayHeader(item.message.createdAtMillis)
                            MessageBubble(item, onRetry = { vm.retry(item.message.clientId) })
                        }
                    }
                    if (ui.loadingOlder) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(
                                    color = NcPrimary, strokeWidth = 2.dp, modifier = Modifier.size(20.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        ui.sendError?.let {
            Text(
                it.message(),
                color = NcError, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        MessageInput(
            text = text,
            onTextChange = { text = it.take(MAX_LENGTH) },
            onSend = {
                vm.send(text)
                text = ""
            },
        )
    }
}

private const val MAX_LENGTH = 4000

@Composable
private fun ChatTopBar(name: String, subtitle: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcSurface)
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(
                Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = stringResource(R.string.back),
                tint = NcTextPrimary,
            )
        }
        AvatarInitial(name.ifEmpty { "?" }, size = 40.dp)
        Column(Modifier.padding(start = 12.dp)) {
            Text(name, color = NcTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(subtitle, color = NcTextSecondary, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun DayHeader(millis: Long) {
    val context = LocalContext.current
    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
        Text(
            formatDayHeader(context, millis),
            color = NcTextSecondary, fontSize = 12.sp,
            modifier = Modifier
                .background(NcCard, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun MessageBubble(item: ChatMessage, onRetry: () -> Unit) {
    val mine = item.mine
    val failed = item.status == MessageStatus.FAILED
    val shape = RoundedCornerShape(
        topStart = 18.dp, topEnd = 18.dp,
        bottomStart = if (mine) 18.dp else 4.dp,
        bottomEnd = if (mine) 4.dp else 18.dp,
    )
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(if (mine) NcPrimary else NcCard, shape)
                .then(if (failed) Modifier.clickable(onClick = onRetry) else Modifier)
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            if (item.message.deleted) {
                Text(
                    stringResource(R.string.message_deleted),
                    color = if (mine) Color.White.copy(alpha = 0.8f) else NcTextSecondary,
                    fontStyle = FontStyle.Italic, fontSize = 15.sp,
                )
            } else {
                Text(item.message.body, color = NcTextPrimary, fontSize = 16.sp)
            }
            Row(
                modifier = Modifier.align(Alignment.End).padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (failed) {
                    Text(stringResource(R.string.message_not_sent), color = Color.White, fontSize = 11.sp)
                } else {
                    Text(
                        formatClock(item.message.createdAtMillis).takeIf { item.message.createdAtRaw.isNotEmpty() }
                            ?: "",
                        color = NcTextPrimary.copy(alpha = 0.7f), fontSize = 11.sp,
                    )
                }
                if (mine) {
                    Spacer(Modifier.size(4.dp))
                    StatusIcon(item.status)
                }
            }
        }
    }
}

@Composable
private fun StatusIcon(status: MessageStatus) {
    val (icon, tint) = when (status) {
        MessageStatus.SENDING -> Icons.Outlined.Schedule to NcTextPrimary.copy(alpha = 0.7f)
        MessageStatus.FAILED -> Icons.Outlined.ErrorOutline to NcError
        MessageStatus.SENT -> Icons.Outlined.Done to NcTextPrimary.copy(alpha = 0.7f)
        MessageStatus.DELIVERED -> Icons.Outlined.DoneAll to NcTextPrimary.copy(alpha = 0.7f)
        MessageStatus.READ -> Icons.Outlined.DoneAll to NcSecondary
    }
    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
}

@Composable
private fun MessageInput(text: String, onTextChange: (String) -> Unit, onSend: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcSurface)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text(stringResource(R.string.chat_input_hint), color = NcTextSecondary) },
            maxLines = 4,
            shape = RoundedCornerShape(24.dp),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = NcTextPrimary,
                unfocusedTextColor = NcTextPrimary,
                focusedContainerColor = NcCard,
                unfocusedContainerColor = NcCard,
                cursorColor = NcPrimary,
                focusedBorderColor = NcPrimary,
                unfocusedBorderColor = NcOutline,
            ),
        )
        IconButton(
            onClick = onSend,
            enabled = text.isNotBlank(),
            modifier = Modifier.padding(start = 4.dp),
        ) {
            Icon(
                Icons.AutoMirrored.Outlined.Send,
                contentDescription = stringResource(R.string.send),
                tint = if (text.isNotBlank()) NcPrimary else NcTextSecondary.copy(alpha = 0.5f),
                modifier = Modifier.alpha(1f),
            )
        }
    }
}

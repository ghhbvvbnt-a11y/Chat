package com.notchat.presentation.chat

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.ChatLogic
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.ChatMessage
import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageStatus
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.model.Receipts
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.ChatRepository
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class ChatUiState(
    val loading: Boolean = true,
    val messages: List<ChatMessage> = emptyList(), // newest first
    val partner: Profile? = null,
    val error: AuthError? = null,
    val sendError: AuthError? = null,
    val loadingOlder: Boolean = false,
    val endReached: Boolean = false,
)

private data class Pending(val message: Message, val failed: Boolean)

@OptIn(FlowPreview::class)
@HiltViewModel
class ChatViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val chat: ChatRepository,
    private val users: UserRepository,
    auth: AuthRepository,
) : ViewModel() {

    private val conversationId = savedStateHandle.get<String>("conversationId").orEmpty()
    private val username = savedStateHandle.get<String>("username").orEmpty()
    private val myId = (auth.sessionState.value as? SessionState.SignedIn)?.userId.orEmpty()

    private var server: List<Message> = emptyList() // newest first
    private var pending: List<Pending> = emptyList() // newest first
    private var receipts: Receipts? = null
    private var lastReadMarkedMillis = 0L
    private var olderJobRunning = false

    private val _ui = MutableStateFlow(ChatUiState())
    val ui: StateFlow<ChatUiState> = _ui.asStateFlow()
    val connected: StateFlow<Boolean> = chat.realtimeConnected

    init {
        chat.startRealtime()
        loadPartner()
        loadInitial()
        viewModelScope.launch { chat.changes.debounce(150).collect { refreshLatest() } }
        // Safety net in case the live connection is down or silently not delivering.
        viewModelScope.launch {
            while (true) {
                delay(if (chat.realtimeConnected.value) 30_000L else 5_000L)
                refreshLatest()
            }
        }
    }

    fun send(raw: String) {
        val body = raw.trim()
        if (body.isEmpty() || body.length > MAX_LENGTH || myId.isEmpty()) return
        val clientId = UUID.randomUUID().toString()
        val local = Message(
            id = clientId, clientId = clientId, conversationId = conversationId, senderId = myId,
            body = body, createdAtRaw = "", createdAtMillis = System.currentTimeMillis(),
            replyTo = null, edited = false, deleted = false,
        )
        pending = listOf(Pending(local, failed = false)) + pending
        _ui.update { it.copy(sendError = null) }
        publish()
        dispatch(clientId)
    }

    fun retry(clientId: String) {
        pending = pending.map { if (it.message.clientId == clientId) it.copy(failed = false) else it }
        _ui.update { it.copy(sendError = null) }
        publish()
        dispatch(clientId)
    }

    fun loadOlder() {
        val state = _ui.value
        if (olderJobRunning || state.endReached || state.loading || server.isEmpty()) return
        olderJobRunning = true
        _ui.update { it.copy(loadingOlder = true) }
        viewModelScope.launch {
            when (val r = chat.messages(conversationId, server.last().createdAtRaw, PAGE_SIZE)) {
                is Outcome.Success -> {
                    server = ChatLogic.mergeNewestFirst(server, r.value)
                    _ui.update { it.copy(endReached = r.value.size < PAGE_SIZE) }
                }
                is Outcome.Failure -> Unit // user can scroll again to retry
            }
            olderJobRunning = false
            _ui.update { it.copy(loadingOlder = false) }
            publish()
        }
    }

    private fun dispatch(clientId: String) {
        val body = pending.firstOrNull { it.message.clientId == clientId }?.message?.body ?: return
        viewModelScope.launch {
            when (val r = chat.sendMessage(conversationId, myId, clientId, body)) {
                is Outcome.Success -> {
                    r.value?.let { server = ChatLogic.mergeNewestFirst(server, listOf(it)) }
                    pending = pending.filterNot { it.message.clientId == clientId }
                    publish()
                    if (r.value == null) refreshLatest()
                }
                is Outcome.Failure -> {
                    pending = pending.map { if (it.message.clientId == clientId) it.copy(failed = true) else it }
                    _ui.update { it.copy(sendError = r.error) }
                    publish()
                }
            }
        }
    }

    private fun loadInitial() {
        viewModelScope.launch {
            when (val r = chat.messages(conversationId, null, PAGE_SIZE)) {
                is Outcome.Success -> {
                    server = ChatLogic.mergeNewestFirst(emptyList(), r.value)
                    _ui.update { it.copy(loading = false, error = null, endReached = r.value.size < PAGE_SIZE) }
                    refreshReceipts()
                    publish()
                    markReadIfNeeded()
                }
                is Outcome.Failure -> _ui.update { it.copy(loading = false, error = r.error) }
            }
        }
    }

    private fun refreshLatest() {
        if (_ui.value.loading) return
        viewModelScope.launch {
            val r = chat.messages(conversationId, null, PAGE_SIZE)
            if (r is Outcome.Success) {
                server = ChatLogic.mergeNewestFirst(server, r.value)
                refreshReceipts()
                publish()
                markReadIfNeeded()
            }
        }
    }

    private suspend fun refreshReceipts() {
        val r = chat.partnerReceipts(conversationId, myId)
        if (r is Outcome.Success) receipts = r.value
    }

    private suspend fun markReadIfNeeded() {
        val newest = server.firstOrNull { it.senderId != myId && !it.deleted } ?: return
        if (newest.createdAtMillis <= lastReadMarkedMillis) return
        if (chat.markRead(conversationId, newest.createdAtRaw) is Outcome.Success) {
            lastReadMarkedMillis = newest.createdAtMillis
        }
    }

    private fun loadPartner() {
        viewModelScope.launch {
            val r = users.profileByUsername(username)
            if (r is Outcome.Success) _ui.update { it.copy(partner = r.value) }
        }
    }

    private fun publish() {
        val storedClientIds = server.mapTo(HashSet()) { it.clientId }
        val local = pending
            .filter { it.message.clientId !in storedClientIds }
            .map { ChatMessage(it.message, if (it.failed) MessageStatus.FAILED else MessageStatus.SENDING, true) }
        val stored = server.map { m ->
            val mine = m.senderId == myId
            ChatMessage(m, if (mine) ChatLogic.statusFor(m, receipts) else MessageStatus.SENT, mine)
        }
        _ui.update { it.copy(messages = local + stored) }
    }

    private companion object {
        const val PAGE_SIZE = 30
        const val MAX_LENGTH = 4000
    }
}

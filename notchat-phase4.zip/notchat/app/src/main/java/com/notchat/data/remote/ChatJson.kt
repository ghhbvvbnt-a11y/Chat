package com.notchat.data.remote

import com.notchat.domain.model.Conversation
import com.notchat.domain.model.Message
import com.notchat.domain.model.Receipts
import org.json.JSONArray
import org.json.JSONObject
import java.time.OffsetDateTime

internal fun parseMillis(raw: String): Long = OffsetDateTime.parse(raw).toInstant().toEpochMilli()

internal fun JSONObject.toMessage(): Message {
    val created = getString("created_at")
    return Message(
        id = getString("id"),
        clientId = getString("client_id"),
        conversationId = getString("conversation_id"),
        senderId = getString("sender_id"),
        body = if (isNull("body")) "" else getString("body"),
        createdAtRaw = created,
        createdAtMillis = parseMillis(created),
        replyTo = optNullableString("reply_to"),
        edited = !isNull("edited_at"),
        deleted = !isNull("deleted_at"),
    )
}

internal fun JSONArray.toMessages(): List<Message> =
    List(length()) { getJSONObject(it).toMessage() }

internal fun JSONObject.toConversation(): Conversation {
    val at = getString("last_message_at")
    return Conversation(
        id = getString("conversation_id"),
        otherUserId = getString("other_user_id"),
        otherUsername = getString("other_username"),
        otherDisplayName = getString("other_display_name"),
        otherAvatarUrl = optNullableString("other_avatar_url"),
        lastMessageBody = if (isNull("last_message_body")) "" else getString("last_message_body"),
        lastMessageDeleted = optBoolean("last_message_deleted", false),
        lastMessageSenderId = getString("last_message_sender_id"),
        lastMessageAtRaw = at,
        lastMessageAtMillis = parseMillis(at),
        unreadCount = optInt("unread_count", 0),
        muted = optBoolean("muted", false),
    )
}

internal fun JSONArray.toConversations(): List<Conversation> =
    List(length()) { getJSONObject(it).toConversation() }

internal fun JSONObject.toReceipts(): Receipts = Receipts(
    deliveredAtMillis = parseMillis(getString("last_delivered_at")),
    readAtMillis = parseMillis(getString("last_read_at")),
)

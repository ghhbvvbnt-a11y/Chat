package com.notchat.data.remote

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatJsonTest {
    @Test fun parsesMessageWithMicrosecondTimestamp() {
        val o = JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"hello",
               "reply_to":null,"edited_at":null,"deleted_at":null,
               "created_at":"2026-11-07T10:00:00.123456+00:00"}""",
        )
        val m = o.toMessage()
        assertEquals("hello", m.body)
        assertEquals(1_794_045_600_123L, m.createdAtMillis)
        assertEquals("2026-11-07T10:00:00.123456+00:00", m.createdAtRaw)
        assertNull(m.replyTo)
        assertFalse(m.edited)
        assertFalse(m.deleted)
    }

    @Test fun flagsEditedAndDeleted() {
        val o = JSONObject(
            """{"id":"m1","conversation_id":"c1","sender_id":"u1","client_id":"k1","body":"",
               "reply_to":"m0","edited_at":"2026-11-07T10:01:00+00:00","deleted_at":"2026-11-07T10:02:00+00:00",
               "created_at":"2026-11-07T10:00:00+00:00"}""",
        )
        val m = o.toMessage()
        assertTrue(m.edited)
        assertTrue(m.deleted)
        assertEquals("m0", m.replyTo)
    }

    @Test fun parsesConversationList() {
        val arr = JSONArray(
            """[{"conversation_id":"c1","other_user_id":"u2","other_username":"sara_k",
                 "other_display_name":"Sara","other_avatar_url":null,"last_message_id":"m1",
                 "last_message_body":"hi","last_message_deleted":false,"last_message_sender_id":"u2",
                 "last_message_at":"2026-11-07T10:00:00.5+00:00","unread_count":3,"muted":false}]""",
        )
        val c = arr.toConversations().single()
        assertEquals("sara_k", c.otherUsername)
        assertEquals(3, c.unreadCount)
        assertNull(c.otherAvatarUrl)
        assertEquals(1_794_045_600_500L, c.lastMessageAtMillis)
    }

    @Test fun parsesReceipts() {
        val r = JSONObject(
            """{"last_delivered_at":"2026-11-07T10:00:05+00:00","last_read_at":"2026-11-07T10:00:01+00:00"}""",
        ).toReceipts()
        assertEquals(1_794_045_605_000L, r.deliveredAtMillis)
        assertEquals(1_794_045_601_000L, r.readAtMillis)
    }
}

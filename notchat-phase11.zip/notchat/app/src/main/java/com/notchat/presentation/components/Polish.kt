package com.notchat.presentation.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary

/** Black background with a soft green glow in one corner and a teal one in the other. */
@Composable
fun GlowBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.fillMaxSize().background(NcBackground)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(NcPrimary.copy(alpha = 0.20f), Color.Transparent),
                    center = Offset(0f, 0f), radius = 1100f,
                ),
            ),
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(NcSecondary.copy(alpha = 0.14f), Color.Transparent),
                    center = Offset(1400f, 2200f), radius = 1200f,
                ),
            ),
        )
        content()
    }
}

/** "Chatro" written with the green-to-teal brand gradient. */
@Composable
fun BrandWordmark(fontSize: TextUnit, modifier: Modifier = Modifier) {
    Text(
        text = stringResource(R.string.app_name),
        modifier = modifier,
        style = TextStyle(
            brush = Brush.horizontalGradient(listOf(NcPrimary, NcSecondary)),
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 2.sp,
        ),
    )
}

/** A moving highlight for placeholder shapes while content loads. */
fun Modifier.shimmer(): Modifier = composed {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = -400f,
        targetValue = 1400f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
        label = "shimmerX",
    )
    background(
        Brush.linearGradient(
            colors = listOf(NcCard, NcOutline.copy(alpha = 0.9f), NcCard),
            start = Offset(x, 0f),
            end = Offset(x + 400f, 0f),
        ),
    )
}

@Composable
fun ConversationSkeleton(count: Int = 7) {
    Column(Modifier.fillMaxSize()) {
        repeat(count) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(54.dp).clip(CircleShape).shimmer())
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth(0.45f).height(14.dp).clip(RoundedCornerShape(7.dp)).shimmer())
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth(0.8f).height(12.dp).clip(RoundedCornerShape(6.dp)).shimmer())
                }
            }
        }
    }
}

@Composable
fun ChatSkeleton() {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
        listOf(0.5f to false, 0.68f to true, 0.4f to false, 0.6f to true, 0.46f to false, 0.55f to true)
            .forEach { (width, mine) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
                ) {
                    Box(Modifier.fillMaxWidth(width).height(44.dp).clip(RoundedCornerShape(18.dp)).shimmer())
                }
            }
    }
}

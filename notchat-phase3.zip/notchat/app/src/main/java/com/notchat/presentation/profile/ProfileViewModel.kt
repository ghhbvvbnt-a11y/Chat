package com.notchat.presentation.profile

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProfileUiState(
    val loading: Boolean = true,
    val profile: Profile? = null,
    val notFound: Boolean = false,
    val error: AuthError? = null,
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repo: UserRepository,
) : ViewModel() {

    private val username: String = savedStateHandle.get<String>("username").orEmpty()

    private val _ui = MutableStateFlow(ProfileUiState())
    val ui: StateFlow<ProfileUiState> = _ui.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null, notFound = false) }
            when (val r = repo.profileByUsername(username)) {
                is Outcome.Success -> {
                    val p = r.value
                    _ui.value = if (p != null) ProfileUiState(loading = false, profile = p)
                    else ProfileUiState(loading = false, notFound = true)
                }
                is Outcome.Failure -> _ui.value = ProfileUiState(loading = false, error = r.error)
            }
        }
    }
}

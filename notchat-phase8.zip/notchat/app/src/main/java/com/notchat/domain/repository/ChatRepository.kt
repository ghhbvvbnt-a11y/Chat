package com.notchat.domain.repository

import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationHeader
import com.notchat.domain.model.GroupMember
import com.notchat.domain.model.LocalMedia
import com.notchat.domain.model.Message
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Receipts
import com.notchat.domain.model.ViewOnceContent
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface ChatRepository {
    /** Emits whenever the server reports a change that may affect my chats (a hint to re-fetch). */
    val changes: SharedFlow<Unit>
    val realtimeConnected: StateFlow<Boolean>

    fun startRealtime()
    fun stopRealtime()

    /** Returns the conversation id (existing or newly created). */
    suspend fun startConversation(otherUserId: String): Outcome<String>

    suspend fun conversations(): Outcome<List<Conversation>>

    /** Newest first. Pass the oldest loaded message's createdAtRaw as [beforeRaw] to page back. */
    suspend fun messages(conversationId: String, beforeRaw: String?, limit: Int): Outcome<List<Message>>

    suspend fun partnerReceipts(conversationId: String, myUserId: String): Outcome<Receipts?>

    /** Success(null) means the message already existed (a retry of an already-stored send). */
    suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        clientId: String,
        body: String,
    ): Outcome<Message?>

    /** Uploads the file, then creates the media message. Safe to retry with the same clientId. */
    suspend fun sendMedia(
        conversationId: String,
        clientId: String,
        media: LocalMedia,
        viewOnce: Boolean = false,
    ): Outcome<Unit>

    /** Opens a received view-once photo/video. Works once per receiver (see 0005 migration). */
    suspend fun openViewOnce(messageId: String): Outcome<ViewOnceContent>

    suspend fun conversationHeader(conversationId: String): Outcome<ConversationHeader>

    suspend fun members(conversationId: String): Outcome<List<GroupMember>>

    suspend fun createGroup(name: String, memberIds: List<String>): Outcome<String>

    suspend fun addMembers(conversationId: String, memberIds: List<String>): Outcome<Unit>

    suspend fun removeMember(conversationId: String, userId: String): Outcome<Unit>

    suspend fun leaveGroup(conversationId: String): Outcome<Unit>

    suspend fun renameGroup(conversationId: String, name: String): Outcome<Unit>

    /** "Delete for me": hides the message from my account only. */
    suspend fun hideMessage(messageId: String): Outcome<Unit>

    /** "Delete for everyone": sender only; erases the text and removes the files. */
    suspend fun deleteForEveryone(messageId: String): Outcome<Unit>

    /** Copies a text or media message into another conversation, marked as forwarded. */
    suspend fun forwardMessage(
        source: Message,
        targetConversationId: String,
        senderId: String,
        clientId: String,
    ): Outcome<Unit>

    suspend fun setMuted(conversationId: String, myUserId: String, muted: Boolean): Outcome<Unit>

    suspend fun markRead(conversationId: String, upToRaw: String): Outcome<Unit>
    suspend fun markDelivered(conversationId: String, upToRaw: String): Outcome<Unit>
}

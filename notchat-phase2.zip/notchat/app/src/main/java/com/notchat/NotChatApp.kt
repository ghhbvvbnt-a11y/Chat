package com.notchat

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class NotChatApp : Application()

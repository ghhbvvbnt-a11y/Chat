package com.notchat.presentation.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.notchat.core.theme.NcBackground
import com.notchat.domain.model.SessionState
import com.notchat.presentation.auth.ForgotPasswordScreen
import com.notchat.presentation.auth.LoginScreen
import com.notchat.presentation.auth.RegisterScreen
import com.notchat.presentation.home.HomeScreen
import com.notchat.presentation.session.SessionViewModel
import com.notchat.presentation.splash.SplashScreen

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT = "forgot"
    const val HOME = "home"
}

@Composable
fun NotChatNavHost() {
    val nav = rememberNavController()
    val sessionVm: SessionViewModel = hiltViewModel()
    val session by sessionVm.state.collectAsState()

    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        modifier = Modifier.background(NcBackground),
        enterTransition = { fadeIn(tween(250)) },
        exitTransition = { fadeOut(tween(250)) },
        popEnterTransition = { fadeIn(tween(250)) },
        popExitTransition = { fadeOut(tween(250)) },
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(ready = session !is SessionState.Loading) {
                val dest = if (session is SessionState.SignedIn) Routes.HOME else Routes.LOGIN
                nav.navigate(dest) { popUpTo(Routes.SPLASH) { inclusive = true } }
            }
        }
        composable(Routes.LOGIN) {
            LoginScreen(
                onNavigateRegister = { nav.navigate(Routes.REGISTER) },
                onNavigateForgot = { nav.navigate(Routes.FORGOT) },
                onSignedIn = {
                    nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
                },
            )
        }
        composable(Routes.REGISTER) {
            RegisterScreen(
                onBack = { nav.popBackStack() },
                onSignedIn = {
                    nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
                },
            )
        }
        composable(Routes.FORGOT) {
            ForgotPasswordScreen(onBack = { nav.popBackStack() })
        }
        composable(Routes.HOME) {
            HomeScreen(
                onSignedOut = {
                    nav.navigate(Routes.LOGIN) { popUpTo(Routes.HOME) { inclusive = true } }
                },
            )
        }
    }
}

package com.notchat.presentation.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import kotlin.math.cos
import kotlin.math.sin

/** Logo: an open ring (borders) with a chat bubble inside and a dot beyond the gap (beyond borders). */
@Composable
fun NotChatLogo(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val center = Offset(s / 2f, s / 2f)
        val r = s * 0.34f
        val brush = Brush.linearGradient(
            colors = listOf(NcPrimary, NcSecondary),
            start = Offset.Zero,
            end = Offset(s, s),
        )
        drawArc(
            brush = brush,
            startAngle = -20f,
            sweepAngle = 310f,
            useCenter = false,
            topLeft = Offset(center.x - r, center.y - r),
            size = Size(r * 2f, r * 2f),
            style = Stroke(width = s * 0.07f, cap = StrokeCap.Round),
        )
        val a = Math.toRadians(-45.0)
        drawCircle(
            color = NcSecondary,
            radius = s * 0.055f,
            center = Offset(
                center.x + (s * 0.47f * cos(a)).toFloat(),
                center.y + (s * 0.47f * sin(a)).toFloat(),
            ),
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(s * 0.36f, s * 0.40f),
            size = Size(s * 0.28f, s * 0.20f),
            cornerRadius = CornerRadius(s * 0.04f),
        )
        val tail = Path().apply {
            moveTo(s * 0.42f, s * 0.59f)
            lineTo(s * 0.42f, s * 0.68f)
            lineTo(s * 0.51f, s * 0.59f)
            close()
        }
        drawPath(tail, Color.White)
    }
}

package com.notchat.core.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NcColorScheme = darkColorScheme(
    primary = NcPrimary,
    onPrimary = NcTextPrimary,
    secondary = NcSecondary,
    onSecondary = NcBackground,
    background = NcBackground,
    onBackground = NcTextPrimary,
    surface = NcSurface,
    onSurface = NcTextPrimary,
    surfaceVariant = NcCard,
    onSurfaceVariant = NcTextSecondary,
    error = NcError,
    outline = NcOutline,
)

@Composable
fun NotChatTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NcColorScheme,
        typography = Typography(),
        content = content,
    )
}

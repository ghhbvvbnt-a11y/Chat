package com.notchat.presentation.auth

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.notchat.R
import com.notchat.domain.model.AuthError

fun AuthError.messageRes(): Int = when (this) {
    AuthError.NETWORK -> R.string.err_network
    AuthError.INVALID_CREDENTIALS -> R.string.err_invalid_credentials
    AuthError.EMAIL_NOT_CONFIRMED -> R.string.err_email_not_confirmed
    AuthError.EMAIL_TAKEN -> R.string.err_email_taken
    AuthError.USERNAME_TAKEN -> R.string.err_username_taken
    AuthError.WEAK_PASSWORD -> R.string.err_weak_password
    AuthError.RATE_LIMITED -> R.string.err_rate_limited
    AuthError.NOT_CONFIGURED -> R.string.err_not_configured
    AuthError.SESSION_EXPIRED -> R.string.err_session_expired
    AuthError.UNKNOWN -> R.string.err_generic
}

@Composable
fun AuthError.message(): String = stringResource(messageRes())

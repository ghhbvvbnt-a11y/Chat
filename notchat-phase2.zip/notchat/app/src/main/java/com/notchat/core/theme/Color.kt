package com.notchat.core.theme

import androidx.compose.ui.graphics.Color

val NcBackground = Color(0xFF08090D)
val NcSurface = Color(0xFF11131A)
val NcCard = Color(0xFF171A23)
val NcPrimary = Color(0xFF7957FF)
val NcSecondary = Color(0xFF00D1C1)
val NcTextPrimary = Color(0xFFFFFFFF)
val NcTextSecondary = Color(0xFF9296A5)
val NcError = Color(0xFFFF4D67)
val NcOutline = Color(0xFF2A2E3B)

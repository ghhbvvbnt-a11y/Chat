# NOT CHAT - Beyond Messages. Beyond Borders.

Android messaging app (Kotlin, Jetpack Compose, Material 3, Hilt) with a Supabase backend.

## Status
- Phase 1: branding, theme, core screens.
- Phase 2 (this version): real sign-up / sign-in / sign-out / password reset / account deletion
  against Supabase, live username check, encrypted session storage, profile loaded from the database.
- Not yet built: global search (3), chat (4), media (5), notifications/privacy (6), calls (7).

## Build secrets (GitHub -> Settings -> Secrets and variables -> Actions)
- `SUPABASE_URL`       e.g. https://<project-ref>.supabase.co
- `SUPABASE_ANON_KEY`  the publishable key (never the service_role / secret key)

## Database
Run `supabase/migrations/0001_profiles_and_auth.sql` once in Supabase -> SQL Editor.

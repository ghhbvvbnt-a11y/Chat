-- =====================================================================
-- Chatro - Migration 0009: group photos and replies
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent). Requires 0001..0008 first.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Group photo (only group admins can change it)
-- ---------------------------------------------------------------------
alter table public.conversations add column if not exists avatar_url text;

alter table public.conversations drop constraint if exists conversations_avatar_url_format;
alter table public.conversations add constraint conversations_avatar_url_format
  check (
    avatar_url is null
    or avatar_url ~ (
      '^https://[a-z0-9.-]+/storage/v1/object/public/group-avatars/' || id::text || '/avatar\.jpg(\?v=[0-9]+)?$'
    )
  );

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('group-avatars', 'group-avatars', true, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- Files live under <conversation_id>/avatar.jpg. Replacing a photo is an upsert,
-- which also needs SELECT, so members may read the folder (the files are public anyway).
drop policy if exists "group_avatars_select_member" on storage.objects;
create policy "group_avatars_select_member"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'group-avatars'
    and public.is_conversation_member(public.chat_media_conversation(name))
  );

drop policy if exists "group_avatars_insert_admin" on storage.objects;
create policy "group_avatars_insert_admin"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'group-avatars'
    and public.is_group_admin(public.chat_media_conversation(name))
  );

drop policy if exists "group_avatars_update_admin" on storage.objects;
create policy "group_avatars_update_admin"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'group-avatars'
    and public.is_group_admin(public.chat_media_conversation(name))
  )
  with check (
    bucket_id = 'group-avatars'
    and public.is_group_admin(public.chat_media_conversation(name))
  );

drop policy if exists "group_avatars_delete_admin" on storage.objects;
create policy "group_avatars_delete_admin"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'group-avatars'
    and public.is_group_admin(public.chat_media_conversation(name))
  );

create or replace function public.set_group_avatar(p_conversation uuid, p_url text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_group_admin(p_conversation) then
    raise exception 'not_admin' using errcode = '42501';
  end if;
  -- the table check constraint only accepts our own group-avatars URL
  update public.conversations set avatar_url = p_url where id = p_conversation;
end;
$$;

create or replace function public.clear_group_avatar(p_conversation uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_group_admin(p_conversation) then
    raise exception 'not_admin' using errcode = '42501';
  end if;
  update public.conversations set avatar_url = null where id = p_conversation;
end;
$$;

revoke all on function public.set_group_avatar(uuid, text) from public, anon;
revoke all on function public.clear_group_avatar(uuid) from public, anon;
grant execute on function public.set_group_avatar(uuid, text) to authenticated;
grant execute on function public.clear_group_avatar(uuid) to authenticated;

-- Group name / photo changes reach other members live.
do $$
begin
  if not exists (select 1 from pg_publication_tables
                 where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'conversations') then
    alter publication supabase_realtime add table public.conversations;
  end if;
end $$;

-- ---------------------------------------------------------------------
-- 2) Replies: a reply must point at a message of the same conversation
--    (this also keeps the anti-spam rate limit from 0003)
-- ---------------------------------------------------------------------
create or replace function public.messages_before_insert()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if (select count(*) from public.messages m
        where m.sender_id = new.sender_id
          and m.created_at > now() - interval '10 seconds') >= 20 then
    raise exception 'rate_limited';
  end if;
  if new.reply_to is not null and not exists (
       select 1 from public.messages r
        where r.id = new.reply_to and r.conversation_id = new.conversation_id) then
    raise exception 'invalid_reply' using errcode = '22023';
  end if;
  return new;
end;
$$;

-- Media messages can be replies too.
drop function if exists public.send_media_message(uuid, uuid, text, text, jsonb, boolean, boolean);

create or replace function public.send_media_message(
  p_conversation uuid,
  p_client_id uuid,
  p_kind text,
  p_body text,
  p_attachment jsonb,
  p_view_once boolean default false,
  p_forwarded boolean default false,
  p_reply_to uuid default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me uuid := (select auth.uid());
  v_id uuid;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if not public.is_conversation_member(p_conversation) then
    raise exception 'not_a_member' using errcode = '42501';
  end if;
  if p_kind not in ('image', 'video', 'audio', 'file') then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if coalesce(p_view_once, false) and p_kind not in ('image', 'video') then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if coalesce(p_view_once, false) and coalesce(p_forwarded, false) then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if (p_attachment ->> 'path') is null
     or (p_attachment ->> 'path') not like p_conversation::text || '/%' then
    raise exception 'invalid_path' using errcode = '22023';
  end if;

  insert into public.messages
    (conversation_id, sender_id, client_id, kind, body, view_once, forwarded, reply_to)
  values (p_conversation, v_me, p_client_id, p_kind, coalesce(p_body, ''),
          coalesce(p_view_once, false), coalesce(p_forwarded, false), p_reply_to)
  on conflict (sender_id, client_id) do nothing
  returning id into v_id;

  if v_id is null then            -- retry of a send that already succeeded
    select m.id into v_id from public.messages m
     where m.sender_id = v_me and m.client_id = p_client_id;
    return v_id;
  end if;

  insert into public.message_attachments
    (message_id, kind, storage_path, file_name, mime_type, size_bytes, width, height, duration_ms)
  values (
    v_id,
    p_kind,
    p_attachment ->> 'path',
    coalesce(nullif(left(p_attachment ->> 'file_name', 200), ''), 'file'),
    p_attachment ->> 'mime_type',
    coalesce((p_attachment ->> 'size_bytes')::bigint, 0),
    (p_attachment ->> 'width')::int,
    (p_attachment ->> 'height')::int,
    (p_attachment ->> 'duration_ms')::int
  );
  return v_id;
end;
$$;

revoke all on function public.send_media_message(uuid, uuid, text, text, jsonb, boolean, boolean, uuid) from public, anon;
grant execute on function public.send_media_message(uuid, uuid, text, text, jsonb, boolean, boolean, uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 3) Header and list report the group photo in the "avatar" column
-- ---------------------------------------------------------------------
drop function if exists public.get_conversation_header(uuid);

create function public.get_conversation_header(p_conversation uuid)
returns table (
  conversation_type text,
  title text,
  other_user_id uuid,
  other_username text,
  other_avatar_url text,
  member_count bigint,
  my_role text,
  muted boolean
)
language sql
stable
security invoker
set search_path = ''
as $$
  select
    c.type,
    case when c.type = 'group' then c.name else op.display_name end,
    o.user_id,
    op.username,
    case when c.type = 'group' then c.avatar_url else op.avatar_url end,
    (select count(*) from public.conversation_members x where x.conversation_id = c.id),
    me.role,
    me.muted
  from public.conversations c
  join public.conversation_members me
    on me.conversation_id = c.id and me.user_id = (select auth.uid())
  left join public.conversation_members o
    on c.type = 'direct' and o.conversation_id = c.id and o.user_id <> me.user_id
  left join public.profiles op on op.id = o.user_id
  where c.id = p_conversation;
$$;

revoke all on function public.get_conversation_header(uuid) from public, anon;
grant execute on function public.get_conversation_header(uuid) to authenticated;

drop function if exists public.list_conversations();

create function public.list_conversations()
returns table (
  conversation_id uuid,
  conversation_type text,
  title text,
  other_user_id uuid,
  other_username text,
  other_avatar_url text,
  last_message_id uuid,
  last_message_body text,
  last_message_kind text,
  last_message_deleted boolean,
  last_message_sender_id uuid,
  last_message_sender_name text,
  last_message_at timestamptz,
  unread_count bigint,
  muted boolean,
  member_count bigint,
  other_online boolean,
  other_last_seen_at timestamptz
)
language sql
stable
security invoker
set search_path = ''
as $$
  select
    c.id,
    c.type,
    case when c.type = 'group' then c.name else p.display_name end,
    o.user_id,
    p.username,
    case when c.type = 'group' then c.avatar_url else p.avatar_url end,
    lm.id,
    lm.body,
    lm.kind,
    (lm.deleted_at is not null),
    lm.sender_id,
    sp.display_name,
    coalesce(lm.created_at, c.created_at),
    (select count(*) from public.messages m
       where m.conversation_id = c.id
         and m.sender_id <> me.user_id
         and m.deleted_at is null
         and m.created_at > me.last_read_at),
    me.muted,
    (select count(*) from public.conversation_members x where x.conversation_id = c.id),
    (select pr.online from public.presence_of(o.user_id) pr),
    (select pr.last_seen_at from public.presence_of(o.user_id) pr)
  from public.conversation_members me
  join public.conversations c on c.id = me.conversation_id
  left join public.conversation_members o
    on c.type = 'direct' and o.conversation_id = c.id and o.user_id <> me.user_id
  left join public.profiles p on p.id = o.user_id
  left join lateral (
    select m.* from public.messages m
    where m.conversation_id = c.id
    order by m.created_at desc, m.id desc
    limit 1
  ) lm on true
  left join public.profiles sp on sp.id = lm.sender_id
  where me.user_id = (select auth.uid())
    and (c.type = 'group' or lm.id is not null)
  order by coalesce(lm.created_at, c.created_at) desc;
$$;

revoke all on function public.list_conversations() from public, anon;
grant execute on function public.list_conversations() to authenticated;

-- =====================================================================
-- Quick checks (run separately after the migration):
--   select column_name from information_schema.columns
--     where table_name = 'conversations' and column_name = 'avatar_url';   -- 1 row
--   select id, public from storage.buckets where id = 'group-avatars';     -- public = true
-- =====================================================================

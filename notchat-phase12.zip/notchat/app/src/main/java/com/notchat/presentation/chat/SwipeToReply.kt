package com.notchat.presentation.chat

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Reply
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.notchat.core.theme.NcPrimary
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Lets the user drag a message sideways to reply to it (to the right in left-to-right layouts,
 * to the left in right-to-left ones). A buzz tells you when it is far enough; letting go replies.
 */
@Composable
fun SwipeToReplyBox(
    enabled: Boolean,
    onReply: () -> Unit,
    content: @Composable () -> Unit,
) {
    if (!enabled) {
        content()
        return
    }
    val density = LocalDensity.current
    val maxPx = with(density) { 84.dp.toPx() }
    val triggerPx = with(density) { 60.dp.toPx() }
    val direction = if (LocalLayoutDirection.current == LayoutDirection.Rtl) -1f else 1f
    val offset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var buzzed by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxWidth()) {
        Icon(
            Icons.AutoMirrored.Outlined.Reply,
            contentDescription = null,
            tint = NcPrimary,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 14.dp)
                .size(22.dp)
                .graphicsLayer {
                    val p = (offset.value / triggerPx).coerceIn(0f, 1f)
                    alpha = p
                    scaleX = 0.6f + 0.4f * p
                    scaleY = 0.6f + 0.4f * p
                },
        )
        Box(
            Modifier
                .offset { IntOffset((offset.value * direction).roundToInt(), 0) }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { buzzed = false },
                        onHorizontalDrag = { change, amount ->
                            val next = (offset.value + amount * direction).coerceIn(0f, maxPx)
                            if (next != offset.value) {
                                change.consume()
                                scope.launch { offset.snapTo(next) }
                            }
                            if (!buzzed && next >= triggerPx) {
                                buzzed = true
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        },
                        onDragEnd = {
                            if (offset.value >= triggerPx) onReply()
                            scope.launch { offset.animateTo(0f, spring()) }
                        },
                        onDragCancel = { scope.launch { offset.animateTo(0f, spring()) } },
                    )
                },
        ) { content() }
    }
}

package com.notchat.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOnPrimary
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.model.Profile
import com.notchat.presentation.auth.message
import com.notchat.presentation.chat.AppearanceDialog
import com.notchat.presentation.chat.ChatLockViewModel
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.glass
import com.notchat.presentation.lock.PinCreateDialog
import com.notchat.presentation.lock.PinVerifyDialog
import com.notchat.presentation.util.shareAccount
import kotlinx.coroutines.launch

/** Profile card on top, then settings grouped into Privacy, Notifications, Appearance and Account. */
@Composable
fun SettingsTab(
    state: HomeUiState,
    lockVm: ChatLockViewModel,
    onRetry: () -> Unit,
    onEditProfile: () -> Unit,
    presenceSharing: Boolean,
    onTogglePresence: (Boolean) -> Unit,
    notificationsEnabled: Boolean,
    notificationsBlocked: Boolean,
    onToggleNotifications: (Boolean) -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit,
) {
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var showAppearance by rememberSaveable { mutableStateOf(false) }
    var pinFlow by rememberSaveable { mutableIntStateOf(0) } // 0 none, 1 verify to change, 2 new PIN, 3 verify to remove
    val pinSet by lockVm.pinSet.collectAsState()
    val pinScope = rememberCoroutineScope()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        val profile = state.profile
        when {
            profile != null -> ProfileHeader(
                profile = profile,
                onEdit = onEditProfile,
                onShare = { shareAccount(context, profile.username) },
            )
            state.loading -> Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NcPrimary)
            }
            else -> Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcCard, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    state.error?.message() ?: stringResource(R.string.profile_load_failed),
                    color = NcError, fontSize = 14.sp,
                )
                TextButton(onClick = onRetry) { Text(stringResource(R.string.retry), color = NcSecondary) }
            }
        }

        SettingsSection(stringResource(R.string.settings_privacy)) {
            SettingsRow(
                icon = Icons.Outlined.Visibility,
                title = stringResource(R.string.presence_setting),
                subtitle = stringResource(R.string.presence_setting_hint),
                divider = false,
                trailing = {
                    Switch(
                        checked = presenceSharing,
                        onCheckedChange = onTogglePresence,
                        colors = SwitchDefaults.colors(checkedTrackColor = NcPrimary, checkedThumbColor = NcOnPrimary),
                    )
                },
            )
            if (pinSet) {
                SettingsRow(
                    icon = Icons.Outlined.Lock,
                    title = stringResource(R.string.pin_change),
                    onClick = { pinFlow = 1 },
                )
                SettingsRow(
                    icon = Icons.Outlined.LockOpen,
                    title = stringResource(R.string.pin_remove),
                    tint = NcError,
                    onClick = { pinFlow = 3 },
                )
            } else {
                SettingsRow(
                    icon = Icons.Outlined.Lock,
                    title = stringResource(R.string.chat_lock),
                    subtitle = stringResource(R.string.settings_chat_lock_hint),
                )
            }
        }

        SettingsSection(stringResource(R.string.settings_notifications)) {
            SettingsRow(
                icon = Icons.Outlined.Notifications,
                title = stringResource(R.string.notifications_setting),
                subtitle = if (notificationsBlocked) stringResource(R.string.notifications_blocked) else null,
                subtitleColor = NcError,
                divider = false,
                trailing = {
                    Switch(
                        checked = notificationsEnabled,
                        onCheckedChange = onToggleNotifications,
                        colors = SwitchDefaults.colors(checkedTrackColor = NcPrimary, checkedThumbColor = NcOnPrimary),
                    )
                },
            )
        }

        SettingsSection(stringResource(R.string.settings_appearance)) {
            SettingsRow(
                icon = Icons.Outlined.Palette,
                title = stringResource(R.string.chat_appearance),
                divider = false,
                onClick = { showAppearance = true },
            )
        }

        SettingsSection(stringResource(R.string.settings_account)) {
            SettingsRow(
                icon = Icons.AutoMirrored.Outlined.Logout,
                title = stringResource(R.string.sign_out),
                divider = false,
                onClick = onSignOut,
            )
            SettingsRow(
                icon = Icons.Outlined.DeleteForever,
                title = stringResource(R.string.delete_account),
                tint = NcError,
                onClick = { confirmDelete = true },
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    if (showAppearance) AppearanceDialog(onDismiss = { showAppearance = false })

    when (pinFlow) {
        1 -> PinVerifyDialog(
            title = stringResource(R.string.pin_enter_current),
            subtitle = null,
            onDismiss = { pinFlow = 0 },
            verify = lockVm::verify,
            remainingMillis = lockVm::lockoutRemainingMillis,
            onVerified = { pinFlow = 2 },
        )
        2 -> PinCreateDialog(
            onDismiss = { pinFlow = 0 },
            onCreated = { pin ->
                pinScope.launch { lockVm.setPin(pin) }
                pinFlow = 0
            },
        )
        3 -> PinVerifyDialog(
            title = stringResource(R.string.pin_enter_current),
            subtitle = stringResource(R.string.pin_remove_warning),
            onDismiss = { pinFlow = 0 },
            verify = lockVm::verify,
            remainingMillis = lockVm::lockoutRemainingMillis,
            onVerified = {
                lockVm.removePin()
                pinFlow = 0
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            textContentColor = NcTextSecondary,
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDeleteAccount()
                }) { Text(stringResource(R.string.delete), color = NcError) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(stringResource(R.string.cancel), color = NcTextPrimary)
                }
            },
        )
    }
}

@Composable
private fun ProfileHeader(profile: Profile, onEdit: () -> Unit, onShare: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .glass(shape)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AvatarInitial(profile.displayName, size = 88.dp, imageUrl = profile.avatarUrl)
        Spacer(Modifier.height(12.dp))
        Text(profile.displayName, color = NcTextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("@${profile.username}", color = NcSecondary, fontSize = 14.sp)
        profile.country?.let { Text(it, color = NcTextSecondary, fontSize = 12.sp) }
        if (profile.bio.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(profile.bio, color = NcTextSecondary, fontSize = 14.sp)
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                GradientButton(text = stringResource(R.string.edit_profile), onClick = onEdit)
            }
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(NcBackgroundSoft)
                    .border(1.dp, NcOutline, CircleShape)
                    .clickable(onClick = onShare),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Outlined.Share,
                    contentDescription = stringResource(R.string.share_account),
                    tint = NcPrimary,
                )
            }
        }
    }
}

private val NcBackgroundSoft = Color(0xFF0B1112)

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column {
        Text(
            title.uppercase(),
            color = NcTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 6.dp, bottom = 8.dp),
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glass(shape),
        ) { content() }
    }
}

@Composable
private fun SettingsRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    subtitleColor: Color = NcTextSecondary,
    tint: Color = NcTextPrimary,
    divider: Boolean = true,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    if (divider) HorizontalDivider(Modifier.padding(start = 66.dp), color = NcOutline.copy(alpha = 0.6f))
    val accent = if (tint == NcTextPrimary) NcPrimary else tint
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier.size(36.dp).background(accent.copy(alpha = 0.14f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = tint, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, color = subtitleColor, fontSize = 12.sp)
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

package com.notchat.data.repository

import com.notchat.data.remote.AuthorizedApi
import com.notchat.data.remote.RealtimeClient
import com.notchat.data.remote.toConversations
import com.notchat.data.remote.toGroupMembers
import com.notchat.data.remote.toHeader
import com.notchat.data.remote.toMessage
import com.notchat.data.remote.toMessages
import com.notchat.data.remote.parseSignedUrls
import com.notchat.data.remote.toReceipts
import com.notchat.data.remote.toReplyPreview
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationHeader
import com.notchat.domain.model.GroupMember
import com.notchat.domain.model.LocalMedia
import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Receipts
import com.notchat.domain.model.ReplyPreview
import com.notchat.domain.model.TypingEvent
import com.notchat.domain.model.TypingState
import com.notchat.domain.model.ViewOnceContent
import com.notchat.domain.ChatLogic
import com.notchat.domain.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val api: AuthorizedApi,
    private val realtime: RealtimeClient,
) : ChatRepository {

    private val http get() = api.http

    private class SignedUrl(val url: String, val expiresAtMillis: Long)

    private val signedUrls = ConcurrentHashMap<String, SignedUrl>()

    override val changes: SharedFlow<Unit> = realtime.changes
    override val realtimeConnected: StateFlow<Boolean> = realtime.connected

    override val typingEvents: SharedFlow<TypingEvent> = realtime.typing

    override fun joinTyping(conversationId: String) = realtime.joinTyping(conversationId)
    override fun leaveTyping(conversationId: String) = realtime.leaveTyping(conversationId)
    override fun sendTyping(conversationId: String, userId: String, state: TypingState) =
        realtime.sendTyping(conversationId, userId, state)

    override fun startRealtime() = realtime.start()
    override fun stopRealtime() = realtime.stop()

    override suspend fun startConversation(otherUserId: String): Outcome<String> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/get_or_create_direct_conversation",
            JSONObject().put("p_other", otherUserId),
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(r.body.trim().trim('"')) else api.failure(r)
    }

    override suspend fun conversations(): Outcome<List<Conversation>> = api.call { token ->
        val r = http.request("POST", "/rest/v1/rpc/list_conversations", accessToken = token)
        if (r.code in 200..299) Outcome.Success(JSONArray(r.body).toConversations()) else api.failure(r)
    }

    private val _schemaOutdated = MutableStateFlow(false)
    override val schemaOutdated: StateFlow<Boolean> = _schemaOutdated.asStateFlow()

    override suspend fun messages(
        conversationId: String,
        beforeRaw: String?,
        limit: Int,
    ): Outcome<List<Message>> = api.call { token ->
        val before = beforeRaw?.let { "&created_at=lt." + URLEncoder.encode(it, "UTF-8") }.orEmpty()
        val base = "/rest/v1/messages?conversation_id=eq.$conversationId"
        val tail = "&order=created_at.desc,id.desc&limit=$limit$before"
        var r = http.request("GET", "$base&select=$FULL_SELECT$tail", accessToken = token)
        var full = true
        if (r.code == 400 && looksLikeMissingSchema(r.body)) {
            // The database is missing a later SQL update: still show the chat with the basics.
            r = http.request("GET", "$base&select=$BASIC_SELECT$tail", accessToken = token)
            full = false
        }
        if (r.code !in 200..299) return@call api.failure(r)
        _schemaOutdated.value = !full
        val messages = JSONArray(r.body).toMessages()
        Outcome.Success(withSignedUrls(withReplies(messages, token, full), token))
    }

    private fun looksLikeMissingSchema(body: String): Boolean =
        listOf("does not exist", "Could not find", "PGRST200", "42703", "schema cache").any { body.contains(it) }

    /** Fills in the quoted message of each reply with one extra query (no table self-join needed). */
    private suspend fun withReplies(messages: List<Message>, token: String, full: Boolean): List<Message> {
        val onPage = messages.associateBy { it.id }
        val missing = messages.mapNotNull { it.replyTo }.filter { it !in onPage }.distinct()
        val fetched = HashMap<String, ReplyPreview>()
        if (missing.isNotEmpty()) {
            try {
                val cols = if (full) "id,sender_id,body,kind,deleted_at" else "id,sender_id,body,deleted_at"
                val r = http.request(
                    "GET",
                    "/rest/v1/messages?id=in.(${missing.joinToString(",")})&select=$cols",
                    accessToken = token,
                )
                if (r.code in 200..299) {
                    val rows = JSONArray(r.body)
                    for (i in 0 until rows.length()) {
                        val p = rows.getJSONObject(i).toReplyPreview()
                        fetched[p.messageId] = p
                    }
                }
            } catch (e: java.io.IOException) {
                // Replies still load, just without the quoted text.
            } catch (e: org.json.JSONException) {
                // Same.
            }
        }
        return messages.map { m ->
            val id = m.replyTo ?: return@map m
            val onThisPage = onPage[id]?.let { ReplyPreview(it.id, it.senderId, it.body, it.kind, it.deleted) }
            m.copy(reply = onThisPage ?: fetched[id])
        }
    }

    override suspend fun partnerReceipts(conversationId: String, myUserId: String): Outcome<Receipts?> =
        api.call { token ->
            val path = "/rest/v1/conversation_members?conversation_id=eq.$conversationId" +
                "&user_id=neq.$myUserId&select=last_delivered_at,last_read_at"
            val r = http.request("GET", path, accessToken = token)
            if (r.code in 200..299) {
                val arr = JSONArray(r.body)
                Outcome.Success(
                    ChatLogic.combineReceipts(List(arr.length()) { arr.getJSONObject(it).toReceipts() }),
                )
            } else {
                api.failure(r)
            }
        }

    override suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        clientId: String,
        body: String,
        replyTo: String?,
    ): Outcome<Message?> = api.call { token ->
        insertText(token, conversationId, senderId, clientId, body, forwarded = false, replyTo = replyTo)
    }

    private suspend fun insertText(
        token: String,
        conversationId: String,
        senderId: String,
        clientId: String,
        body: String,
        forwarded: Boolean,
        replyTo: String? = null,
    ): Outcome<Message?> {
        val json = JSONObject()
            .put("conversation_id", conversationId)
            .put("sender_id", senderId)
            .put("client_id", clientId)
            .put("body", body)
        if (forwarded) json.put("forwarded", true)
        if (replyTo != null) json.put("reply_to", replyTo)
        val r = http.request(
            "POST",
            "/rest/v1/messages",
            json,
            accessToken = token,
            headers = mapOf("Prefer" to "return=representation"),
        )
        return when {
            r.code in 200..299 -> Outcome.Success(JSONArray(r.body).getJSONObject(0).toMessage())
            // 409 = unique (sender_id, client_id): this exact send was already stored earlier.
            r.code == 409 -> Outcome.Success(null)
            else -> api.failure(r)
        }
    }

    override suspend fun sendMedia(
        conversationId: String,
        clientId: String,
        media: LocalMedia,
        viewOnce: Boolean,
        replyTo: String?,
    ): Outcome<Unit> = api.call { token ->
        val ext = media.fileName.substringAfterLast('.', "").lowercase()
            .filter { it.isLetterOrDigit() }.take(8).ifEmpty { "bin" }
        // Deterministic path: a retry overwrites the same object instead of leaving orphans.
        val path = "$conversationId/$clientId/file.$ext"
        val bucket = if (viewOnce) ONCE_BUCKET else MEDIA_BUCKET
        val up = http.upload("/storage/v1/object/$bucket/$path", media.file, media.mimeType, token)
        if (up.code !in 200..299) return@call api.failure(up)

        val attachment = JSONObject()
            .put("path", path)
            .put("file_name", media.fileName)
            .put("mime_type", media.mimeType)
            .put("size_bytes", media.sizeBytes)
        media.width?.let { attachment.put("width", it) }
        media.height?.let { attachment.put("height", it) }
        media.durationMs?.let { attachment.put("duration_ms", it) }

        val r = http.request(
            "POST",
            "/rest/v1/rpc/send_media_message",
            JSONObject()
                .put("p_conversation", conversationId)
                .put("p_client_id", clientId)
                .put("p_kind", media.kind.wire)
                .put("p_body", "")
                .put("p_attachment", attachment)
                .put("p_view_once", viewOnce)
                .apply { if (replyTo != null) put("p_reply_to", replyTo) },
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
    }

    override suspend fun openViewOnce(messageId: String): Outcome<ViewOnceContent> = api.call { token ->
        val r = http.request(
            "POST",
            "/rest/v1/rpc/open_view_once_message",
            JSONObject().put("p_message", messageId),
            accessToken = token,
        )
        if (r.code !in 200..299) return@call api.failure(r)
        val info = JSONObject(r.body)
        val path = info.getString("path")
        val s = http.request(
            "POST",
            "/storage/v1/object/sign/$ONCE_BUCKET/$path",
            JSONObject().put("expiresIn", VIEW_ONCE_URL_SECONDS),
            accessToken = token,
        )
        if (s.code !in 200..299) return@call api.failure(s)
        val signed = JSONObject(s.body).getString("signedURL")
        Outcome.Success(
            ViewOnceContent(
                url = http.publicBaseUrl().trimEnd('/') + "/storage/v1" + signed,
                kind = MessageKind.fromWire(info.optString("kind")),
                mimeType = info.optString("mime_type"),
            ),
        )
    }

    /** Attaches short-lived signed URLs (cached) so the UI can load private files. */
    private suspend fun withSignedUrls(messages: List<Message>, token: String): List<Message> {
        val now = System.currentTimeMillis()
        // View-once files live in another bucket and are never pre-signed.
        val needed = messages.filterNot { it.viewOnce }.flatMap { it.attachments }.map { it.storagePath }.distinct()
            .filter { (signedUrls[it]?.expiresAtMillis ?: 0L) - now < REFRESH_MARGIN_MS }
        if (needed.isNotEmpty()) {
            try {
                val body = JSONObject()
                    .put("expiresIn", URL_TTL_SECONDS)
                    .put("paths", JSONArray(needed))
                val r = http.request("POST", "/storage/v1/object/sign/chat-media", body, accessToken = token)
                if (r.code in 200..299) {
                    val expires = now + URL_TTL_SECONDS * 1000L
                    parseSignedUrls(r.body, http.publicBaseUrl()).forEach { (path, url) ->
                        signedUrls[path] = SignedUrl(url, expires)
                    }
                }
            } catch (e: java.io.IOException) {
                // Messages still load; media shows a placeholder until the next refresh.
            } catch (e: org.json.JSONException) {
                // Same as above.
            }
        }
        return messages.map { m ->
            if (m.attachments.isEmpty() || m.viewOnce) m
            else m.copy(attachments = m.attachments.map { a -> a.copy(url = signedUrls[a.storagePath]?.url) })
        }
    }

    override suspend fun conversationHeader(conversationId: String): Outcome<ConversationHeader> =
        api.call { token ->
            val r = http.request(
                "POST", "/rest/v1/rpc/get_conversation_header",
                JSONObject().put("p_conversation", conversationId), accessToken = token,
            )
            if (r.code !in 200..299) return@call api.failure(r)
            val rows = JSONArray(r.body)
            if (rows.length() == 0) Outcome.Failure(AuthError.UNKNOWN)
            else Outcome.Success(rows.getJSONObject(0).toHeader())
        }

    override suspend fun members(conversationId: String): Outcome<List<GroupMember>> = api.call { token ->
        val r = http.request(
            "POST", "/rest/v1/rpc/list_conversation_members",
            JSONObject().put("p_conversation", conversationId), accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(JSONArray(r.body).toGroupMembers()) else api.failure(r)
    }

    override suspend fun createGroup(name: String, memberIds: List<String>): Outcome<String> = api.call { token ->
        val r = http.request(
            "POST", "/rest/v1/rpc/create_group",
            JSONObject().put("p_name", name.trim()).put("p_members", JSONArray(memberIds)),
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(r.body.trim().trim('"')) else api.failure(r)
    }

    override suspend fun addMembers(conversationId: String, memberIds: List<String>): Outcome<Unit> =
        rpcUnit(
            "add_group_members",
            JSONObject().put("p_conversation", conversationId).put("p_members", JSONArray(memberIds)),
        )

    override suspend fun removeMember(conversationId: String, userId: String): Outcome<Unit> =
        rpcUnit(
            "remove_group_member",
            JSONObject().put("p_conversation", conversationId).put("p_user", userId),
        )

    override suspend fun leaveGroup(conversationId: String): Outcome<Unit> =
        rpcUnit("leave_group", JSONObject().put("p_conversation", conversationId))

    override suspend fun renameGroup(conversationId: String, name: String): Outcome<Unit> =
        rpcUnit(
            "rename_group",
            JSONObject().put("p_conversation", conversationId).put("p_name", name.trim()),
        )

    override suspend fun setGroupAvatar(conversationId: String, file: java.io.File): Outcome<Unit> =
        api.call { token ->
            val path = "$conversationId/avatar.jpg"
            val up = http.upload("/storage/v1/object/group-avatars/$path", file, "image/jpeg", token)
            if (up.code !in 200..299) return@call api.failure(up)
            // "?v=" busts image caches when the photo is replaced; the database only accepts this exact shape.
            val url = "${http.publicBaseUrl().trimEnd('/')}/storage/v1/object/public/group-avatars/$path" +
                "?v=${System.currentTimeMillis()}"
            val r = http.request(
                "POST", "/rest/v1/rpc/set_group_avatar",
                JSONObject().put("p_conversation", conversationId).put("p_url", url),
                accessToken = token,
            )
            if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
        }

    override suspend fun removeGroupAvatar(conversationId: String): Outcome<Unit> = api.call { token ->
        val r = http.request(
            "POST", "/rest/v1/rpc/clear_group_avatar",
            JSONObject().put("p_conversation", conversationId), accessToken = token,
        )
        if (r.code !in 200..299) return@call api.failure(r)
        // Best effort: also remove the stored file.
        try {
            http.request("DELETE", "/storage/v1/object/group-avatars/$conversationId/avatar.jpg", accessToken = token)
        } catch (e: java.io.IOException) {
            // ignored
        }
        Outcome.Success(Unit)
    }

    private suspend fun rpcUnit(function: String, body: JSONObject): Outcome<Unit> = api.call { token ->
        val r = http.request("POST", "/rest/v1/rpc/$function", body, accessToken = token)
        if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
    }

    override suspend fun hideMessage(messageId: String): Outcome<Unit> =
        rpcUnit("hide_message", JSONObject().put("p_message", messageId))

    override suspend fun deleteForEveryone(messageId: String): Outcome<Unit> = api.call { token ->
        val r = http.request(
            "POST", "/rest/v1/rpc/delete_message_for_everyone",
            JSONObject().put("p_message", messageId), accessToken = token,
        )
        if (r.code !in 200..299) return@call api.failure(r)
        // The message is already erased; removing its files is best effort.
        val files = JSONArray(r.body)
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            try {
                http.request(
                    "DELETE",
                    "/storage/v1/object/${f.getString("bucket")}/${f.getString("path")}",
                    accessToken = token,
                )
            } catch (e: java.io.IOException) {
                // ignored
            }
        }
        Outcome.Success(Unit)
    }

    override suspend fun forwardMessage(
        source: Message,
        targetConversationId: String,
        senderId: String,
        clientId: String,
    ): Outcome<Unit> = api.call { token ->
        if (source.viewOnce || source.deleted) return@call Outcome.Failure(AuthError.NOT_ALLOWED)
        if (source.kind == MessageKind.TEXT) {
            val r = insertText(token, targetConversationId, senderId, clientId, source.body, forwarded = true)
            return@call if (r is Outcome.Failure) r else Outcome.Success(Unit)
        }
        val a = source.attachments.firstOrNull() ?: return@call Outcome.Failure(AuthError.UNKNOWN)
        val ext = a.storagePath.substringAfterLast('.', "bin")
        val newPath = "$targetConversationId/$clientId/file.$ext"
        val copy = http.request(
            "POST", "/storage/v1/object/copy",
            JSONObject()
                .put("bucketId", MEDIA_BUCKET)
                .put("sourceKey", a.storagePath)
                .put("destinationKey", newPath),
            accessToken = token,
        )
        // 409: a previous attempt already copied the file; the message insert below is idempotent.
        if (copy.code !in 200..299 && copy.code != 409) return@call api.failure(copy)

        val attachment = JSONObject()
            .put("path", newPath)
            .put("file_name", a.fileName)
            .put("mime_type", a.mimeType)
            .put("size_bytes", a.sizeBytes)
        a.width?.let { attachment.put("width", it) }
        a.height?.let { attachment.put("height", it) }
        a.durationMs?.let { attachment.put("duration_ms", it) }
        val r = http.request(
            "POST", "/rest/v1/rpc/send_media_message",
            JSONObject()
                .put("p_conversation", targetConversationId)
                .put("p_client_id", clientId)
                .put("p_kind", source.kind.wire)
                .put("p_body", "")
                .put("p_attachment", attachment)
                .put("p_view_once", false)
                .put("p_forwarded", true),
            accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
    }

    override suspend fun setMuted(conversationId: String, myUserId: String, muted: Boolean): Outcome<Unit> =
        api.call { token ->
            val r = http.request(
                "PATCH",
                "/rest/v1/conversation_members?conversation_id=eq.$conversationId&user_id=eq.$myUserId",
                JSONObject().put("muted", muted),
                accessToken = token,
            )
            if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
        }

    override suspend fun markRead(conversationId: String, upToRaw: String): Outcome<Unit> =
        rpcMark("mark_conversation_read", conversationId, upToRaw)

    override suspend fun markDelivered(conversationId: String, upToRaw: String): Outcome<Unit> =
        rpcMark("mark_conversation_delivered", conversationId, upToRaw)

    private suspend fun rpcMark(function: String, conversationId: String, upToRaw: String): Outcome<Unit> =
        api.call { token ->
            val r = http.request(
                "POST",
                "/rest/v1/rpc/$function",
                JSONObject().put("p_conversation", conversationId).put("p_up_to", upToRaw),
                accessToken = token,
            )
            if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
        }

    private companion object {
        const val FULL_SELECT = "id,conversation_id,sender_id,client_id,body,kind,view_once,forwarded,reply_to," +
            "edited_at,deleted_at,created_at,message_views(viewer_id)," +
            "message_attachments(id,kind,storage_path,file_name,mime_type,size_bytes,width,height,duration_ms)"
        const val BASIC_SELECT = "id,conversation_id,sender_id,client_id,body,reply_to,edited_at,deleted_at,created_at"
        const val URL_TTL_SECONDS = 4 * 60 * 60
        const val REFRESH_MARGIN_MS = 10 * 60 * 1000L
        const val VIEW_ONCE_URL_SECONDS = 120
        const val MEDIA_BUCKET = "chat-media"
        const val ONCE_BUCKET = "chat-media-once"
    }
}

package com.notchat.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcOnPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcTextSecondary

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
) {
    val active = enabled && !loading
    val brush = if (enabled) {
        Brush.horizontalGradient(listOf(NcPrimary, NcSecondary))
    } else {
        Brush.horizontalGradient(listOf(NcCard, NcCard))
    }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(brush)
            .clickable(enabled = active, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = NcOnPrimary,
                strokeWidth = 2.dp,
            )
        } else {
            Text(
                text = text,
                color = if (enabled) NcOnPrimary else NcTextSecondary,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

package com.notchat.domain.model

import java.io.File

enum class MessageStatus { SENDING, FAILED, SENT, DELIVERED, READ }

enum class MessageKind(val wire: String) {
    TEXT("text"),
    IMAGE("image"),
    VIDEO("video"),
    AUDIO("audio"),
    FILE("file");

    companion object {
        fun fromWire(value: String?): MessageKind = entries.firstOrNull { it.wire == value } ?: TEXT

        fun fromMime(mime: String): MessageKind = when {
            mime.startsWith("image/") -> IMAGE
            mime.startsWith("video/") -> VIDEO
            mime.startsWith("audio/") -> AUDIO
            else -> FILE
        }
    }
}

data class Attachment(
    val id: String,
    val kind: MessageKind,
    val storagePath: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val width: Int?,
    val height: Int?,
    val durationMs: Int?,
    /** Short-lived signed URL (or a local file URI while the upload is pending). */
    val url: String? = null,
)

/** A file prepared on this device (compressed / copied to cache) and ready to upload. */
data class LocalMedia(
    val file: File,
    val kind: MessageKind,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val width: Int?,
    val height: Int?,
    val durationMs: Int?,
)

data class Message(
    val id: String,
    val clientId: String,
    val conversationId: String,
    val senderId: String,
    val body: String,
    /** Exact server timestamp text, reused as a pagination cursor (keeps microsecond precision). */
    val createdAtRaw: String,
    val createdAtMillis: Long,
    val replyTo: String?,
    val edited: Boolean,
    val deleted: Boolean,
    val kind: MessageKind = MessageKind.TEXT,
    val attachments: List<Attachment> = emptyList(),
    /** Photo/video that each receiver can open only once. */
    val viewOnce: Boolean = false,
    /** User ids that already opened this view-once message (visible to the sender and to themselves). */
    val viewedBy: Set<String> = emptySet(),
    val forwarded: Boolean = false,
    /** The message this one answers (null if it is not a reply, or the original is not visible). */
    val reply: ReplyPreview? = null,
)

/** A message as shown on screen. */
data class ChatMessage(
    val message: Message,
    val status: MessageStatus,
    val mine: Boolean,
    val viewedByMe: Boolean = false,
    val viewedByOther: Boolean = false,
    /** Sender's name, shown above messages from other people in a group. */
    val senderName: String? = null,
    /** Who wrote the quoted message ("You", or a name), when this message is a reply. */
    val replyName: String? = null,
    val replyMine: Boolean = false,
)

/** Temporary access to a view-once file (valid for about two minutes). */
data class ViewOnceContent(val url: String, val kind: MessageKind, val mimeType: String)

/** How far the other person's device has received / read, as server times in epoch millis. */
data class Receipts(val deliveredAtMillis: Long, val readAtMillis: Long)

enum class ConversationType { DIRECT, GROUP }

enum class MemberRole { ADMIN, MEMBER }

data class Conversation(
    val id: String,
    val type: ConversationType,
    /** Group name, or the other person's display name in a direct chat. */
    val title: String,
    val otherUserId: String?,
    val otherUsername: String?,
    val otherAvatarUrl: String?,
    val lastMessageBody: String,
    val lastMessageDeleted: Boolean,
    val lastMessageSenderId: String?,
    val lastMessageSenderName: String?,
    val lastMessageAtRaw: String,
    val lastMessageAtMillis: Long,
    val unreadCount: Int,
    val muted: Boolean,
    val memberCount: Int,
    /** False for a freshly created group nobody has written in yet. */
    val hasMessages: Boolean,
    val lastMessageKind: MessageKind = MessageKind.TEXT,
    val otherOnline: Boolean = false,
    val otherLastSeenMillis: Long? = null,
)

/** What the chat screen needs to know about a conversation. */
data class ConversationHeader(
    val type: ConversationType,
    val title: String,
    val otherUserId: String?,
    val otherUsername: String?,
    val otherAvatarUrl: String?,
    val memberCount: Int,
    val myRole: MemberRole,
    val muted: Boolean = false,
)

data class GroupMember(
    val userId: String,
    val username: String,
    val displayName: String,
    val avatarUrl: String?,
    val role: MemberRole,
)

/** Whether the other person is online right now, or when they were last seen. */
data class Presence(val online: Boolean, val lastSeenMillis: Long)

/** What a person is doing in the composer; shared live with the other side of the chat. */
enum class TypingState(val wire: String) {
    IDLE("idle"), TYPING("typing"), RECORDING("recording");

    companion object {
        fun fromWire(value: String?): TypingState = entries.firstOrNull { it.wire == value } ?: IDLE
    }
}

data class TypingEvent(val conversationId: String, val userId: String, val state: TypingState)

/** What the "typing…" bubble at the bottom of the chat shows. */
data class TypingUi(val state: TypingState, val names: List<String>)

/** Result of entering the chat PIN. */
sealed interface PinResult {
    data object Ok : PinResult
    data class Wrong(val attemptsLeft: Int) : PinResult
    data class LockedOut(val untilMillis: Long) : PinResult
}

/** The quoted part of a reply: enough to show who said what, without loading the whole message. */
data class ReplyPreview(
    val messageId: String,
    val senderId: String,
    val body: String,
    val kind: MessageKind,
    val deleted: Boolean,
)

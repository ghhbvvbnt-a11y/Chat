package com.notchat.presentation.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary

/**
 * "Liquid glass" panel: a frosted translucent fill, a soft light across the top edge and a
 * thin border that is bright on the top-left and fades out. It is a visual imitation (the
 * background is not blurred), so the colourful moving background behind it shows through.
 */
fun Modifier.glass(shape: Shape, strength: Float = 1f): Modifier = this
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.15f * strength),
                Color.White.copy(alpha = 0.06f * strength),
            ),
        ),
    )
    .drawBehind {
        drawRect(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.12f * strength), Color.Transparent),
                endY = size.height * 0.5f,
            ),
        )
    }
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.55f),
                Color.White.copy(alpha = 0.06f),
                Color.White.copy(alpha = 0.22f),
            ),
        ),
        shape,
    )

/** A glossy highlight and bright rim on top of a solid or gradient fill (your own message bubbles). */
fun Modifier.glossy(shape: Shape): Modifier = this
    .clip(shape)
    .drawBehind {
        drawRect(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.26f), Color.Transparent),
                endY = size.height * 0.55f,
            ),
        )
    }
    .border(
        1.dp,
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f))),
        shape,
    )

/** Dark base with three large soft colour orbs that drift slowly, so glass has something to catch. */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier.fillMaxSize()) {
    val transition = rememberInfiniteTransition(label = "liquid")
    val a by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(18_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "orbA",
    )
    val b by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(23_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "orbB",
    )
    Canvas(modifier.background(NcBackground)) {
        fun orb(color: Color, cx: Float, cy: Float, radius: Float) = drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(color, Color.Transparent),
                center = Offset(cx, cy),
                radius = radius,
            ),
            radius = radius,
            center = Offset(cx, cy),
        )
        val w = size.width
        val h = size.height
        orb(NcPrimary.copy(alpha = 0.30f), w * (0.15f + 0.45f * a), h * (0.12f + 0.12f * b), w * 0.75f)
        orb(NcSecondary.copy(alpha = 0.24f), w * (0.85f - 0.45f * b), h * (0.55f + 0.20f * a), w * 0.80f)
        orb(Color(0xFF2B86BD).copy(alpha = 0.22f), w * (0.30f + 0.40f * b), h * (0.92f - 0.18f * a), w * 0.70f)
    }
}

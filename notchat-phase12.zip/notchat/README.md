# Chatro - Beyond Messages. Beyond Borders.

Android messaging app (Kotlin, Jetpack Compose, Material 3, Hilt) with a Supabase backend.

## Status
- Phase 1: branding, theme, core screens.
- Phase 2: real sign-up / sign-in / sign-out / password reset / account deletion
  against Supabase, live username check, encrypted session storage, profile loaded from the database.
- Phase 3: global search by @username or name, profile page, share account.
- Phase 4: 1:1 real-time text chat (Supabase Realtime), sent/delivered/read status,
  paging, day separators, retry-safe sending, unread counters.
- Phase 5: photos (compressed before upload), videos, files, voice messages,
  private storage with signed URLs.
- Phase 5b: profile editing (photo, name, bio, country), chat looks (bubble color/shape/background),
  view-once photos and videos.
- Phase 6a: contacts (add/remove, list) and group chats (create, add/remove members,
  rename, leave, sender names, group read receipts).
- Phase 6b: delete for me / for everyone, forward (text + media, up to 5 chats),
  copy, mute chats, message notifications via a background service (no Firebase).
- Phase 7: app renamed to Chatro with the new icon and neon-green look, online status / last seen
  (with a privacy switch), live typing and voice-recording indicators.
- Phase 8: new chat-list design (filter chips, floating navigation, flat rows), refreshed chat
  (waveform voice messages, image time overlay, scroll-to-latest button, header menu), blue "Ocean" bubbles,
  per-chat 4-digit PIN lock (local, with attempt lockout).
- Phase 9: swipe-to-reply with quoted messages, group photos, polish (glow backgrounds, brand
  wordmark, loading skeletons, animated lists, grouped settings screen).
- Phase 10 (this version): chat-loading fix (readable error + Retry, works with an outdated database),
  liquid-glass look (frosted panels, glossy bubbles, drifting colour background).
- Not yet built: voice/video calls (WebRTC + TURN), stickers, edit message/delete/pin/forward/typing/in-chat search (4b), media (5), notifications/privacy (6), calls (7).

## Build secrets (GitHub -> Settings -> Secrets and variables -> Actions)
- `SUPABASE_URL`       e.g. https://<project-ref>.supabase.co
- `SUPABASE_ANON_KEY`  the publishable key (never the service_role / secret key)

## Database
Run in order in Supabase -> SQL Editor: `supabase/migrations/0001_profiles_and_auth.sql`, `0002_search.sql`, `0003_chat.sql`, `0004_media.sql`, `0005_profile_and_view_once.sql`, `0006_contacts_groups.sql`, `0007_message_actions.sql`, `0008_presence.sql`, then `0009_group_photo_replies.sql`.

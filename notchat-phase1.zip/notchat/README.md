# NOT CHAT — Beyond Messages. Beyond Borders.

Android messaging app (Kotlin, Jetpack Compose, Material 3) with a Supabase backend.

## Status
Phase 1 only: branding, theme, splash, login/register UI (local validation only), home shell.
No server connection yet — that starts in Phase 2.

## Build without Android Studio
1. Create a GitHub repository and upload this folder (keep the `.github` folder).
2. Open the repo -> Actions -> "Android CI" -> Run workflow (it also runs on every push to main).
3. When it finishes, open the run and download the `notchat-debug-apk` artifact, unzip it, and install `app-debug.apk` on your phone (allow installs from unknown sources).
4. If the run fails, send me the red error log.

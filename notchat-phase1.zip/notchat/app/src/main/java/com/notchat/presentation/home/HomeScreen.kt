package com.notchat.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcSurface
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.core.util.NetworkMonitor
import com.notchat.presentation.components.EmptyState
import com.notchat.presentation.components.NcTextField
import com.notchat.presentation.components.NotChatLogo
import kotlinx.coroutines.launch

private data class Tab(val labelRes: Int, val icon: ImageVector)

private val tabs = listOf(
    Tab(R.string.tab_chats, Icons.Outlined.ChatBubbleOutline),
    Tab(R.string.tab_contacts, Icons.Outlined.People),
    Tab(R.string.tab_settings, Icons.Outlined.Settings),
)

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val monitor = remember { NetworkMonitor(context.applicationContext) }
    val online by monitor.isOnline.collectAsState(initial = true)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val soon = stringResource(R.string.coming_soon)

    Scaffold(
        containerColor = NcBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { HomeTopBar(online) },
        bottomBar = {
            NavigationBar(containerColor = NcSurface) {
                tabs.forEachIndexed { index, t ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(stringResource(t.labelRes)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NcPrimary,
                            selectedTextColor = NcPrimary,
                            indicatorColor = NcPrimary.copy(alpha = 0.15f),
                            unselectedIconColor = NcTextSecondary,
                            unselectedTextColor = NcTextSecondary,
                        ),
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(
                    onClick = { scope.launch { snackbar.showSnackbar(soon) } },
                    containerColor = NcPrimary,
                    contentColor = Color.White,
                ) {
                    Icon(Icons.Outlined.Edit, contentDescription = stringResource(R.string.new_chat))
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> {
                    // Search becomes functional in Phase 3 (global user search).
                    NcTextField(
                        value = "",
                        onValueChange = {},
                        label = stringResource(R.string.search_hint),
                        leadingIcon = Icons.Outlined.Search,
                        enabled = false,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                    // No conversations exist until Phase 4, so the honest state is empty.
                    EmptyState(
                        icon = Icons.Outlined.ChatBubbleOutline,
                        title = stringResource(R.string.empty_chats_title),
                        body = stringResource(R.string.empty_chats_body),
                    )
                }
                1 -> EmptyState(
                    icon = Icons.Outlined.People,
                    title = stringResource(R.string.soon_title),
                    body = stringResource(R.string.soon_body),
                )
                else -> EmptyState(
                    icon = Icons.Outlined.Settings,
                    title = stringResource(R.string.soon_title),
                    body = stringResource(R.string.soon_body),
                )
            }
        }
    }
}

@Composable
private fun HomeTopBar(online: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NotChatLogo(size = 38.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.app_name),
                color = NcTextPrimary, fontSize = 18.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(8.dp)
                        .background(if (online) NcSecondary else NcError, CircleShape)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    stringResource(if (online) R.string.online else R.string.offline),
                    color = NcTextSecondary, fontSize = 12.sp,
                )
            }
        }
        // Real avatar arrives with profiles in Phase 2.
        Box(
            modifier = Modifier.size(40.dp).background(NcCard, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.Person, contentDescription = null, tint = NcTextSecondary)
        }
    }
}

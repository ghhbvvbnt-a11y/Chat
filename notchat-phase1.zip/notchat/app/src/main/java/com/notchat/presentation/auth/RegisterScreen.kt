package com.notchat.presentation.auth

import android.util.Patterns
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AlternateEmail
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.core.util.UsernameError
import com.notchat.core.util.UsernameValidator
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.NcTextField
import kotlinx.coroutines.launch

@Composable
private fun usernameErrorText(error: UsernameError?): String? = when (error) {
    null -> null
    UsernameError.EMPTY -> stringResource(R.string.err_username_empty)
    UsernameError.BAD_START -> stringResource(R.string.err_username_start)
    UsernameError.BAD_CHARS -> stringResource(R.string.err_username_chars)
    UsernameError.TOO_SHORT -> stringResource(R.string.err_username_short)
    UsernameError.TOO_LONG -> stringResource(R.string.err_username_long)
}

@Composable
fun RegisterScreen(onBack: () -> Unit) {
    var email by rememberSaveable { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    var displayName by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val soon = stringResource(R.string.backend_soon)

    val emailValid = Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
    val usernameIssue = UsernameValidator.validate(username)
    val nameValid = displayName.isNotBlank()
    val passwordValid = password.length >= 8
    val confirmValid = confirm == password

    val emailError = if (submitted && !emailValid) stringResource(R.string.err_email) else null
    val userError = if (username.isNotEmpty() || submitted) usernameErrorText(usernameIssue) else null
    val nameError = if (submitted && !nameValid) stringResource(R.string.err_required) else null
    val passError = if (submitted && !passwordValid) stringResource(R.string.err_password_short) else null
    val confirmError = if (submitted && !confirmValid) stringResource(R.string.err_password_mismatch) else null

    Scaffold(
        containerColor = NcBackground,
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).systemBarsPadding().imePadding()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    stringResource(R.string.register_title),
                    color = NcTextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start),
                )
                Text(
                    stringResource(R.string.register_subtitle),
                    color = NcTextSecondary, fontSize = 14.sp,
                    modifier = Modifier.align(Alignment.Start),
                )
                Spacer(Modifier.height(20.dp))
                NcTextField(
                    value = email, onValueChange = { email = it },
                    label = stringResource(R.string.email),
                    leadingIcon = Icons.Outlined.Email,
                    keyboardType = KeyboardType.Email, error = emailError,
                )
                NcTextField(
                    value = username, onValueChange = { username = it.trim() },
                    label = stringResource(R.string.username),
                    leadingIcon = Icons.Outlined.AlternateEmail,
                    error = userError,
                )
                NcTextField(
                    value = displayName, onValueChange = { displayName = it },
                    label = stringResource(R.string.display_name),
                    leadingIcon = Icons.Outlined.Badge, error = nameError,
                )
                NcTextField(
                    value = password, onValueChange = { password = it },
                    label = stringResource(R.string.password),
                    leadingIcon = Icons.Outlined.Lock, isPassword = true, error = passError,
                )
                NcTextField(
                    value = confirm, onValueChange = { confirm = it },
                    label = stringResource(R.string.confirm_password),
                    leadingIcon = Icons.Outlined.Lock, isPassword = true,
                    imeAction = ImeAction.Done, error = confirmError,
                )
                Spacer(Modifier.height(16.dp))
                GradientButton(
                    text = stringResource(R.string.create_account),
                    onClick = {
                        submitted = true
                        val ok = emailValid && usernameIssue == null && nameValid && passwordValid && confirmValid
                        // Phase 2 replaces this with the real Supabase sign-up + username check.
                        if (ok) scope.launch { snackbar.showSnackbar(soon) }
                    },
                )
                TextButton(onClick = onBack) {
                    Text(stringResource(R.string.have_account), color = NcSecondary)
                }
            }
        }
    }
}

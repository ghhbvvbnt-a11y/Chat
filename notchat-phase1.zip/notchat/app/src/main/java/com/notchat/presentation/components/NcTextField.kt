package com.notchat.presentation.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary

@Composable
fun NcTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    isPassword: Boolean = false,
    error: String? = null,
    enabled: Boolean = true,
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        enabled = enabled,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        leadingIcon = leadingIcon?.let { icon -> { Icon(icon, contentDescription = null) } },
        trailingIcon = if (isPassword) {
            {
                IconButton(onClick = { visible = !visible }) {
                    Icon(
                        imageVector = if (visible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                        contentDescription = stringResource(
                            if (visible) R.string.hide_password else R.string.show_password
                        ),
                    )
                }
            }
        } else null,
        isError = error != null,
        supportingText = error?.let { e -> { Text(e) } },
        singleLine = true,
        visualTransformation = if (isPassword && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (isPassword) KeyboardType.Password else keyboardType,
            imeAction = imeAction,
        ),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = NcTextPrimary,
            unfocusedTextColor = NcTextPrimary,
            disabledTextColor = NcTextSecondary,
            focusedContainerColor = NcCard,
            unfocusedContainerColor = NcCard,
            disabledContainerColor = NcCard,
            errorContainerColor = NcCard,
            cursorColor = NcPrimary,
            focusedBorderColor = NcPrimary,
            unfocusedBorderColor = NcOutline,
            disabledBorderColor = NcOutline,
            errorBorderColor = NcError,
            focusedLabelColor = NcPrimary,
            unfocusedLabelColor = NcTextSecondary,
            disabledLabelColor = NcTextSecondary,
            errorLabelColor = NcError,
            focusedLeadingIconColor = NcPrimary,
            unfocusedLeadingIconColor = NcTextSecondary,
            disabledLeadingIconColor = NcTextSecondary,
            errorLeadingIconColor = NcError,
            focusedTrailingIconColor = NcTextSecondary,
            unfocusedTrailingIconColor = NcTextSecondary,
            errorSupportingTextColor = NcError,
        ),
    )
}

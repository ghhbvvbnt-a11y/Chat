package com.notchat.presentation.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.notchat.core.theme.NcBackground
import com.notchat.presentation.auth.LoginScreen
import com.notchat.presentation.auth.RegisterScreen
import com.notchat.presentation.home.HomeScreen
import com.notchat.presentation.splash.SplashScreen

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
}

@Composable
fun NotChatNavHost() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        modifier = Modifier.background(NcBackground),
        enterTransition = { fadeIn(tween(250)) },
        exitTransition = { fadeOut(tween(250)) },
        popEnterTransition = { fadeIn(tween(250)) },
        popExitTransition = { fadeOut(tween(250)) },
    ) {
        composable(Routes.SPLASH) {
            SplashScreen {
                nav.navigate(Routes.LOGIN) { popUpTo(Routes.SPLASH) { inclusive = true } }
            }
        }
        composable(Routes.LOGIN) {
            LoginScreen(
                onNavigateRegister = { nav.navigate(Routes.REGISTER) },
                onPreviewHome = { nav.navigate(Routes.HOME) },
            )
        }
        composable(Routes.REGISTER) {
            RegisterScreen(onBack = { nav.popBackStack() })
        }
        composable(Routes.HOME) { HomeScreen() }
    }
}

package com.notchat.presentation.auth

import android.util.Patterns
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.BuildConfig
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.NcTextField
import com.notchat.presentation.components.NotChatLogo
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    onNavigateRegister: () -> Unit,
    onPreviewHome: () -> Unit,
) {
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val soon = stringResource(R.string.backend_soon)

    val emailError = if (submitted && !Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches())
        stringResource(R.string.err_email) else null
    val passwordError = if (submitted && password.length < 8)
        stringResource(R.string.err_password_short) else null

    Scaffold(
        containerColor = NcBackground,
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).systemBarsPadding().imePadding()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                NotChatLogo(size = 88.dp)
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(R.string.app_name),
                    color = NcTextPrimary, fontSize = 26.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 3.sp,
                )
                Text(stringResource(R.string.tagline), color = NcTextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(32.dp))
                Text(
                    stringResource(R.string.login_title),
                    color = NcTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.Start),
                )
                Text(
                    stringResource(R.string.login_subtitle),
                    color = NcTextSecondary, fontSize = 14.sp,
                    modifier = Modifier.align(Alignment.Start),
                )
                Spacer(Modifier.height(20.dp))
                NcTextField(
                    value = email, onValueChange = { email = it },
                    label = stringResource(R.string.email),
                    leadingIcon = Icons.Outlined.Email,
                    keyboardType = KeyboardType.Email,
                    error = emailError,
                )
                Spacer(Modifier.height(4.dp))
                NcTextField(
                    value = password, onValueChange = { password = it },
                    label = stringResource(R.string.password),
                    leadingIcon = Icons.Outlined.Lock,
                    isPassword = true, imeAction = ImeAction.Done,
                    error = passwordError,
                )
                Spacer(Modifier.height(16.dp))
                GradientButton(
                    text = stringResource(R.string.login),
                    onClick = {
                        submitted = true
                        val ok = Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() && password.length >= 8
                        // Phase 2 replaces this with the real Supabase sign-in call.
                        if (ok) scope.launch { snackbar.showSnackbar(soon) }
                    },
                )
                TextButton(onClick = onNavigateRegister) {
                    Text(stringResource(R.string.no_account), color = NcSecondary)
                }
                if (BuildConfig.DEBUG) {
                    TextButton(onClick = onPreviewHome) {
                        Text(stringResource(R.string.preview_home), color = NcPrimary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

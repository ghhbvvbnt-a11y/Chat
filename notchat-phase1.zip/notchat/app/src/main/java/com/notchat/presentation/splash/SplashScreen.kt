package com.notchat.presentation.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.presentation.components.NotChatLogo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.85f) }
    LaunchedEffect(Unit) {
        launch { alpha.animateTo(1f, tween(700)) }
        launch { scale.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        delay(1400)
        onFinished()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NcBackground)
            .background(Brush.radialGradient(listOf(NcPrimary.copy(alpha = 0.18f), Color.Transparent))),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.alpha(alpha.value).scale(scale.value),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            NotChatLogo(size = 120.dp)
            Spacer(Modifier.height(20.dp))
            Text(
                text = stringResource(R.string.app_name),
                color = NcTextPrimary,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.tagline),
                color = NcTextSecondary,
                fontSize = 14.sp,
            )
        }
    }
}

package com.notchat.domain

import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationType
import org.junit.Assert.assertEquals
import org.junit.Test

class ChatListFilterTest {
    private fun conv(id: String, type: ConversationType = ConversationType.DIRECT, unread: Int = 0) = Conversation(
        id = id, type = type, title = id, otherUserId = null, otherUsername = null, otherAvatarUrl = null,
        lastMessageBody = "", lastMessageDeleted = false, lastMessageSenderId = null, lastMessageSenderName = null,
        lastMessageAtRaw = "", lastMessageAtMillis = 0L, unreadCount = unread, muted = false,
        memberCount = 2, hasMessages = true,
    )

    private val all = listOf(
        conv("a", unread = 2),
        conv("b", ConversationType.GROUP),
        conv("c", ConversationType.GROUP, unread = 1),
        conv("d"),
    )

    @Test fun allKeepsEverything() {
        assertEquals(listOf("a", "b", "c", "d"), ChatListFilter.apply(all, ChatFilter.ALL, emptySet()).map { it.id })
    }

    @Test fun unreadKeepsOnlyChatsWithNewMessages() {
        assertEquals(listOf("a", "c"), ChatListFilter.apply(all, ChatFilter.UNREAD, emptySet()).map { it.id })
    }

    @Test fun groupsKeepsOnlyGroups() {
        assertEquals(listOf("b", "c"), ChatListFilter.apply(all, ChatFilter.GROUPS, emptySet()).map { it.id })
    }

    @Test fun lockedKeepsOnlyLockedChats() {
        assertEquals(listOf("d"), ChatListFilter.apply(all, ChatFilter.LOCKED, setOf("d", "zzz")).map { it.id })
    }
}

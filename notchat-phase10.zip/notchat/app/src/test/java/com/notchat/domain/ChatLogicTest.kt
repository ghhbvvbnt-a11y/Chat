package com.notchat.domain

import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageStatus
import com.notchat.domain.model.Receipts
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneOffset

class ChatLogicTest {
    private fun msg(id: String, at: Long, body: String = "x") = Message(
        id = id, clientId = "c$id", conversationId = "conv", senderId = "me",
        body = body, createdAtRaw = "", createdAtMillis = at,
        replyTo = null, edited = false, deleted = false,
    )

    @Test fun statusIsSentWithoutReceipts() {
        assertEquals(MessageStatus.SENT, ChatLogic.statusFor(msg("1", 100), null))
    }

    @Test fun statusProgressesSentDeliveredRead() {
        val m = msg("1", 100)
        assertEquals(MessageStatus.SENT, ChatLogic.statusFor(m, Receipts(50, 50)))
        assertEquals(MessageStatus.DELIVERED, ChatLogic.statusFor(m, Receipts(150, 50)))
        assertEquals(MessageStatus.READ, ChatLogic.statusFor(m, Receipts(150, 120)))
    }

    @Test fun mergeDeduplicatesAndSortsNewestFirst() {
        val a = msg("a", 100)
        val b = msg("b", 200)
        val bEdited = msg("b", 200, body = "edited")
        val c = msg("c", 300)
        val merged = ChatLogic.mergeNewestFirst(listOf(a, b), listOf(bEdited, c))
        assertEquals(listOf("c", "b", "a"), merged.map { it.id })
        assertEquals("edited", merged[1].body)
    }

    @Test fun mergeKeepsStableOrderForEqualTimestamps() {
        val merged = ChatLogic.mergeNewestFirst(listOf(msg("a", 100), msg("b", 100)), emptyList())
        assertEquals(listOf("b", "a"), merged.map { it.id })
    }

    @Test fun groupReceiptsUseTheSlowestMember() {
        val combined = ChatLogic.combineReceipts(listOf(Receipts(500, 300), Receipts(200, 100), Receipts(900, 800)))
        assertEquals(Receipts(200, 100), combined)
        assertEquals(null, ChatLogic.combineReceipts(emptyList()))
    }

    @Test fun sameDayRespectsTimeZone() {
        val utc = ZoneOffset.UTC
        val t = 1_794_045_600_000L // 2026-11-07 10:00 UTC
        assertTrue(ChatLogic.sameDay(t, t + 3_600_000L, utc))
        assertFalse(ChatLogic.sameDay(t, t + 24 * 3_600_000L, utc))
    }
}

class ViewOnceLogicTest {
    @org.junit.Test fun receiverSeesTapToViewUntilOpened() {
        org.junit.Assert.assertEquals(
            ViewOnceDisplay.TAP_TO_VIEW,
            ChatLogic.viewOnceDisplay(mine = false, viewedByMe = false, viewedByOther = false),
        )
        org.junit.Assert.assertEquals(
            ViewOnceDisplay.OPENED_BY_ME,
            ChatLogic.viewOnceDisplay(mine = false, viewedByMe = true, viewedByOther = false),
        )
    }

    @org.junit.Test fun senderSeesWhetherItWasOpened() {
        org.junit.Assert.assertEquals(
            ViewOnceDisplay.SENT_NOT_OPENED,
            ChatLogic.viewOnceDisplay(mine = true, viewedByMe = false, viewedByOther = false),
        )
        org.junit.Assert.assertEquals(
            ViewOnceDisplay.SENT_OPENED,
            ChatLogic.viewOnceDisplay(mine = true, viewedByMe = false, viewedByOther = true),
        )
    }
}

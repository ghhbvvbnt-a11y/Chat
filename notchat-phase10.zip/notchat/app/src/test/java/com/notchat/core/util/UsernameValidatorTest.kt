package com.notchat.core.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class UsernameValidatorTest {
    @Test fun validNamesPass() {
        assertNull(UsernameValidator.validate("mohammed123"))
        assertNull(UsernameValidator.validate("1abc"))
        assertNull(UsernameValidator.validate("a_b"))
        assertNull(UsernameValidator.validate("A".repeat(32)))
    }

    @Test fun emptyIsRejected() {
        assertEquals(UsernameError.EMPTY, UsernameValidator.validate(""))
    }

    @Test fun mustStartWithLetterOrDigit() {
        assertEquals(UsernameError.BAD_START, UsernameValidator.validate("_abc"))
        assertEquals(UsernameError.BAD_START, UsernameValidator.validate(" abc"))
        assertEquals(UsernameError.BAD_START, UsernameValidator.validate("محمد1"))
    }

    @Test fun onlyAllowedCharacters() {
        assertEquals(UsernameError.BAD_CHARS, UsernameValidator.validate("ab-c"))
        assertEquals(UsernameError.BAD_CHARS, UsernameValidator.validate("a b c"))
        assertEquals(UsernameError.BAD_CHARS, UsernameValidator.validate("a!"))
    }

    @Test fun lengthLimits() {
        assertEquals(UsernameError.TOO_SHORT, UsernameValidator.validate("ab"))
        assertEquals(UsernameError.TOO_LONG, UsernameValidator.validate("a".repeat(33)))
    }

    @Test fun normalizeLowercases() {
        assertEquals("mohammed_1", UsernameValidator.normalize("MoHaMMed_1"))
    }
}

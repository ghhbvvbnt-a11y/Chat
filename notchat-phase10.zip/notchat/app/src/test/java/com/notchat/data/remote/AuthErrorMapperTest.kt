package com.notchat.data.remote

import com.notchat.domain.model.AuthError
import org.junit.Assert.assertEquals
import org.junit.Test

class AuthErrorMapperTest {
    @Test fun invalidCredentials() {
        val body = """{"code":400,"error_code":"invalid_credentials","msg":"Invalid login credentials"}"""
        assertEquals(AuthError.INVALID_CREDENTIALS, AuthErrorMapper.fromResponse(400, body))
    }

    @Test fun legacyInvalidCredentialsMessage() {
        val body = """{"error":"invalid_grant","error_description":"Invalid login credentials"}"""
        assertEquals(AuthError.INVALID_CREDENTIALS, AuthErrorMapper.fromResponse(400, body))
    }

    @Test fun emailNotConfirmed() {
        val body = """{"error_code":"email_not_confirmed","msg":"Email not confirmed"}"""
        assertEquals(AuthError.EMAIL_NOT_CONFIRMED, AuthErrorMapper.fromResponse(400, body))
    }

    @Test fun emailAlreadyRegistered() {
        val body = """{"error_code":"user_already_exists","msg":"User already registered"}"""
        assertEquals(AuthError.EMAIL_TAKEN, AuthErrorMapper.fromResponse(422, body))
    }

    @Test fun weakPassword() {
        val body = """{"error_code":"weak_password","msg":"Password should be longer"}"""
        assertEquals(AuthError.WEAK_PASSWORD, AuthErrorMapper.fromResponse(422, body))
    }

    @Test fun usernameConflictSurfacesAsDatabaseError() {
        val body = """{"error_code":"unexpected_failure","msg":"Database error saving new user"}"""
        assertEquals(AuthError.USERNAME_TAKEN, AuthErrorMapper.fromResponse(500, body))
    }

    @Test fun rateLimitByStatusAndByCode() {
        assertEquals(AuthError.RATE_LIMITED, AuthErrorMapper.fromResponse(429, "{}"))
        val body = """{"error_code":"over_email_send_rate_limit","msg":"slow down"}"""
        assertEquals(AuthError.RATE_LIMITED, AuthErrorMapper.fromResponse(429, body))
    }

    @Test fun garbageBodyIsUnknown() {
        assertEquals(AuthError.UNKNOWN, AuthErrorMapper.fromResponse(502, "<html>Bad gateway</html>"))
        assertEquals(AuthError.UNKNOWN, AuthErrorMapper.fromResponse(500, ""))
    }
}

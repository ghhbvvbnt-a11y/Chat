package com.notchat.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PinPolicyTest {
    @Test fun onlyFourDigitsAreValid() {
        assertTrue(PinPolicy.isValid("0000"))
        assertTrue(PinPolicy.isValid("1234"))
        assertFalse(PinPolicy.isValid("123"))
        assertFalse(PinPolicy.isValid("12345"))
        assertFalse(PinPolicy.isValid("12a4"))
        assertFalse(PinPolicy.isValid(""))
        assertFalse(PinPolicy.isValid("١٢٣٤")) // Arabic-Indic digits are not accepted
    }

    @Test fun firstFiveWrongAttemptsAreFree() {
        for (fails in 0..4) assertEquals(0L, PinPolicy.lockoutMillis(fails))
    }

    @Test fun lockoutGrowsInTiers() {
        assertEquals(30_000L, PinPolicy.lockoutMillis(5))
        assertEquals(30_000L, PinPolicy.lockoutMillis(9))
        assertEquals(60_000L, PinPolicy.lockoutMillis(10))
        assertEquals(120_000L, PinPolicy.lockoutMillis(15))
    }

    @Test fun lockoutIsCappedAtFifteenMinutes() {
        assertEquals(15 * 60_000L, PinPolicy.lockoutMillis(200))
        assertEquals(15 * 60_000L, PinPolicy.lockoutMillis(Int.MAX_VALUE))
    }

    @Test fun attemptsLeftCountsDown() {
        assertEquals(5, PinPolicy.attemptsLeft(0))
        assertEquals(1, PinPolicy.attemptsLeft(4))
        assertEquals(0, PinPolicy.attemptsLeft(5))
        assertEquals(0, PinPolicy.attemptsLeft(50))
    }
}

package com.notchat.domain

import com.notchat.domain.model.BubbleShape
import com.notchat.domain.model.BubbleTheme
import com.notchat.domain.model.ChatAppearance
import com.notchat.domain.model.ChatBackground
import org.junit.Assert.assertEquals
import org.junit.Test

class ChatAppearanceTest {
    @Test fun defaultsWhenNothingSaved() {
        val a = ChatAppearance.fromIds(null, null, null)
        assertEquals(ChatAppearance(), a)
    }

    @Test fun readsSavedIds() {
        val a = ChatAppearance.fromIds("rose", "pill", "dots")
        assertEquals(BubbleTheme.ROSE, a.theme)
        assertEquals(BubbleShape.PILL, a.shape)
        assertEquals(ChatBackground.DOTS, a.background)
    }

    @Test fun unknownValuesFallBackIndividually() {
        val a = ChatAppearance.fromIds("neon", "square", "???")
        assertEquals(BubbleTheme.GREEN, a.theme)
        assertEquals(BubbleShape.SQUARE, a.shape)
        assertEquals(ChatBackground.GREEN_GLOW, a.background)
    }

    @Test fun idsAreUnique() {
        assertEquals(BubbleTheme.entries.size, BubbleTheme.entries.map { it.id }.toSet().size)
        assertEquals(BubbleShape.entries.size, BubbleShape.entries.map { it.id }.toSet().size)
        assertEquals(ChatBackground.entries.size, ChatBackground.entries.map { it.id }.toSet().size)
    }
}

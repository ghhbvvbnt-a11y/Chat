package com.notchat.domain

import com.notchat.domain.model.TypingState
import org.junit.Assert.assertEquals
import org.junit.Test

class TypingStateTest {
    @Test fun wireRoundTrip() {
        TypingState.entries.forEach { assertEquals(it, TypingState.fromWire(it.wire)) }
    }

    @Test fun unknownOrMissingMeansIdle() {
        assertEquals(TypingState.IDLE, TypingState.fromWire(null))
        assertEquals(TypingState.IDLE, TypingState.fromWire("dancing"))
    }

    @Test fun wireNamesMatchWhatTheOtherSideExpects() {
        assertEquals("typing", TypingState.TYPING.wire)
        assertEquals("recording", TypingState.RECORDING.wire)
    }
}

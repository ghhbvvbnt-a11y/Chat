package com.notchat.data.remote

import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ProfileJsonTest {
    @Test fun parsesFullProfileList() {
        val body = """[
            {"id":"1","username":"mohammed123","display_name":"Mohammed","avatar_url":null,"bio":"hi","country":"EG"},
            {"id":"2","username":"sara_k","display_name":"Sara","avatar_url":"https://x/y.png","bio":"","country":null}
        ]"""
        val list = JSONArray(body).toProfiles()
        assertEquals(2, list.size)
        assertEquals("mohammed123", list[0].username)
        assertNull(list[0].avatarUrl)
        assertEquals("EG", list[0].country)
        assertEquals("https://x/y.png", list[1].avatarUrl)
        assertNull(list[1].country)
    }

    @Test fun emptyArrayGivesEmptyList() {
        assertEquals(0, JSONArray("[]").toProfiles().size)
    }

    @Test fun nullBioBecomesEmptyString() {
        val body = """[{"id":"1","username":"abc","display_name":"A","avatar_url":null,"bio":null,"country":null}]"""
        assertEquals("", JSONArray(body).toProfiles()[0].bio)
    }
}

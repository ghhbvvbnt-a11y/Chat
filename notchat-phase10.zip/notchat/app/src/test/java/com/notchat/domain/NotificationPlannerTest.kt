package com.notchat.domain

import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationPlannerTest {
    private fun conv(
        id: String,
        at: Long,
        unread: Int = 1,
        sender: String? = "other",
        muted: Boolean = false,
        deleted: Boolean = false,
        hasMessages: Boolean = true,
    ) = Conversation(
        id = id, type = ConversationType.DIRECT, title = "T$id",
        otherUserId = "other", otherUsername = "o", otherAvatarUrl = null,
        lastMessageBody = "hi", lastMessageDeleted = deleted,
        lastMessageSenderId = sender, lastMessageSenderName = null,
        lastMessageAtRaw = "", lastMessageAtMillis = at,
        unreadCount = unread, muted = muted, memberCount = 2, hasMessages = hasMessages,
    )

    private fun plan(
        previous: Map<String, Long>?,
        current: List<Conversation>,
        active: String? = null,
        foreground: Boolean = false,
    ) = NotificationPlanner.plan(previous, current, "me", active, foreground)

    @Test fun firstCheckNeverNotifiesButRemembersState() {
        val p = plan(null, listOf(conv("a", 100), conv("b", 200)))
        assertTrue(p.toNotify.isEmpty())
        assertEquals(mapOf("a" to 100L, "b" to 200L), p.newState)
    }

    @Test fun notifiesOnlyForNewerMessages() {
        val p = plan(mapOf("a" to 100L, "b" to 200L), listOf(conv("a", 100), conv("b", 250)))
        assertEquals(listOf("b"), p.toNotify.map { it.id })
    }

    @Test fun newConversationWithUnreadNotifies() {
        val p = plan(emptyMap(), listOf(conv("new", 50)))
        assertEquals(listOf("new"), p.toNotify.map { it.id })
    }

    @Test fun skipsMyOwnMutedDeletedAndReadMessages() {
        val prev = mapOf("a" to 1L, "b" to 1L, "c" to 1L, "d" to 1L)
        val p = plan(
            prev,
            listOf(
                conv("a", 10, sender = "me"),
                conv("b", 10, muted = true),
                conv("c", 10, deleted = true),
                conv("d", 10, unread = 0),
            ),
        )
        assertTrue(p.toNotify.isEmpty())
    }

    @Test fun skipsOpenChatAndForegroundApp() {
        val prev = mapOf("a" to 1L)
        assertTrue(plan(prev, listOf(conv("a", 10)), active = "a").toNotify.isEmpty())
        assertTrue(plan(prev, listOf(conv("a", 10)), foreground = true).toNotify.isEmpty())
    }

    @Test fun messagesSeenWhileInForegroundAreNotNotifiedLater() {
        val first = plan(mapOf("a" to 1L), listOf(conv("a", 10)), foreground = true)
        val second = plan(first.newState, listOf(conv("a", 10)), foreground = false)
        assertTrue(second.toNotify.isEmpty())
    }

    @Test fun emptyGroupIsIgnored() {
        val p = plan(emptyMap(), listOf(conv("g", 5, hasMessages = false)))
        assertTrue(p.toNotify.isEmpty())
    }
}

package com.notchat.domain

import com.notchat.domain.model.MessageKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaRulesTest {
    @Test fun kindFromMime() {
        assertEquals(MessageKind.IMAGE, MessageKind.fromMime("image/jpeg"))
        assertEquals(MessageKind.VIDEO, MessageKind.fromMime("video/mp4"))
        assertEquals(MessageKind.AUDIO, MessageKind.fromMime("audio/mp4"))
        assertEquals(MessageKind.FILE, MessageKind.fromMime("application/pdf"))
    }

    @Test fun wireRoundTrip() {
        MessageKind.entries.forEach { assertEquals(it, MessageKind.fromWire(it.wire)) }
        assertEquals(MessageKind.TEXT, MessageKind.fromWire(null))
        assertEquals(MessageKind.TEXT, MessageKind.fromWire("weird"))
    }

    @Test fun allowedTypes() {
        assertTrue(MediaRules.isAllowed("image/jpeg"))
        assertTrue(MediaRules.isAllowed("AUDIO/MP4"))
        assertTrue(MediaRules.isAllowed("application/pdf"))
        assertFalse(MediaRules.isAllowed("application/vnd.android.package-archive"))
        assertFalse(MediaRules.isAllowed("application/x-msdownload"))
        assertFalse(MediaRules.isAllowed("application/octet-stream"))
    }

    @Test fun limitIs25Mb() {
        assertEquals(26_214_400L, MediaRules.MAX_BYTES)
    }
}

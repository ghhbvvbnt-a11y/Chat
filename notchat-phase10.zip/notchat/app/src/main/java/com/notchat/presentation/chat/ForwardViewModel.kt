package com.notchat.presentation.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationType
import com.notchat.domain.model.Message
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.ChatRepository
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

/** Somewhere a message can be forwarded to. */
sealed interface ForwardDest {
    val key: String
    val title: String
    val subtitle: String?
    val avatarUrl: String?

    data class Existing(val conversation: Conversation) : ForwardDest {
        override val key get() = "c:" + conversation.id
        override val title get() = conversation.title
        override val subtitle get() = conversation.otherUsername?.let { "@$it" }
        override val avatarUrl get() = conversation.otherAvatarUrl
    }

    /** A contact I have no chat with yet; the chat is created when forwarding. */
    data class NewDirect(val profile: Profile) : ForwardDest {
        override val key get() = "p:" + profile.id
        override val title get() = profile.displayName
        override val subtitle get() = "@" + profile.username
        override val avatarUrl get() = profile.avatarUrl
    }
}

data class ForwardUiState(
    val loading: Boolean = true,
    val destinations: List<ForwardDest> = emptyList(),
    val selected: Set<String> = emptySet(),
    val sending: Boolean = false,
    val error: AuthError? = null,
) {
    val canSend: Boolean get() = selected.isNotEmpty() && !sending
}

@HiltViewModel
class ForwardViewModel @Inject constructor(
    private val chat: ChatRepository,
    private val users: UserRepository,
    auth: AuthRepository,
) : ViewModel() {

    private val myId = (auth.sessionState.value as? SessionState.SignedIn)?.userId.orEmpty()
    private val _ui = MutableStateFlow(ForwardUiState())
    val ui: StateFlow<ForwardUiState> = _ui.asStateFlow()

    private val _done = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val done: SharedFlow<Unit> = _done.asSharedFlow()

    private val sent = HashSet<String>() // destinations already served (skipped when retrying)

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null) }
            val conversations = chat.conversations()
            val contacts = users.contacts()
            if (conversations is Outcome.Failure) {
                _ui.update { it.copy(loading = false, error = conversations.error) }
                return@launch
            }
            val existing = (conversations as Outcome.Success).value
            val haveDirectWith = existing
                .filter { it.type == ConversationType.DIRECT }
                .mapNotNullTo(HashSet()) { it.otherUserId }
            val newOnes = (contacts as? Outcome.Success)?.value.orEmpty()
                .filter { it.id !in haveDirectWith }
                .map { ForwardDest.NewDirect(it) }
            _ui.update {
                it.copy(loading = false, destinations = existing.map { c -> ForwardDest.Existing(c) } + newOnes)
            }
        }
    }

    fun toggle(key: String) = _ui.update {
        val next = if (key in it.selected) it.selected - key else if (it.selected.size < MAX_TARGETS) it.selected + key else it.selected
        it.copy(selected = next)
    }

    fun forward(source: Message) {
        val state = _ui.value
        if (!state.canSend) return
        _ui.update { it.copy(sending = true, error = null) }
        viewModelScope.launch {
            for (dest in state.destinations.filter { it.key in state.selected }) {
                if (dest.key in sent) continue
                val conversationId = when (dest) {
                    is ForwardDest.Existing -> dest.conversation.id
                    is ForwardDest.NewDirect -> when (val r = chat.startConversation(dest.profile.id)) {
                        is Outcome.Success -> r.value
                        is Outcome.Failure -> {
                            _ui.update { it.copy(sending = false, error = r.error) }
                            return@launch
                        }
                    }
                }
                val r = chat.forwardMessage(source, conversationId, myId, UUID.randomUUID().toString())
                if (r is Outcome.Failure) {
                    _ui.update { it.copy(sending = false, error = r.error) }
                    return@launch
                }
                sent += dest.key
            }
            _ui.update { it.copy(sending = false) }
            _done.tryEmit(Unit)
        }
    }

    private companion object {
        const val MAX_TARGETS = 5
    }
}

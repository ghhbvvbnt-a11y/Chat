package com.notchat.presentation.home

import android.Manifest
import kotlinx.coroutines.launch
import com.notchat.presentation.lock.PinVerifyDialog
import com.notchat.presentation.lock.PinCreateDialog
import com.notchat.presentation.chat.ChatLockViewModel
import com.notchat.domain.ChatListFilter
import com.notchat.domain.ChatFilter
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.outlined.AddComment
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.GroupAdd
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcOnPrimary
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcSurface
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.core.util.NetworkMonitor
import com.notchat.domain.model.Profile
import com.notchat.presentation.auth.message
import com.notchat.presentation.auth.messageRes
import com.notchat.presentation.chat.AppearanceDialog
import com.notchat.presentation.components.EmptyState
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.SearchBarButton
import com.notchat.presentation.util.shareAccount
import com.notchat.presentation.components.NotChatLogo

private data class Tab(val labelRes: Int, val icon: ImageVector)

private val tabs = listOf(
    Tab(R.string.tab_chats, Icons.Outlined.ChatBubbleOutline),
    Tab(R.string.tab_contacts, Icons.Outlined.People),
    Tab(R.string.tab_settings, Icons.Outlined.Settings),
)

@Composable
fun HomeScreen(
    onSignedOut: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenChat: (conversationId: String) -> Unit,
    onEditProfile: () -> Unit,
    onOpenProfile: (username: String) -> Unit,
    onNewGroup: () -> Unit,
    convVm: ConversationsViewModel = hiltViewModel(),
    contactsVm: ContactsViewModel = hiltViewModel(),
    lockVm: ChatLockViewModel = hiltViewModel(),
    vm: HomeViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val monitor = remember { NetworkMonitor(context.applicationContext) }
    val online by monitor.isOnline.collectAsState(initial = true)
    val ui by vm.ui.collectAsState()
    val convUi by convVm.ui.collectAsState()
    val contactsUi by contactsVm.ui.collectAsState()
    val notificationsEnabled by vm.notificationsEnabled.collectAsState()
    val presenceSharing by vm.presenceSharing.collectAsState()
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        vm.onNotificationPermissionResult(granted)
    }
    LaunchedEffect(Unit) {
        if (vm.needsNotificationPrompt()) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            vm.ensureNotifications()
        }
    }
    val signedOut by vm.signedOut.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var filter by rememberSaveable { mutableStateOf(ChatFilter.ALL) }
    val lockedIds by lockVm.lockedIds.collectAsState()
    val unreadTotal = convUi.items.filter { !it.muted }.sumOf { it.unreadCount }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(signedOut) {
        if (signedOut) onSignedOut()
    }
    LaunchedEffect(Unit) {
        vm.errors.collect { error -> snackbar.showSnackbar(context.getString(error.messageRes())) }
    }

    Scaffold(
        containerColor = NcBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            HomeTopBar(
                title = stringResource(tabs[tab].labelRes),
                online = online,
                profile = ui.profile,
                onAvatar = { tab = 2 },
                onNewGroup = onNewGroup,
                onNewChat = onOpenSearch,
            )
        },
        bottomBar = {
            FloatingNavBar(selected = tab, onSelect = { tab = it }, unread = unreadTotal)
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> {
                    SearchBarButton(
                        hint = stringResource(R.string.search_hint),
                        onClick = onOpenSearch,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                    FilterRow(selected = filter, unread = unreadTotal, onSelect = { filter = it })
                    ConversationsList(
                        state = convUi.copy(items = ChatListFilter.apply(convUi.items, filter, lockedIds)),
                        lockedIds = lockedIds,
                        onOpen = onOpenChat,
                        onRetry = convVm::refresh,
                    )
                }
                1 -> ContactsTab(
                    state = contactsUi,
                    onOpenProfile = onOpenProfile,
                    onNewGroup = onNewGroup,
                    onOpenSearch = onOpenSearch,
                    onRetry = contactsVm::load,
                )
                else -> SettingsTab(
                    state = ui,
                    lockVm = lockVm,
                    onRetry = vm::loadProfile,
                    onEditProfile = onEditProfile,
                    presenceSharing = presenceSharing,
                    onTogglePresence = vm::setPresenceSharing,
                    notificationsEnabled = notificationsEnabled,
                    notificationsBlocked = notificationsEnabled && !vm.canNotify(),
                    onToggleNotifications = { want ->
                        if (want && android.os.Build.VERSION.SDK_INT >= 33 && !vm.canNotify()) {
                            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        vm.setNotificationsEnabled(want)
                    },
                    onSignOut = vm::signOut,
                    onDeleteAccount = vm::deleteAccount,
                )
            }
        }
    }
}

@Composable
private fun SettingsTab(
    state: HomeUiState,
    lockVm: ChatLockViewModel,
    onRetry: () -> Unit,
    onEditProfile: () -> Unit,
    presenceSharing: Boolean,
    onTogglePresence: (Boolean) -> Unit,
    notificationsEnabled: Boolean,
    notificationsBlocked: Boolean,
    onToggleNotifications: (Boolean) -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit,
) {
    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var showAppearance by rememberSaveable { mutableStateOf(false) }
    var pinFlow by rememberSaveable { mutableIntStateOf(0) } // 0 none, 1 verify to change, 2 new PIN, 3 verify to remove
    val pinSet by lockVm.pinSet.collectAsState()
    val pinScope = rememberCoroutineScope()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        val profile = state.profile
        when {
            profile != null -> ProfileCard(profile, onShare = { shareAccount(context, profile.username) })
            state.loading -> Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NcPrimary)
            }
            else -> Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NcCard, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    state.error?.message() ?: stringResource(R.string.profile_load_failed),
                    color = NcError, fontSize = 14.sp,
                )
                TextButton(onClick = onRetry) {
                    Text(stringResource(R.string.retry), color = NcSecondary)
                }
            }
        }

        GradientButton(
            text = stringResource(R.string.edit_profile),
            onClick = onEditProfile,
            enabled = state.profile != null,
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NcCard, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.notifications_setting), color = NcTextPrimary)
                if (notificationsBlocked) {
                    Text(
                        stringResource(R.string.notifications_blocked),
                        color = NcError, fontSize = 12.sp,
                    )
                }
            }
            Switch(
                checked = notificationsEnabled,
                onCheckedChange = onToggleNotifications,
                colors = SwitchDefaults.colors(checkedTrackColor = NcPrimary),
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NcCard, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.presence_setting), color = NcTextPrimary)
                Text(
                    stringResource(R.string.presence_setting_hint),
                    color = NcTextSecondary, fontSize = 12.sp,
                )
            }
            Switch(
                checked = presenceSharing,
                onCheckedChange = onTogglePresence,
                colors = SwitchDefaults.colors(checkedTrackColor = NcPrimary, checkedThumbColor = NcOnPrimary),
            )
        }
        if (pinSet) {
            OutlinedButton(
                onClick = { pinFlow = 1 },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, NcOutline),
            ) {
                Text(stringResource(R.string.pin_change), color = NcTextPrimary)
            }
            OutlinedButton(
                onClick = { pinFlow = 3 },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, NcOutline),
            ) {
                Text(stringResource(R.string.pin_remove), color = NcError)
            }
        }
        OutlinedButton(
            onClick = { showAppearance = true },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NcOutline),
        ) {
            Text(stringResource(R.string.chat_appearance), color = NcTextPrimary)
        }
        OutlinedButton(
            onClick = onSignOut,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NcOutline),
        ) {
            Text(stringResource(R.string.sign_out), color = NcTextPrimary)
        }
        OutlinedButton(
            onClick = { confirmDelete = true },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, NcError.copy(alpha = 0.5f)),
        ) {
            Text(stringResource(R.string.delete_account), color = NcError)
        }
    }

    if (showAppearance) AppearanceDialog(onDismiss = { showAppearance = false })

    when (pinFlow) {
        1 -> PinVerifyDialog(
            title = stringResource(R.string.pin_enter_current),
            subtitle = null,
            onDismiss = { pinFlow = 0 },
            verify = lockVm::verify,
            remainingMillis = lockVm::lockoutRemainingMillis,
            onVerified = { pinFlow = 2 },
        )
        2 -> PinCreateDialog(
            onDismiss = { pinFlow = 0 },
            onCreated = { pin ->
                pinScope.launch { lockVm.setPin(pin) }
                pinFlow = 0
            },
        )
        3 -> PinVerifyDialog(
            title = stringResource(R.string.pin_enter_current),
            subtitle = stringResource(R.string.pin_remove_warning),
            onDismiss = { pinFlow = 0 },
            verify = lockVm::verify,
            remainingMillis = lockVm::lockoutRemainingMillis,
            onVerified = {
                lockVm.removePin()
                pinFlow = 0
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            textContentColor = NcTextSecondary,
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDeleteAccount()
                }) { Text(stringResource(R.string.delete), color = NcError) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(stringResource(R.string.cancel), color = NcTextPrimary)
                }
            },
        )
    }
}

@Composable
private fun ProfileCard(profile: Profile, onShare: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcCard, RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AvatarInitial(profile.displayName, size = 56.dp, imageUrl = profile.avatarUrl)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                profile.displayName,
                color = NcTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
            )
            Text("@${profile.username}", color = NcSecondary, fontSize = 14.sp)
            profile.country?.let {
                Text(it, color = NcTextSecondary, fontSize = 12.sp)
            }
        }
        IconButton(onClick = onShare) {
            Icon(
                Icons.Outlined.Share,
                contentDescription = stringResource(R.string.share_account),
                tint = NcSecondary,
            )
        }
    }
}

@Composable
private fun HomeTopBar(
    title: String,
    online: Boolean,
    profile: Profile?,
    onAvatar: () -> Unit,
    onNewGroup: () -> Unit,
    onNewChat: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcBackground)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.clip(CircleShape).clickable(onClick = onAvatar)) {
            AvatarInitial(profile?.displayName ?: "?", size = 40.dp, imageUrl = profile?.avatarUrl)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = NcTextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (!online) {
                Text(stringResource(R.string.offline), color = NcError, fontSize = 11.sp)
            }
        }
        RoundIcon(Icons.Outlined.GroupAdd, stringResource(R.string.new_group), filled = false, onClick = onNewGroup)
        Spacer(Modifier.width(8.dp))
        RoundIcon(Icons.Outlined.AddComment, stringResource(R.string.new_chat), filled = true, onClick = onNewChat)
    }
}

@Composable
private fun RoundIcon(icon: ImageVector, description: String, filled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (filled) Brush.horizontalGradient(listOf(NcPrimary, NcSecondary)) else SolidColor(NcCard))
            .then(if (filled) Modifier else Modifier.border(1.dp, NcOutline, CircleShape))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = if (filled) NcOnPrimary else NcPrimary, modifier = Modifier.size(20.dp))
    }
}

/** Floating rounded navigation bar with an unread badge on Chats. */
@Composable
private fun FloatingNavBar(selected: Int, onSelect: (Int) -> Unit, unread: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        val shape = RoundedCornerShape(32.dp)
        Row(
            modifier = Modifier
                .background(NcSurface, shape)
                .border(1.dp, NcOutline, shape)
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            tabs.forEachIndexed { index, t ->
                val isSelected = index == selected
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(26.dp))
                        .background(if (isSelected) NcPrimary.copy(alpha = 0.16f) else Color.Transparent)
                        .clickable { onSelect(index) }
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box {
                        Icon(
                            t.icon,
                            contentDescription = null,
                            tint = if (isSelected) NcPrimary else NcTextSecondary,
                        )
                        if (index == 0 && unread > 0) {
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(start = 14.dp)
                                    .background(NcPrimary, CircleShape)
                                    .padding(horizontal = 5.dp, vertical = 1.dp),
                            ) {
                                Text(
                                    if (unread > 99) "99+" else unread.toString(),
                                    color = NcOnPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                    Text(
                        stringResource(t.labelRes),
                        color = if (isSelected) NcPrimary else NcTextSecondary,
                        fontSize = 11.sp,
                    )
                }
            }
        }
    }
}

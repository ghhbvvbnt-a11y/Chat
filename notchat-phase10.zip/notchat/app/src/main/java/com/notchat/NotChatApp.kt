package com.notchat

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.notchat.data.local.ChatLockStore
import com.notchat.presence.PresenceManager
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class NotChatApp : Application() {
    @Inject lateinit var presenceManager: PresenceManager
    @Inject lateinit var chatLockStore: ChatLockStore

    override fun onCreate() {
        super.onCreate()
        ProcessLifecycleOwner.get().lifecycle.addObserver(presenceManager)
        ProcessLifecycleOwner.get().lifecycle.addObserver(chatLockStore)
    }
}

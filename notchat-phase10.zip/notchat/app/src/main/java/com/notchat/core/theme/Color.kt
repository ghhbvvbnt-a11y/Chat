package com.notchat.core.theme

import androidx.compose.ui.graphics.Color

// Chatro palette: near-black surfaces with the neon green / teal of the app icon.
val NcBackground = Color(0xFF050808)
val NcSurface = Color(0xFF0B1112)
val NcCard = Color(0xFF121B1C)
val NcPrimary = Color(0xFF18FB74)
val NcSecondary = Color(0xFF1CE3C3)
val NcOnPrimary = Color(0xFF03140A) // text/icons placed on neon green
val NcTextPrimary = Color(0xFFFFFFFF)
val NcTextSecondary = Color(0xFF8DA39D)
val NcError = Color(0xFFFF4D67)
val NcOutline = Color(0xFF1E2D2B)

package com.notchat.presentation.chat

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcOnPrimary
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.domain.model.BubbleShape
import com.notchat.domain.model.BubbleTheme
import com.notchat.domain.model.ChatBackground

/** Gradient (start, end) used for the bubbles I send. */
fun BubbleTheme.gradient(): Pair<Color, Color> = when (this) {
    BubbleTheme.GREEN -> Color(0xFF22E873) to Color(0xFF19D4B8)
    BubbleTheme.OCEAN -> Color(0xFF1B6C9E) to Color(0xFF2B86BD)
    BubbleTheme.VIOLET -> NcPrimary to Color(0xFF9B7BFF)
    BubbleTheme.TEAL -> Color(0xFF00A99D) to Color(0xFF00D1C1)
    BubbleTheme.ROSE -> Color(0xFFD63C75) to Color(0xFFFF6B9A)
    BubbleTheme.SUNSET -> Color(0xFFFF7A45) to Color(0xFFE0457B)
    BubbleTheme.MONO -> Color(0xFF343A52) to Color(0xFF4A5170)
}

/** Text/icon color that stays readable on top of the bubble gradient. */
fun BubbleTheme.contentColor(): Color = when (this) {
    BubbleTheme.GREEN, BubbleTheme.TEAL -> NcOnPrimary
    else -> Color.White
}

fun BubbleTheme.brush(): Brush = gradient().let { (a, b) -> Brush.linearGradient(listOf(a, b)) }

/** [tail] is false for all but the last bubble of a run from the same sender. */
fun BubbleShape.bubble(mine: Boolean, tail: Boolean = true): Shape = when (this) {
    BubbleShape.ROUNDED -> RoundedCornerShape(
        topStart = 18.dp, topEnd = 18.dp,
        bottomStart = if (mine || !tail) 18.dp else 4.dp,
        bottomEnd = if (!mine || !tail) 18.dp else 4.dp,
    )
    BubbleShape.PILL -> RoundedCornerShape(26.dp)
    BubbleShape.CLASSIC -> RoundedCornerShape(
        topStart = 10.dp, topEnd = 10.dp,
        bottomStart = if (mine || !tail) 10.dp else 2.dp,
        bottomEnd = if (!mine || !tail) 10.dp else 2.dp,
    )
    BubbleShape.SQUARE -> RoundedCornerShape(4.dp)
}

/** Full-size chat wallpaper. */
@Composable
fun ChatBackgroundLayer(background: ChatBackground, modifier: Modifier = Modifier.fillMaxSize()) {
    Box(modifier.background(NcBackground)) {
        when (background) {
            ChatBackground.DARK -> Unit
            ChatBackground.GREEN_GLOW -> Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        listOf(NcPrimary.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset.Zero, radius = 1200f,
                    ),
                ),
            )
            ChatBackground.VIOLET_GLOW -> Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        listOf(NcPrimary.copy(alpha = 0.30f), Color.Transparent),
                        center = Offset.Zero, radius = 1100f,
                    ),
                ),
            )
            ChatBackground.TEAL_GLOW -> Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        listOf(NcSecondary.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset.Zero, radius = 1100f,
                    ),
                ),
            )
            ChatBackground.AURORA -> {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.radialGradient(
                            listOf(NcPrimary.copy(alpha = 0.28f), Color.Transparent),
                            center = Offset(0f, 0f), radius = 900f,
                        ),
                    ),
                )
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.radialGradient(
                            listOf(NcSecondary.copy(alpha = 0.20f), Color.Transparent),
                            center = Offset(1400f, 1800f), radius = 1000f,
                        ),
                    ),
                )
            }
            ChatBackground.DOTS -> Canvas(Modifier.fillMaxSize()) {
                val step = 28.dp.toPx()
                val radius = 1.4.dp.toPx()
                var y = step / 2
                while (y < size.height) {
                    var x = step / 2
                    while (x < size.width) {
                        drawCircle(Color.White.copy(alpha = 0.09f), radius, Offset(x, y))
                        x += step
                    }
                    y += step
                }
            }
        }
    }
}

package com.notchat.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.notchat.MainActivity
import com.notchat.data.local.ChatLockStore
import com.notchat.R
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationType
import com.notchat.domain.model.MessageKind
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context,
    private val chatLock: ChatLockStore,
) {
    private val manager = NotificationManagerCompat.from(context)

    init {
        createChannels()
    }

    fun canNotify(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    /** The permanent (silent) notification Android requires while the connection service runs. */
    fun ongoingNotification(): Notification =
        NotificationCompat.Builder(context, CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.notif_service_text))
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(openIntent(null))
            .build()

    @SuppressLint("MissingPermission") // checked by canNotify()
    fun show(c: Conversation) {
        if (!canNotify()) return
        val locked = chatLock.isLocked(c.id)
        val preview = if (locked) context.getString(R.string.notif_new_message) else previewText(c)
        val title = if (locked) context.getString(R.string.app_name) else c.title
        // Lock screens only show a generic text, never the message itself.
        val public = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.notif_new_message))
            .build()
        val notification = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(preview)
            .setStyle(NotificationCompat.BigTextStyle().bigText(preview))
            .setNumber(c.unreadCount)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(public)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openIntent(c.id))
            .build()
        manager.notify(c.id.hashCode(), notification)
    }

    fun clear(conversationId: String) {
        manager.cancel(conversationId.hashCode())
    }

    private fun previewText(c: Conversation): String {
        val content = when (c.lastMessageKind) {
            MessageKind.TEXT -> c.lastMessageBody
            MessageKind.IMAGE -> context.getString(R.string.media_photo)
            MessageKind.VIDEO -> context.getString(R.string.media_video)
            MessageKind.AUDIO -> context.getString(R.string.media_voice)
            MessageKind.FILE -> context.getString(R.string.media_file)
        }
        val sender = c.lastMessageSenderName
        return if (c.type == ConversationType.GROUP && sender != null) "$sender: $content" else content
    }

    private fun openIntent(conversationId: String?): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (conversationId != null) putExtra(MainActivity.EXTRA_CONVERSATION_ID, conversationId)
        }
        return PendingIntent.getActivity(
            context,
            conversationId?.hashCode() ?: 0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_MESSAGES,
                context.getString(R.string.channel_messages),
                NotificationManager.IMPORTANCE_HIGH,
            ),
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_SERVICE,
                context.getString(R.string.channel_service),
                NotificationManager.IMPORTANCE_MIN,
            ),
        )
    }

    private companion object {
        const val CHANNEL_MESSAGES = "messages"
        const val CHANNEL_SERVICE = "background_connection"
    }
}

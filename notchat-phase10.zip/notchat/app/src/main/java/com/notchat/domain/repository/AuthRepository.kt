package com.notchat.domain.repository

import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.model.SessionState
import kotlinx.coroutines.flow.StateFlow

interface AuthRepository {
    val sessionState: StateFlow<SessionState>

    /** Loads the saved session (refreshing it if needed). Safe to call offline. */
    suspend fun restoreSession()

    /** Success(true) = email confirmation required; Success(false) = signed in immediately. */
    suspend fun signUp(email: String, password: String, username: String, displayName: String): Outcome<Boolean>

    suspend fun signIn(email: String, password: String): Outcome<Unit>
    suspend fun sendPasswordReset(email: String): Outcome<Unit>
    suspend fun signOut()
    suspend fun isUsernameAvailable(username: String): Outcome<Boolean>
    suspend fun currentProfile(): Outcome<Profile>
    suspend fun deleteAccount(): Outcome<Unit>

    /** A non-expired access token (refreshed if needed), or null when signed out. */
    suspend fun validAccessToken(): String?
}

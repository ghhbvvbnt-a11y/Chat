package com.notchat.presentation.profile

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.repository.ChatRepository
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProfileUiState(
    val loading: Boolean = true,
    val profile: Profile? = null,
    val notFound: Boolean = false,
    val error: AuthError? = null,
    val starting: Boolean = false,
    val chatError: AuthError? = null,
    val isContact: Boolean = false,
    val contactBusy: Boolean = false,
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repo: UserRepository,
    private val chat: ChatRepository,
) : ViewModel() {

    private val username: String = savedStateHandle.get<String>("username").orEmpty()

    private val _ui = MutableStateFlow(ProfileUiState())
    val ui: StateFlow<ProfileUiState> = _ui.asStateFlow()

    private val _chatReady = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val chatReady: SharedFlow<String> = _chatReady.asSharedFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null, notFound = false) }
            when (val r = repo.profileByUsername(username)) {
                is Outcome.Success -> {
                    val p = r.value
                    _ui.value = if (p != null) ProfileUiState(loading = false, profile = p)
                    else ProfileUiState(loading = false, notFound = true)
                    if (p != null) {
                        val c = repo.isContact(p.id)
                        if (c is Outcome.Success) _ui.update { it.copy(isContact = c.value) }
                    }
                }
                is Outcome.Failure -> _ui.value = ProfileUiState(loading = false, error = r.error)
            }
        }
    }

    fun toggleContact() {
        val state = _ui.value
        val profile = state.profile ?: return
        if (state.contactBusy) return
        _ui.update { it.copy(contactBusy = true) }
        viewModelScope.launch {
            val r = if (state.isContact) repo.removeContact(profile.id) else repo.addContact(profile.id)
            _ui.update {
                if (r is Outcome.Success) it.copy(contactBusy = false, isContact = !state.isContact)
                else it.copy(contactBusy = false)
            }
        }
    }

    fun startChat() {
        val profile = _ui.value.profile ?: return
        if (_ui.value.starting) return
        _ui.update { it.copy(starting = true, chatError = null) }
        viewModelScope.launch {
            when (val r = chat.startConversation(profile.id)) {
                is Outcome.Success -> {
                    _ui.update { it.copy(starting = false) }
                    _chatReady.tryEmit(r.value)
                }
                is Outcome.Failure -> _ui.update { it.copy(starting = false, chatError = r.error) }
            }
        }
    }
}

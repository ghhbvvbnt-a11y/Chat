package com.notchat.notify

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ProcessLifecycleOwner
import com.notchat.domain.NotificationPlanner
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.ChatRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Keeps the live connection open while the app is in the background and posts a notification
 * for new messages. This replaces push (FCM): it is best effort, because some phone makers
 * stop background services to save battery.
 */
@AndroidEntryPoint
class MessageService : Service() {
    @Inject lateinit var chat: ChatRepository
    @Inject lateinit var auth: AuthRepository
    @Inject lateinit var helper: NotificationHelper

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var running = false
    private var snapshot: Map<String, Long>? = null
    private val reportedDelivered = HashMap<String, String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(
            this, ONGOING_ID, helper.ongoingNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
        if (!running) {
            running = true
            chat.startRealtime()
            scope.launch { loop() }
        }
        return START_STICKY
    }

    @OptIn(FlowPreview::class)
    private suspend fun loop() = coroutineScope {
        launch { chat.changes.debounce(300).collect { check() } }
        launch {
            while (true) {
                delay(60_000L)
                check()
            }
        }
        check()
    }

    private suspend fun check() {
        val state = auth.sessionState.value
        if (state !is SessionState.SignedIn) {
            stopSelf()
            return
        }
        val result = chat.conversations()
        if (result !is Outcome.Success) return
        val inForeground = withContext(Dispatchers.Main) {
            ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        }
        val plan = NotificationPlanner.plan(
            previous = snapshot,
            current = result.value,
            myId = state.userId,
            activeConversationId = ActiveChat.id,
            appInForeground = inForeground,
        )
        snapshot = plan.newState
        plan.toNotify.forEach { helper.show(it) }

        // Tell senders their message reached this phone (the double tick).
        for (c in result.value) {
            if (!c.hasMessages || c.lastMessageSenderId == state.userId) continue
            if (reportedDelivered[c.id] == c.lastMessageAtRaw) continue
            if (chat.markDelivered(c.id, c.lastMessageAtRaw) is Outcome.Success) {
                reportedDelivered[c.id] = c.lastMessageAtRaw
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        if (running) chat.stopRealtime()
        running = false
        super.onDestroy()
    }

    private companion object {
        const val ONGOING_ID = 1001
    }
}

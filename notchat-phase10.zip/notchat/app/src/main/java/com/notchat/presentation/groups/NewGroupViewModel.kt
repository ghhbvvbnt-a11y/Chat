package com.notchat.presentation.groups

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.repository.ChatRepository
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class NewGroupUiState(
    val loading: Boolean = true,
    val contacts: List<Profile> = emptyList(),
    val name: String = "",
    val selected: Set<String> = emptySet(),
    val creating: Boolean = false,
    val error: AuthError? = null,
) {
    val canCreate: Boolean get() = name.isNotBlank() && selected.isNotEmpty() && !creating
}

@HiltViewModel
class NewGroupViewModel @Inject constructor(
    private val users: UserRepository,
    private val chat: ChatRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(NewGroupUiState())
    val ui: StateFlow<NewGroupUiState> = _ui.asStateFlow()

    private val _created = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val created: SharedFlow<String> = _created.asSharedFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null) }
            when (val r = users.contacts()) {
                is Outcome.Success -> _ui.update { it.copy(loading = false, contacts = r.value) }
                is Outcome.Failure -> _ui.update { it.copy(loading = false, error = r.error) }
            }
        }
    }

    fun onNameChange(value: String) = _ui.update { it.copy(name = value.take(60)) }

    fun toggle(userId: String) = _ui.update {
        it.copy(selected = if (userId in it.selected) it.selected - userId else it.selected + userId)
    }

    fun create() {
        val s = _ui.value
        if (!s.canCreate) return
        _ui.update { it.copy(creating = true, error = null) }
        viewModelScope.launch {
            when (val r = chat.createGroup(s.name, s.selected.toList())) {
                is Outcome.Success -> {
                    _ui.update { it.copy(creating = false) }
                    _created.tryEmit(r.value)
                }
                is Outcome.Failure -> _ui.update { it.copy(creating = false, error = r.error) }
            }
        }
    }
}

package com.notchat.data.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.exifinterface.media.ExifInterface
import com.notchat.domain.MediaRules
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.LocalMedia
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.Outcome
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max

/**
 * Turns a picked file into something safe to upload: validates type and size, compresses
 * photos (max 1600 px, JPEG 80), and copies everything to the app cache so the original
 * is never touched. Runs on a background thread.
 */
@Singleton
class MediaPreparer @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    suspend fun prepare(uri: Uri): Outcome<LocalMedia> = withContext(Dispatchers.IO) {
        try {
            prepareBlocking(uri)
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            Outcome.Failure(AuthError.UNSUPPORTED_FILE)
        } catch (e: RuntimeException) {
            Outcome.Failure(AuthError.UNSUPPORTED_FILE)
        }
    }

    /** Center-crops a picked photo to a 512x512 JPEG for use as a profile picture. */
    suspend fun prepareAvatar(uri: Uri): Outcome<File> = withContext(Dispatchers.IO) {
        try {
            avatarBlocking(uri)
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            Outcome.Failure(AuthError.UNSUPPORTED_FILE)
        } catch (e: RuntimeException) {
            Outcome.Failure(AuthError.UNSUPPORTED_FILE)
        }
    }

    private fun avatarBlocking(uri: Uri): Outcome<File> {
        val resolver = context.contentResolver
        val mime = (resolver.getType(uri) ?: guessMime(uri)).lowercase()
        if (!mime.startsWith("image/") || mime == "image/gif") return Outcome.Failure(AuthError.UNSUPPORTED_FILE)

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return Outcome.Failure(AuthError.UNSUPPORTED_FILE)

        var sample = 1
        while (minOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= AVATAR_PX) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: return Outcome.Failure(AuthError.UNSUPPORTED_FILE)

        val rotation = resolver.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        val upright = if (rotation != 0) {
            val m = Matrix().apply { postRotate(rotation.toFloat()) }
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
        } else {
            decoded
        }
        val side = minOf(upright.width, upright.height)
        val square = Bitmap.createBitmap(upright, (upright.width - side) / 2, (upright.height - side) / 2, side, side)
        val finalBitmap = if (side > AVATAR_PX) Bitmap.createScaledBitmap(square, AVATAR_PX, AVATAR_PX, true) else square

        val out = File(context.cacheDir, "avatar_${System.nanoTime()}.jpg")
        out.outputStream().use { finalBitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return Outcome.Success(out)
    }

    private fun prepareBlocking(uri: Uri): Outcome<LocalMedia> {
        val resolver = context.contentResolver
        val mime = (resolver.getType(uri) ?: guessMime(uri)).lowercase()
        if (!MediaRules.isAllowed(mime)) return Outcome.Failure(AuthError.UNSUPPORTED_FILE)

        val (name, size) = nameAndSize(uri)
        val kind = MessageKind.fromMime(mime)
        val isStillImage = kind == MessageKind.IMAGE && mime != "image/gif"
        if (!isStillImage && size != null && size > MediaRules.MAX_BYTES) {
            return Outcome.Failure(AuthError.FILE_TOO_LARGE)
        }
        return if (isStillImage) compressImage(uri, name) else copyAsIs(uri, name, mime, kind)
    }

    private fun compressImage(uri: Uri, originalName: String): Outcome<LocalMedia> {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return Outcome.Failure(AuthError.UNSUPPORTED_FILE)

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MediaRules.IMAGE_MAX_SIDE_PX) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        var bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: return Outcome.Failure(AuthError.UNSUPPORTED_FILE)

        val rotation = resolver.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        val longest = max(bitmap.width, bitmap.height)
        val scale = if (longest > MediaRules.IMAGE_MAX_SIDE_PX) MediaRules.IMAGE_MAX_SIDE_PX.toFloat() / longest else 1f
        if (scale < 1f || rotation != 0) {
            val matrix = Matrix().apply {
                postScale(scale, scale)
                postRotate(rotation.toFloat())
            }
            val transformed = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (transformed !== bitmap) bitmap.recycle()
            bitmap = transformed
        }

        val out = File(context.cacheDir, "img_${System.nanoTime()}.jpg")
        out.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, MediaRules.IMAGE_JPEG_QUALITY, it) }
        val width = bitmap.width
        val height = bitmap.height
        bitmap.recycle()

        val name = originalName.substringBeforeLast('.', originalName) + ".jpg"
        return Outcome.Success(
            LocalMedia(out, MessageKind.IMAGE, name, "image/jpeg", out.length(), width, height, null),
        )
    }

    private fun copyAsIs(uri: Uri, name: String, mime: String, kind: MessageKind): Outcome<LocalMedia> {
        val ext = name.substringAfterLast('.', "").ifEmpty {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "bin"
        }
        val out = File(context.cacheDir, "up_${System.nanoTime()}.$ext")
        var total = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            out.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    if (total > MediaRules.MAX_BYTES) {
                        output.close()
                        out.delete()
                        return Outcome.Failure(AuthError.FILE_TOO_LARGE)
                    }
                    output.write(buffer, 0, read)
                }
            }
        } ?: return Outcome.Failure(AuthError.UNSUPPORTED_FILE)

        var width: Int? = null
        var height: Int? = null
        var duration: Int? = null
        if (kind == MessageKind.VIDEO || kind == MessageKind.AUDIO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(out.absolutePath)
                duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull()
                if (kind == MessageKind.VIDEO) {
                    width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                    height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                }
            } catch (e: RuntimeException) {
                // Metadata is optional; the file can still be sent.
            } finally {
                retriever.release()
            }
        }
        return Outcome.Success(LocalMedia(out, kind, name, mime, total, width, height, duration))
    }

    private fun nameAndSize(uri: Uri): Pair<String, Long?> {
        var name = "file"
        var size: Long? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0 && !c.isNull(nameIdx)) name = c.getString(nameIdx)
                if (sizeIdx >= 0 && !c.isNull(sizeIdx)) size = c.getLong(sizeIdx)
            }
        }
        return name to size
    }

    private fun guessMime(uri: Uri): String {
        val ext = MimeTypeMap.getFileExtensionFromUrl(uri.toString())
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext?.lowercase()) ?: "application/octet-stream"
    }

    private companion object {
        const val AVATAR_PX = 512
    }
}

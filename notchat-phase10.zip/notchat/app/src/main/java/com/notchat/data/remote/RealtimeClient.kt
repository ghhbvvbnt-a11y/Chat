package com.notchat.data.remote

import com.notchat.domain.model.TypingEvent
import com.notchat.domain.model.TypingState
import com.notchat.domain.repository.AuthRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Supabase Realtime over a raw WebSocket (Phoenix protocol).
 * It only emits a "something changed" hint on [changes]; the app then re-fetches real data
 * through the normal REST calls, so row-level security is always enforced by the server.
 * Reconnects automatically with backoff and keeps the access token fresh.
 */
@Singleton
class RealtimeClient @Inject constructor(
    private val http: SupabaseHttp,
    private val auth: AuthRepository,
) {
    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    private val _changes = MutableSharedFlow<Unit>(
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val changes: SharedFlow<Unit> = _changes.asSharedFlow()

    private val _typing = MutableSharedFlow<TypingEvent>(
        extraBufferCapacity = 32,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    /** Live "typing / recording" signals from other people (Realtime broadcast, nothing is stored). */
    val typing: SharedFlow<TypingEvent> = _typing.asSharedFlow()

    private val typingChats = CopyOnWriteArraySet<String>()
    private val extraRefs = AtomicInteger(100)
    @Volatile private var socket: WebSocket? = null
    @Volatile private var channelReady = false
    @Volatile private var currentToken = ""

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    /** Every start() must be paired with one stop(); the socket closes when nobody needs it. */
    private var holders = 0

    @Synchronized
    fun start() {
        holders++
        if (!http.configured || job?.isActive == true) return
        job = scope.launch { loop() }
    }

    @Synchronized
    fun stop() {
        if (holders > 0) holders--
        if (holders > 0) return
        job?.cancel()
        job = null
        _connected.value = false
    }

    fun joinTyping(conversationId: String) {
        if (typingChats.add(conversationId) && channelReady) {
            socket?.send(typingJoinMessage(conversationId, currentToken))
        }
    }

    fun leaveTyping(conversationId: String) {
        if (typingChats.remove(conversationId) && channelReady) {
            socket?.send(leaveMessage(conversationId))
        }
    }

    fun sendTyping(conversationId: String, userId: String, state: TypingState) {
        if (!channelReady || conversationId !in typingChats) return
        socket?.send(
            JSONObject()
                .put("topic", typingTopic(conversationId))
                .put("event", "broadcast")
                .put(
                    "payload",
                    JSONObject()
                        .put("type", "broadcast")
                        .put("event", "typing")
                        .put("payload", JSONObject().put("user_id", userId).put("state", state.wire)),
                )
                .put("ref", extraRefs.incrementAndGet().toString())
                .toString(),
        )
    }

    private fun handleBroadcast(o: JSONObject) {
        val topic = o.optString("topic")
        if (!topic.startsWith(TYPING_PREFIX)) return
        val outer = o.optJSONObject("payload") ?: return
        if (outer.optString("event") != "typing") return
        val body = outer.optJSONObject("payload") ?: return
        val userId = body.optString("user_id")
        if (userId.isEmpty()) return
        _typing.tryEmit(
            TypingEvent(topic.removePrefix(TYPING_PREFIX), userId, TypingState.fromWire(body.optString("state"))),
        )
    }

    private suspend fun loop() {
        var failures = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val token = auth.validAccessToken()
            if (token == null) {
                delay(5_000)
                continue
            }
            val joined = try {
                connectOnce(token)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                false
            }
            _connected.value = false
            failures = if (joined) 0 else minOf(failures + 1, 5)
            delay(minOf(1_000L shl failures, 30_000L))
        }
    }

    /** Suspends until the socket closes. Returns true if the channel had been joined successfully. */
    private suspend fun connectOnce(initialToken: String): Boolean = coroutineScope {
        val done = CompletableDeferred<Unit>()
        val joined = AtomicBoolean(false)
        val acked = AtomicBoolean(true)
        val refs = AtomicInteger(1)

        val ws = okHttp.newWebSocket(
            Request.Builder().url(http.realtimeUrl()).build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    webSocket.send(joinMessage(initialToken))
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    val o = try {
                        JSONObject(text)
                    } catch (e: JSONException) {
                        return
                    }
                    when (o.optString("event")) {
                        "phx_reply" -> {
                            val status = o.optJSONObject("payload")?.optString("status").orEmpty()
                            if (o.optString("ref") == JOIN_REF) {
                                if (status == "ok") {
                                    joined.set(true)
                                    _connected.value = true
                                    currentToken = initialToken
                                    channelReady = true
                                    typingChats.forEach { webSocket.send(typingJoinMessage(it, initialToken)) }
                                    _changes.tryEmit(Unit) // resync after (re)connect
                                } else {
                                    webSocket.cancel()
                                }
                            } else {
                                acked.set(true)
                            }
                        }
                        "postgres_changes" -> _changes.tryEmit(Unit)
                        "broadcast" -> handleBroadcast(o)
                        "phx_error", "phx_close" -> webSocket.cancel()
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(code, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    done.complete(Unit)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    done.complete(Unit)
                }
            },
        )

        socket = ws

        val heartbeat = launch {
            var lastToken = initialToken
            while (true) {
                delay(HEARTBEAT_MS)
                if (!acked.get()) { // no reply to the previous heartbeat: connection is dead
                    ws.cancel()
                    break
                }
                acked.set(false)
                ws.send(heartbeatMessage(refs.incrementAndGet()))
                val fresh = auth.validAccessToken()
                if (fresh != null && fresh != lastToken) {
                    ws.send(accessTokenMessage(fresh))
                    typingChats.forEach { ws.send(accessTokenMessage(fresh, typingTopic(it))) }
                    currentToken = fresh
                    lastToken = fresh
                }
            }
        }

        try {
            done.await()
        } finally {
            channelReady = false
            socket = null
            heartbeat.cancel()
            ws.cancel()
        }
        joined.get()
    }

    private fun postgresChange(event: String, table: String) =
        JSONObject().put("event", event).put("schema", "public").put("table", table)

    private fun joinMessage(token: String): String {
        val config = JSONObject()
            .put("broadcast", JSONObject().put("ack", false).put("self", false))
            .put("presence", JSONObject().put("key", ""))
            .put(
                "postgres_changes",
                JSONArray()
                    .put(postgresChange("INSERT", "messages"))
                    .put(postgresChange("UPDATE", "messages"))
                    .put(postgresChange("INSERT", "conversation_members"))
                    .put(postgresChange("UPDATE", "conversation_members"))
                    .put(postgresChange("INSERT", "message_views")),
            )
            .put("private", false)
        return JSONObject()
            .put("topic", TOPIC)
            .put("event", "phx_join")
            .put("ref", JOIN_REF)
            .put("join_ref", JOIN_REF)
            .put("payload", JSONObject().put("config", config).put("access_token", token))
            .toString()
    }

    private fun heartbeatMessage(ref: Int): String = JSONObject()
        .put("topic", "phoenix")
        .put("event", "heartbeat")
        .put("payload", JSONObject())
        .put("ref", ref.toString())
        .toString()

    private fun typingTopic(conversationId: String) = TYPING_PREFIX + conversationId

    private fun typingJoinMessage(conversationId: String, token: String): String {
        val ref = extraRefs.incrementAndGet().toString()
        val config = JSONObject()
            .put("broadcast", JSONObject().put("ack", false).put("self", false))
            .put("presence", JSONObject().put("key", ""))
            .put("postgres_changes", JSONArray())
            .put("private", false)
        return JSONObject()
            .put("topic", typingTopic(conversationId))
            .put("event", "phx_join")
            .put("ref", ref)
            .put("join_ref", ref)
            .put("payload", JSONObject().put("config", config).put("access_token", token))
            .toString()
    }

    private fun leaveMessage(conversationId: String): String = JSONObject()
        .put("topic", typingTopic(conversationId))
        .put("event", "phx_leave")
        .put("payload", JSONObject())
        .put("ref", extraRefs.incrementAndGet().toString())
        .toString()

    private fun accessTokenMessage(token: String, topic: String = TOPIC): String = JSONObject()
        .put("topic", topic)
        .put("event", "access_token")
        .put("payload", JSONObject().put("access_token", token))
        .put("ref", "token")
        .toString()

    private companion object {
        const val TOPIC = "realtime:notchat-feed"
        const val TYPING_PREFIX = "realtime:typing-"
        const val JOIN_REF = "1"
        const val HEARTBEAT_MS = 25_000L
    }
}

package com.notchat.data.repository

import com.notchat.data.remote.AuthorizedApi
import com.notchat.data.remote.parseMillis
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Presence
import com.notchat.domain.repository.PresenceRepository
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PresenceRepositoryImpl @Inject constructor(
    private val api: AuthorizedApi,
) : PresenceRepository {

    private val http get() = api.http

    override suspend fun touch(): Outcome<Unit> = api.call { token ->
        val r = http.request("POST", "/rest/v1/rpc/touch_presence", accessToken = token)
        if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
    }

    override suspend fun presenceOf(userId: String): Outcome<Presence?> = api.call { token ->
        val r = http.request(
            "POST", "/rest/v1/rpc/presence_of",
            JSONObject().put("p_user", userId), accessToken = token,
        )
        if (r.code !in 200..299) return@call api.failure(r)
        val rows = JSONArray(r.body)
        if (rows.length() == 0) {
            Outcome.Success(null)
        } else {
            val o = rows.getJSONObject(0)
            Outcome.Success(Presence(o.optBoolean("online", false), parseMillis(o.getString("last_seen_at"))))
        }
    }

    override suspend fun sharing(): Outcome<Boolean> = api.call { token ->
        val r = http.request("POST", "/rest/v1/rpc/get_my_presence_sharing", accessToken = token)
        if (r.code in 200..299) Outcome.Success(r.body.trim() != "false") else api.failure(r)
    }

    override suspend fun setSharing(share: Boolean): Outcome<Unit> = api.call { token ->
        val r = http.request(
            "POST", "/rest/v1/rpc/set_presence_sharing",
            JSONObject().put("p_share", share), accessToken = token,
        )
        if (r.code in 200..299) Outcome.Success(Unit) else api.failure(r)
    }
}

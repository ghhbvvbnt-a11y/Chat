package com.notchat.data.remote

import com.notchat.BuildConfig
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class HttpResult(val code: Int, val body: String)

/** Thin HTTPS client for the Supabase Auth and REST (PostgREST) endpoints. */
@Singleton
class SupabaseHttp @Inject constructor() {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val anonKey = BuildConfig.SUPABASE_ANON_KEY
    private val jsonType = "application/json".toMediaType()

    val configured: Boolean
        get() = baseUrl.startsWith("https://") && anonKey.isNotEmpty()

    /** WebSocket endpoint of Supabase Realtime (Phoenix protocol v1). */
    fun realtimeUrl(): String =
        baseUrl.replaceFirst("https://", "wss://") + "/realtime/v1/websocket?apikey=" + anonKey + "&vsn=1.0.0"

    /** Throws [IOException] on network failure. Cancelling the coroutine cancels the call. */
    suspend fun request(
        method: String,
        path: String,
        body: JSONObject? = null,
        accessToken: String? = null,
        headers: Map<String, String> = emptyMap(),
    ): HttpResult {
        val builder = Request.Builder().url(baseUrl + path).header("apikey", anonKey)
        if (accessToken != null) builder.header("Authorization", "Bearer $accessToken")
        headers.forEach { (k, v) -> builder.header(k, v) }
        if (method == "GET") {
            builder.get()
        } else {
            builder.method(method, (body ?: JSONObject()).toString().toRequestBody(jsonType))
        }
        client.newCall(builder.build()).await().use { response ->
            return HttpResult(response.code, response.body?.string().orEmpty())
        }
    }

    private val uploadClient = client.newBuilder()
        .writeTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    /** Streams a file to Supabase Storage (upsert, so a retry overwrites the same path). */
    suspend fun upload(path: String, file: File, mimeType: String, accessToken: String): HttpResult {
        val request = Request.Builder()
            .url(baseUrl + path)
            .header("apikey", anonKey)
            .header("Authorization", "Bearer $accessToken")
            .header("x-upsert", "true")
            .post(file.asRequestBody(mimeType.toMediaType()))
            .build()
        uploadClient.newCall(request).await().use { response ->
            return HttpResult(response.code, response.body?.string().orEmpty())
        }
    }

    fun publicBaseUrl(): String = baseUrl
}

private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { cancel() }
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            cont.resume(response)
        }
    })
}

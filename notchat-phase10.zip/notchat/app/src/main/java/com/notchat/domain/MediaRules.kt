package com.notchat.domain

/** Upload limits. Must match the bucket settings in supabase/migrations/0004_media.sql. */
object MediaRules {
    const val MAX_BYTES: Long = 25L * 1024 * 1024
    const val IMAGE_MAX_SIDE_PX = 1600
    const val IMAGE_JPEG_QUALITY = 80
    const val MAX_VOICE_MS = 5 * 60 * 1000

    private val allowed = setOf(
        "image/jpeg", "image/png", "image/webp", "image/gif", "image/heic", "image/heif",
        "video/mp4", "video/quicktime", "video/3gpp", "video/webm",
        "audio/mp4", "audio/aac", "audio/mpeg", "audio/ogg", "audio/webm",
        "application/pdf", "text/plain", "text/csv", "application/zip",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    )

    fun isAllowed(mime: String): Boolean = mime.lowercase() in allowed
}

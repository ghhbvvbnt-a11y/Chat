package com.notchat.presentation.chat

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.model.BubbleShape
import com.notchat.domain.model.BubbleTheme
import com.notchat.domain.model.ChatAppearance
import com.notchat.domain.model.ChatBackground

private fun BubbleTheme.label() = when (this) {
    BubbleTheme.GREEN -> R.string.theme_green
    BubbleTheme.OCEAN -> R.string.theme_ocean
    BubbleTheme.VIOLET -> R.string.theme_violet
    BubbleTheme.TEAL -> R.string.theme_teal
    BubbleTheme.ROSE -> R.string.theme_rose
    BubbleTheme.SUNSET -> R.string.theme_sunset
    BubbleTheme.MONO -> R.string.theme_mono
}

private fun BubbleShape.label() = when (this) {
    BubbleShape.ROUNDED -> R.string.shape_rounded
    BubbleShape.PILL -> R.string.shape_pill
    BubbleShape.CLASSIC -> R.string.shape_classic
    BubbleShape.SQUARE -> R.string.shape_square
}

private fun ChatBackground.label() = when (this) {
    ChatBackground.GREEN_GLOW -> R.string.bg_green
    ChatBackground.DARK -> R.string.bg_dark
    ChatBackground.VIOLET_GLOW -> R.string.bg_violet
    ChatBackground.TEAL_GLOW -> R.string.bg_teal
    ChatBackground.DOTS -> R.string.bg_dots
    ChatBackground.AURORA -> R.string.bg_aurora
}

/** Pick bubble color, bubble shape and chat background, with a live preview. */
@Composable
fun AppearanceDialog(
    onDismiss: () -> Unit,
    vm: AppearanceViewModel = hiltViewModel(),
) {
    val current by vm.appearance.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NcCard,
        titleContentColor = NcTextPrimary,
        title = { Text(stringResource(R.string.chat_appearance)) },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.done), color = NcSecondary) }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Preview(current)

                SectionTitle(stringResource(R.string.appearance_color))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    BubbleTheme.entries.forEach { theme ->
                        val selected = theme == current.theme
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(theme.brush())
                                .border(
                                    BorderStroke(if (selected) 3.dp else 1.dp, if (selected) NcTextPrimary else NcOutline),
                                    CircleShape,
                                )
                                .clickable { vm.set(current.copy(theme = theme)) },
                        )
                    }
                }

                SectionTitle(stringResource(R.string.appearance_shape))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    BubbleShape.entries.forEach { shape ->
                        OptionChip(stringResource(shape.label()), shape == current.shape) {
                            vm.set(current.copy(shape = shape))
                        }
                    }
                }

                SectionTitle(stringResource(R.string.appearance_background))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    ChatBackground.entries.forEach { bg ->
                        OptionChip(stringResource(bg.label()), bg == current.background) {
                            vm.set(current.copy(background = bg))
                        }
                    }
                }
            }
        },
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = NcTextSecondary, fontSize = 13.sp)
}

@Composable
private fun OptionChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = NcPrimary.copy(alpha = 0.25f),
            selectedLabelColor = NcTextPrimary,
            labelColor = NcTextSecondary,
        ),
    )
}

@Composable
private fun Preview(a: ChatAppearance) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(16.dp)),
    ) {
        ChatBackgroundLayer(a.background)
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                Text(
                    "👋",
                    color = NcTextPrimary,
                    modifier = Modifier
                        .widthIn(max = 200.dp)
                        .background(NcCard, a.shape.bubble(mine = false))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
                Text(
                    "Chatro",
                    color = NcTextPrimary,
                    modifier = Modifier
                        .widthIn(max = 200.dp)
                        .background(a.theme.brush(), a.shape.bubble(mine = true))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
    }
}

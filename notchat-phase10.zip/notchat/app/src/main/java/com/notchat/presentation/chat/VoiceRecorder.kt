package com.notchat.presentation.chat

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import java.io.File

class RecordedVoice(val file: File, val durationMs: Int)

/** Records AAC audio (.m4a) from the microphone into the app cache. Needs RECORD_AUDIO granted. */
class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    fun start(): Boolean {
        cancel()
        val target = File(context.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(64_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(target.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = target
            startedAt = SystemClock.elapsedRealtime()
            true
        } catch (e: Exception) {
            target.delete()
            false
        }
    }

    fun elapsedMs(): Int = if (recorder == null) 0 else (SystemClock.elapsedRealtime() - startedAt).toInt()

    /** Returns the recording, or null if it was too short or failed. */
    fun stop(): RecordedVoice? {
        val r = recorder ?: return null
        val f = file
        val duration = elapsedMs()
        recorder = null
        file = null
        val ok = try {
            r.stop()
            true
        } catch (e: RuntimeException) {
            false // nothing was recorded
        } finally {
            r.release()
        }
        if (!ok || f == null || duration < MIN_MS) {
            f?.delete()
            return null
        }
        return RecordedVoice(f, duration)
    }

    fun cancel() {
        val r = recorder
        val f = file
        recorder = null
        file = null
        if (r != null) {
            try {
                r.stop()
            } catch (e: RuntimeException) {
                // ignored
            }
            r.release()
        }
        f?.delete()
    }

    private companion object {
        const val MIN_MS = 700
    }
}

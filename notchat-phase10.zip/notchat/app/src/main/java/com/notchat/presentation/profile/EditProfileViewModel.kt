package com.notchat.presentation.profile

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.data.media.MediaPreparer
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditProfileUiState(
    val loading: Boolean = true,
    val profile: Profile? = null,
    val loadError: AuthError? = null,
    val saving: Boolean = false,
    val avatarBusy: Boolean = false,
    val error: AuthError? = null,
)

@HiltViewModel
class EditProfileViewModel @Inject constructor(
    private val auth: AuthRepository,
    private val users: UserRepository,
    private val media: MediaPreparer,
) : ViewModel() {

    private val _ui = MutableStateFlow(EditProfileUiState())
    val ui: StateFlow<EditProfileUiState> = _ui.asStateFlow()

    private val _saved = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val saved: SharedFlow<Unit> = _saved.asSharedFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, loadError = null) }
            when (val r = auth.currentProfile()) {
                is Outcome.Success -> _ui.update { it.copy(loading = false, profile = r.value) }
                is Outcome.Failure -> _ui.update { it.copy(loading = false, loadError = r.error) }
            }
        }
    }

    fun save(displayName: String, bio: String, country: String) {
        if (_ui.value.saving) return
        _ui.update { it.copy(saving = true, error = null) }
        viewModelScope.launch {
            when (val r = users.updateProfile(displayName, bio, country.ifBlank { null })) {
                is Outcome.Success -> {
                    _ui.update { it.copy(saving = false, profile = r.value) }
                    _saved.tryEmit(Unit)
                }
                is Outcome.Failure -> _ui.update { it.copy(saving = false, error = r.error) }
            }
        }
    }

    fun setAvatar(uri: Uri) {
        if (_ui.value.avatarBusy) return
        _ui.update { it.copy(avatarBusy = true, error = null) }
        viewModelScope.launch {
            when (val prepared = media.prepareAvatar(uri)) {
                is Outcome.Failure -> _ui.update { it.copy(avatarBusy = false, error = prepared.error) }
                is Outcome.Success -> {
                    when (val r = users.uploadAvatar(prepared.value)) {
                        is Outcome.Success -> _ui.update { it.copy(avatarBusy = false, profile = r.value) }
                        is Outcome.Failure -> _ui.update { it.copy(avatarBusy = false, error = r.error) }
                    }
                    prepared.value.delete()
                }
            }
        }
    }

    fun removeAvatar() {
        if (_ui.value.avatarBusy) return
        _ui.update { it.copy(avatarBusy = true, error = null) }
        viewModelScope.launch {
            when (val r = users.removeAvatar()) {
                is Outcome.Success -> _ui.update { it.copy(avatarBusy = false, profile = r.value) }
                is Outcome.Failure -> _ui.update { it.copy(avatarBusy = false, error = r.error) }
            }
        }
    }
}

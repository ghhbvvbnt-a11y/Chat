package com.notchat.domain

import com.notchat.domain.model.Conversation

data class NotificationPlan(
    /** conversation id -> time of its latest message, to compare against next time. */
    val newState: Map<String, Long>,
    val toNotify: List<Conversation>,
)

/** Decides which conversations deserve a notification. Pure, so it can be unit tested. */
object NotificationPlanner {
    /**
     * @param previous what we saw last time; null on the first check, when nothing is notified
     *        (old unread messages must not produce a burst of notifications at startup).
     */
    fun plan(
        previous: Map<String, Long>?,
        current: List<Conversation>,
        myId: String,
        activeConversationId: String?,
        appInForeground: Boolean,
    ): NotificationPlan {
        val newState = current.associate { it.id to it.lastMessageAtMillis }
        if (previous == null) return NotificationPlan(newState, emptyList())
        val toNotify = current.filter { c ->
            c.hasMessages &&
                !c.lastMessageDeleted &&
                c.lastMessageSenderId != myId &&
                c.unreadCount > 0 &&
                !c.muted &&
                c.id != activeConversationId &&
                !appInForeground &&
                c.lastMessageAtMillis > (previous[c.id] ?: 0L)
        }
        return NotificationPlan(newState, toNotify)
    }
}

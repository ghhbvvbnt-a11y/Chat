package com.notchat.data.remote

import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.repository.AuthRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/** Runs requests with the signed-in user's token and converts failures into [AuthError]s. */
@Singleton
class AuthorizedApi @Inject constructor(
    val http: SupabaseHttp,
    private val auth: AuthRepository,
) {
    suspend fun <T> call(block: suspend (token: String) -> Outcome<T>): Outcome<T> {
        if (!http.configured) return Outcome.Failure(AuthError.NOT_CONFIGURED)
        return withContext(Dispatchers.IO) {
            try {
                val token = auth.validAccessToken()
                    ?: return@withContext Outcome.Failure(AuthError.SESSION_EXPIRED)
                block(token)
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                Outcome.Failure(AuthError.NETWORK)
            } catch (e: JSONException) {
                Outcome.Failure(AuthError.UNKNOWN)
            } catch (e: java.time.format.DateTimeParseException) {
                Outcome.Failure(AuthError.UNKNOWN)
            }
        }
    }

    fun failure(r: HttpResult): Outcome.Failure = Outcome.Failure(
        when {
            r.code == 401 -> AuthError.SESSION_EXPIRED
            r.code == 413 -> AuthError.FILE_TOO_LARGE
            r.body.contains("already_viewed") -> AuthError.ALREADY_VIEWED
            r.body.contains("not_admin") || r.code == 403 -> AuthError.NOT_ALLOWED
            r.code == 415 || r.body.contains("mime type", ignoreCase = true) -> AuthError.UNSUPPORTED_FILE
            r.code == 429 || r.body.contains("rate_limited") -> AuthError.RATE_LIMITED
            else -> AuthError.UNKNOWN
        },
    )
}

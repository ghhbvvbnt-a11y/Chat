package com.notchat.presentation.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import com.notchat.R

/** The Chatro mark (chat bubble with a paper plane), drawn from the artwork in res/drawable-nodpi. */
@Composable
fun NotChatLogo(size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.chatro_mark),
        contentDescription = null,
        modifier = modifier.size(size),
    )
}

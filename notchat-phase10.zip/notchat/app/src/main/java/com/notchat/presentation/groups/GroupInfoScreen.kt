package com.notchat.presentation.groups

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.model.GroupMember
import com.notchat.domain.model.MemberRole
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.NcTextField

@Composable
fun GroupInfoScreen(
    onBack: () -> Unit,
    onLeft: () -> Unit,
    onOpenMember: (username: String) -> Unit,
    vm: GroupInfoViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    var showRename by rememberSaveable { mutableStateOf(false) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var showLeave by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) { vm.left.collect { onLeft() } }

    Scaffold(containerColor = NcBackground) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = NcTextPrimary,
                    )
                }
                Text(
                    stringResource(R.string.group_info),
                    color = NcTextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                )
            }
            val header = ui.header
            when {
                header != null -> Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    AvatarInitial(header.title, size = 96.dp)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            header.title,
                            color = NcTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                        )
                        if (ui.iAmAdmin) {
                            IconButton(onClick = { showRename = true }) {
                                Icon(
                                    Icons.Outlined.Edit,
                                    contentDescription = stringResource(R.string.rename_group),
                                    tint = NcSecondary,
                                )
                            }
                        }
                    }
                    Text(
                        stringResource(R.string.members_count, ui.members.size),
                        color = NcTextSecondary, fontSize = 14.sp,
                    )
                    Spacer(Modifier.height(16.dp))
                    if (ui.iAmAdmin) {
                        OutlinedButton(
                            onClick = {
                                vm.loadCandidates()
                                showAdd = true
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            enabled = !ui.busy,
                        ) {
                            Icon(Icons.Outlined.PersonAdd, contentDescription = null, tint = NcSecondary)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.add_members), color = NcTextPrimary)
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                    ui.error?.let {
                        Text(it.message(), color = NcError, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ui.members.forEach { m ->
                            MemberRow(
                                member = m,
                                isMe = m.userId == vm.myId,
                                canRemove = ui.iAmAdmin && m.userId != vm.myId && !ui.busy,
                                onOpen = { onOpenMember(m.username) },
                                onRemove = { vm.remove(m.userId) },
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    OutlinedButton(
                        onClick = { showLeave = true },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                        enabled = !ui.busy,
                    ) {
                        Text(stringResource(R.string.leave_group), color = NcError)
                    }
                    Spacer(Modifier.height(24.dp))
                }
                ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NcPrimary)
                }
                else -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        ui.loadError?.message() ?: stringResource(R.string.err_generic),
                        color = NcError, textAlign = TextAlign.Center,
                    )
                    TextButton(onClick = vm::load) {
                        Text(stringResource(R.string.retry), color = NcSecondary)
                    }
                }
            }
        }
    }

    if (showRename) {
        var name by remember { mutableStateOf(ui.header?.title.orEmpty()) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            title = { Text(stringResource(R.string.rename_group)) },
            text = {
                NcTextField(
                    value = name,
                    onValueChange = { name = it.take(60) },
                    label = stringResource(R.string.group_name),
                )
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = {
                        showRename = false
                        vm.rename(name)
                    },
                ) { Text(stringResource(R.string.save), color = NcSecondary) }
            },
            dismissButton = {
                TextButton(onClick = { showRename = false }) {
                    Text(stringResource(R.string.cancel), color = NcTextPrimary)
                }
            },
        )
    }

    if (showAdd) {
        var picked by remember { mutableStateOf(setOf<String>()) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            textContentColor = NcTextSecondary,
            title = { Text(stringResource(R.string.add_members)) },
            text = {
                if (ui.candidates.isEmpty()) {
                    Text(stringResource(R.string.no_contacts_to_add))
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        ui.candidates.forEach { p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        picked = if (p.id in picked) picked - p.id else picked + p.id
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                AvatarInitial(p.displayName, size = 36.dp, imageUrl = p.avatarUrl)
                                Spacer(Modifier.width(10.dp))
                                Text(p.displayName, color = NcTextPrimary, modifier = Modifier.weight(1f), maxLines = 1)
                                Checkbox(
                                    checked = p.id in picked,
                                    onCheckedChange = {
                                        picked = if (p.id in picked) picked - p.id else picked + p.id
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = NcPrimary, uncheckedColor = NcOutline),
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = picked.isNotEmpty(),
                    onClick = {
                        showAdd = false
                        vm.add(picked.toList())
                    },
                ) { Text(stringResource(R.string.add), color = NcSecondary) }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) {
                    Text(stringResource(R.string.cancel), color = NcTextPrimary)
                }
            },
        )
    }

    if (showLeave) {
        AlertDialog(
            onDismissRequest = { showLeave = false },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            textContentColor = NcTextSecondary,
            title = { Text(stringResource(R.string.leave_group_title)) },
            text = { Text(stringResource(R.string.leave_group_body)) },
            confirmButton = {
                TextButton(onClick = {
                    showLeave = false
                    vm.leave()
                }) { Text(stringResource(R.string.leave_group), color = NcError) }
            },
            dismissButton = {
                TextButton(onClick = { showLeave = false }) {
                    Text(stringResource(R.string.cancel), color = NcTextPrimary)
                }
            },
        )
    }
}

@Composable
private fun MemberRow(
    member: GroupMember,
    isMe: Boolean,
    canRemove: Boolean,
    onOpen: () -> Unit,
    onRemove: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcCard, RoundedCornerShape(16.dp))
            .clickable(enabled = !isMe, onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AvatarInitial(member.displayName, size = 44.dp, imageUrl = member.avatarUrl)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                member.displayName + if (isMe) " (" + stringResource(R.string.you) + ")" else "",
                color = NcTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            )
            Text("@${member.username}", color = NcSecondary, fontSize = 12.sp, maxLines = 1)
        }
        if (member.role == MemberRole.ADMIN) {
            Text(
                stringResource(R.string.admin_badge),
                color = NcPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(end = 4.dp),
            )
        }
        if (canRemove) {
            IconButton(onClick = onRemove) {
                Icon(
                    Icons.Outlined.Close,
                    contentDescription = stringResource(R.string.remove_member),
                    tint = NcError,
                )
            }
        }
    }
}

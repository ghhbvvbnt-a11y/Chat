package com.notchat.presentation.session

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SessionViewModel @Inject constructor(
    private val repo: AuthRepository,
) : ViewModel() {
    val state: StateFlow<SessionState> = repo.sessionState

    init {
        viewModelScope.launch { repo.restoreSession() }
    }
}

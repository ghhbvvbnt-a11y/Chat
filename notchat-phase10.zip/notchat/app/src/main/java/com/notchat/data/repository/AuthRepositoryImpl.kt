package com.notchat.data.repository

import com.notchat.data.local.SessionStore
import com.notchat.data.remote.AuthErrorMapper
import com.notchat.data.remote.SupabaseHttp
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.model.SessionState
import com.notchat.domain.model.UserSession
import com.notchat.domain.repository.AuthRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepositoryImpl @Inject constructor(
    private val http: SupabaseHttp,
    private val store: SessionStore,
) : AuthRepository {

    private val _state = MutableStateFlow<SessionState>(SessionState.Loading)
    override val sessionState: StateFlow<SessionState> = _state.asStateFlow()
    private val refreshMutex = Mutex()

    override suspend fun restoreSession() {
        withContext(Dispatchers.IO) {
            if (!http.configured || store.load() == null) {
                _state.value = SessionState.SignedOut
                return@withContext
            }
            val session = validSession()
            _state.value =
                if (session != null) SessionState.SignedIn(session.userId) else SessionState.SignedOut
        }
    }

    override suspend fun signUp(
        email: String,
        password: String,
        username: String,
        displayName: String,
    ): Outcome<Boolean> = call {
        val body = JSONObject()
            .put("email", email.trim())
            .put("password", password)
            .put(
                "data",
                JSONObject().put("username", username).put("display_name", displayName.trim()),
            )
        val r = http.request("POST", "/auth/v1/signup", body)
        if (r.code !in 200..299) {
            return@call Outcome.Failure(AuthErrorMapper.fromResponse(r.code, r.body))
        }
        val json = JSONObject(r.body)
        if (json.has("access_token")) {
            val s = parseSession(json)
            store.save(s)
            _state.value = SessionState.SignedIn(s.userId)
            Outcome.Success(false)
        } else {
            Outcome.Success(true)
        }
    }

    override suspend fun signIn(email: String, password: String): Outcome<Unit> = call {
        val body = JSONObject().put("email", email.trim()).put("password", password)
        val r = http.request("POST", "/auth/v1/token?grant_type=password", body)
        if (r.code in 200..299) {
            val s = parseSession(JSONObject(r.body))
            store.save(s)
            _state.value = SessionState.SignedIn(s.userId)
            Outcome.Success(Unit)
        } else {
            Outcome.Failure(AuthErrorMapper.fromResponse(r.code, r.body))
        }
    }

    override suspend fun sendPasswordReset(email: String): Outcome<Unit> = call {
        val r = http.request("POST", "/auth/v1/recover", JSONObject().put("email", email.trim()))
        if (r.code in 200..299) {
            Outcome.Success(Unit)
        } else {
            Outcome.Failure(AuthErrorMapper.fromResponse(r.code, r.body))
        }
    }

    override suspend fun signOut() {
        withContext(Dispatchers.IO) {
            val s = store.load()
            if (s != null && http.configured) {
                try {
                    http.request("POST", "/auth/v1/logout?scope=local", accessToken = s.accessToken)
                } catch (e: IOException) {
                    // Offline: still sign out locally.
                }
            }
            store.clear()
            _state.value = SessionState.SignedOut
        }
    }

    override suspend fun isUsernameAvailable(username: String): Outcome<Boolean> = call {
        val r = http.request(
            "POST",
            "/rest/v1/rpc/is_username_available",
            JSONObject().put("p_username", username),
        )
        if (r.code in 200..299) {
            Outcome.Success(r.body.trim() == "true")
        } else {
            Outcome.Failure(AuthError.UNKNOWN)
        }
    }

    override suspend fun currentProfile(): Outcome<Profile> = call {
        val s = validSession() ?: return@call Outcome.Failure(AuthError.SESSION_EXPIRED)
        val r = http.request(
            "GET",
            "/rest/v1/profiles?id=eq.${s.userId}&select=id,username,display_name,avatar_url,bio,country",
            accessToken = s.accessToken,
            headers = mapOf("Accept" to "application/vnd.pgrst.object+json"),
        )
        when {
            r.code in 200..299 -> {
                val o = JSONObject(r.body)
                Outcome.Success(
                    Profile(
                        id = o.getString("id"),
                        username = o.getString("username"),
                        displayName = o.getString("display_name"),
                        avatarUrl = o.optNullableString("avatar_url"),
                        bio = o.optString("bio", ""),
                        country = o.optNullableString("country"),
                    ),
                )
            }
            r.code == 401 -> {
                expireLocally()
                Outcome.Failure(AuthError.SESSION_EXPIRED)
            }
            else -> Outcome.Failure(AuthError.UNKNOWN)
        }
    }

    override suspend fun deleteAccount(): Outcome<Unit> = call {
        val s = validSession() ?: return@call Outcome.Failure(AuthError.SESSION_EXPIRED)
        val r = http.request("POST", "/rest/v1/rpc/delete_my_account", accessToken = s.accessToken)
        if (r.code in 200..299) {
            store.clear()
            _state.value = SessionState.SignedOut
            Outcome.Success(Unit)
        } else if (r.code == 401) {
            expireLocally()
            Outcome.Failure(AuthError.SESSION_EXPIRED)
        } else {
            Outcome.Failure(AuthError.UNKNOWN)
        }
    }

    override suspend fun validAccessToken(): String? = withContext(Dispatchers.IO) {
        if (!http.configured) null else validSession()?.accessToken
    }

    // ---- helpers -------------------------------------------------------

    private suspend fun <T> call(block: suspend () -> Outcome<T>): Outcome<T> {
        if (!http.configured) return Outcome.Failure(AuthError.NOT_CONFIGURED)
        return withContext(Dispatchers.IO) {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                Outcome.Failure(AuthError.NETWORK)
            } catch (e: JSONException) {
                Outcome.Failure(AuthError.UNKNOWN)
            }
        }
    }

    /** Returns a usable session, refreshing the token when it is about to expire. */
    private suspend fun validSession(): UserSession? = refreshMutex.withLock {
        val s = store.load() ?: return null
        val now = System.currentTimeMillis() / 1000
        if (s.expiresAtSec - now > 60) return s
        try {
            val r = http.request(
                "POST",
                "/auth/v1/token?grant_type=refresh_token",
                JSONObject().put("refresh_token", s.refreshToken),
            )
            when {
                r.code in 200..299 -> {
                    val fresh = parseSession(JSONObject(r.body))
                    store.save(fresh)
                    fresh
                }
                r.code in 400..403 -> {
                    expireLocally()
                    null
                }
                else -> s
            }
        } catch (e: IOException) {
            s // Offline: keep the session and retry later.
        } catch (e: JSONException) {
            s
        }
    }

    private fun expireLocally() {
        store.clear()
        _state.value = SessionState.SignedOut
    }

    private fun parseSession(json: JSONObject): UserSession {
        val now = System.currentTimeMillis() / 1000
        val expiresAt =
            if (json.has("expires_at")) json.getLong("expires_at") else now + json.optLong("expires_in", 3600L)
        return UserSession(
            accessToken = json.getString("access_token"),
            refreshToken = json.getString("refresh_token"),
            expiresAtSec = expiresAt,
            userId = json.getJSONObject("user").getString("id"),
        )
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (isNull(key)) null else getString(key)
}

package com.notchat.presentation.chat

import androidx.lifecycle.ViewModel
import com.notchat.data.local.ChatLockStore
import com.notchat.domain.model.PinResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class ChatLockViewModel @Inject constructor(
    private val store: ChatLockStore,
) : ViewModel() {
    val lockedIds: StateFlow<Set<String>> = store.lockedIds
    val unlockedIds: StateFlow<Set<String>> = store.unlockedIds
    val pinSet: StateFlow<Boolean> = store.pinSet

    fun hasPin(): Boolean = store.hasPin()
    suspend fun verify(pin: String): PinResult = store.verify(pin)
    fun lockoutRemainingMillis(): Long = store.lockoutRemainingMillis()
    suspend fun setPin(pin: String) = store.setPin(pin)
    fun removePin() = store.clearAll()

    /** Locks the chat now, but keeps it open for this visit. */
    fun lockChat(conversationId: String) {
        store.lock(conversationId)
        store.markUnlocked(conversationId)
    }

    fun removeLock(conversationId: String) = store.unlockForever(conversationId)
    fun markUnlocked(conversationId: String) = store.markUnlocked(conversationId)
}

package com.notchat.domain

import com.notchat.domain.model.Conversation
import com.notchat.domain.model.ConversationType

enum class ChatFilter { ALL, UNREAD, GROUPS, LOCKED }

/** Which conversations the chips on the chat list show. */
object ChatListFilter {
    fun apply(items: List<Conversation>, filter: ChatFilter, lockedIds: Set<String>): List<Conversation> =
        when (filter) {
            ChatFilter.ALL -> items
            ChatFilter.UNREAD -> items.filter { it.unreadCount > 0 }
            ChatFilter.GROUPS -> items.filter { it.type == ConversationType.GROUP }
            ChatFilter.LOCKED -> items.filter { it.id in lockedIds }
        }
}

package com.notchat.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.notchat.domain.PinPolicy
import com.notchat.domain.model.PinResult
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Locks individual chats behind one 4-digit PIN. Everything stays on this phone:
 * - which chats are locked (plain preferences: just ids),
 * - the PIN itself as a salted PBKDF2 hash inside encrypted preferences (Android Keystore).
 * A locked chat asks for the PIN each time it is opened, and locks again when you leave the
 * chat or the app goes to the background. Signing out removes the PIN and all locks.
 */
@Singleton
class ChatLockStore @Inject constructor(
    @ApplicationContext private val context: Context,
) : DefaultLifecycleObserver {

    private val plain: SharedPreferences = context.getSharedPreferences("chat_lock", Context.MODE_PRIVATE)
    private val secret: SharedPreferences by lazy { createSecretPrefs() }

    private val _locked = MutableStateFlow(plain.getStringSet(K_LOCKED, emptySet()).orEmpty().toSet())
    val lockedIds: StateFlow<Set<String>> = _locked.asStateFlow()

    private val _unlocked = MutableStateFlow<Set<String>>(emptySet())
    /** Locked chats that were unlocked in this visit; cleared when leaving the chat or the app. */
    val unlockedIds: StateFlow<Set<String>> = _unlocked.asStateFlow()

    private val _pinSet = MutableStateFlow(plain.getBoolean(K_HAS_PIN, false))
    val pinSet: StateFlow<Boolean> = _pinSet.asStateFlow()

    fun hasPin(): Boolean = _pinSet.value
    fun isLocked(conversationId: String): Boolean = conversationId in _locked.value

    fun lock(conversationId: String) {
        _locked.update { it + conversationId }
        persistLocked()
    }

    fun unlockForever(conversationId: String) {
        _locked.update { it - conversationId }
        _unlocked.update { it - conversationId }
        persistLocked()
    }

    fun markUnlocked(conversationId: String) = _unlocked.update { it + conversationId }
    fun relock(conversationId: String) = _unlocked.update { it - conversationId }
    fun relockAll() {
        _unlocked.value = emptySet()
    }

    override fun onStop(owner: LifecycleOwner) = relockAll()

    suspend fun setPin(pin: String) {
        require(PinPolicy.isValid(pin)) { "PIN must be ${PinPolicy.LENGTH} digits" }
        withContext(Dispatchers.Default) {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val hash = hash(pin, salt)
            secret.edit()
                .putString(K_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString(K_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
                .apply()
        }
        plain.edit().putBoolean(K_HAS_PIN, true).putInt(K_FAILS, 0).putLong(K_LOCKED_UNTIL, 0L).apply()
        _pinSet.value = true
    }

    suspend fun verify(pin: String): PinResult {
        val now = System.currentTimeMillis()
        val until = plain.getLong(K_LOCKED_UNTIL, 0L)
        if (until > now) return PinResult.LockedOut(until)
        if (!PinPolicy.isValid(pin) || !hasPin()) return PinResult.Wrong(PinPolicy.attemptsLeft(plain.getInt(K_FAILS, 0)))

        val ok = withContext(Dispatchers.Default) {
            val salt = Base64.decode(secret.getString(K_SALT, "") ?: "", Base64.NO_WRAP)
            val stored = Base64.decode(secret.getString(K_HASH, "") ?: "", Base64.NO_WRAP)
            salt.isNotEmpty() && MessageDigest.isEqual(stored, hash(pin, salt))
        }
        if (ok) {
            plain.edit().putInt(K_FAILS, 0).putLong(K_LOCKED_UNTIL, 0L).apply()
            return PinResult.Ok
        }
        val fails = plain.getInt(K_FAILS, 0) + 1
        val wait = PinPolicy.lockoutMillis(fails)
        plain.edit().putInt(K_FAILS, fails).putLong(K_LOCKED_UNTIL, if (wait > 0) now + wait else 0L).apply()
        return if (wait > 0) PinResult.LockedOut(now + wait) else PinResult.Wrong(PinPolicy.attemptsLeft(fails))
    }

    /** Milliseconds until PIN entry is allowed again (0 when allowed). */
    fun lockoutRemainingMillis(): Long = (plain.getLong(K_LOCKED_UNTIL, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    /** Removes the PIN and every lock (used by "remove PIN" and when signing out). */
    fun clearAll() {
        plain.edit().clear().apply()
        try {
            secret.edit().clear().apply()
        } catch (e: Exception) {
            // Nothing stored yet or the keystore is unavailable: there is nothing to protect.
        }
        _locked.value = emptySet()
        _unlocked.value = emptySet()
        _pinSet.value = false
    }

    private fun persistLocked() {
        plain.edit().putStringSet(K_LOCKED, _locked.value).apply()
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 256))
            .encoded

    private fun createSecretPrefs(): SharedPreferences {
        fun build(): SharedPreferences = EncryptedSharedPreferences.create(
            context,
            "chat_lock_secret",
            MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
        return try {
            build()
        } catch (e: Exception) {
            context.deleteSharedPreferences("chat_lock_secret")
            build()
        }
    }

    private companion object {
        const val K_LOCKED = "locked_ids"
        const val K_HAS_PIN = "has_pin"
        const val K_FAILS = "fail_count"
        const val K_LOCKED_UNTIL = "locked_until"
        const val K_SALT = "salt"
        const val K_HASH = "hash"
        const val ITERATIONS = 100_000
    }
}

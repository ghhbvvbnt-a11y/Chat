package com.notchat.presentation.auth

import android.util.Patterns
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.NcTextField
import com.notchat.presentation.components.NotChatLogo

@Composable
fun LoginScreen(
    onNavigateRegister: () -> Unit,
    onNavigateForgot: () -> Unit,
    onSignedIn: () -> Unit,
    vm: AuthViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(ui.event) {
        if (ui.event == AuthEvent.SIGNED_IN) onSignedIn()
    }

    val emailValid = Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
    val emailError = if (submitted && !emailValid) stringResource(R.string.err_email) else null
    val passwordError = if (submitted && password.isEmpty()) stringResource(R.string.err_required) else null

    Scaffold(containerColor = NcBackground) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).systemBarsPadding().imePadding()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                NotChatLogo(size = 88.dp)
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(R.string.app_name),
                    color = NcTextPrimary, fontSize = 26.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 3.sp,
                )
                Text(stringResource(R.string.tagline), color = NcTextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(32.dp))
                Text(
                    stringResource(R.string.login_title),
                    color = NcTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.Start),
                )
                Text(
                    stringResource(R.string.login_subtitle),
                    color = NcTextSecondary, fontSize = 14.sp,
                    modifier = Modifier.align(Alignment.Start),
                )
                Spacer(Modifier.height(20.dp))
                NcTextField(
                    value = email, onValueChange = { email = it },
                    label = stringResource(R.string.email),
                    leadingIcon = Icons.Outlined.Email,
                    keyboardType = KeyboardType.Email,
                    error = emailError,
                )
                Spacer(Modifier.height(4.dp))
                NcTextField(
                    value = password, onValueChange = { password = it },
                    label = stringResource(R.string.password),
                    leadingIcon = Icons.Outlined.Lock,
                    isPassword = true, imeAction = ImeAction.Done,
                    error = passwordError,
                )
                ui.error?.let { error ->
                    Spacer(Modifier.height(4.dp))
                    Text(
                        error.message(),
                        color = NcError, fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.Start),
                    )
                }
                Spacer(Modifier.height(16.dp))
                GradientButton(
                    text = stringResource(R.string.login),
                    loading = ui.loading,
                    onClick = {
                        submitted = true
                        if (emailValid && password.isNotEmpty()) vm.signIn(email, password)
                    },
                )
                TextButton(onClick = onNavigateForgot) {
                    Text(stringResource(R.string.forgot_password), color = NcTextSecondary)
                }
                TextButton(onClick = onNavigateRegister) {
                    Text(stringResource(R.string.no_account), color = NcSecondary)
                }
            }
        }
    }
}

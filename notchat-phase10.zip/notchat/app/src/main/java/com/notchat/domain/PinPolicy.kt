package com.notchat.domain

import kotlin.math.min

/** Rules for the 4-digit chat PIN. Pure, so it can be unit tested. */
object PinPolicy {
    const val LENGTH = 4
    const val FREE_ATTEMPTS = 5
    private const val BASE_LOCKOUT_MS = 30_000L
    private const val MAX_LOCKOUT_MS = 15 * 60_000L

    fun isValid(pin: String): Boolean = pin.length == LENGTH && pin.all { it in '0'..'9' }

    /**
     * How long entering a PIN is blocked after [failCount] wrong attempts in a row:
     * none for the first five, then 30 s, doubling every further five attempts, at most 15 min.
     */
    fun lockoutMillis(failCount: Int): Long {
        if (failCount < FREE_ATTEMPTS) return 0L
        val tier = (failCount - FREE_ATTEMPTS) / FREE_ATTEMPTS
        val factor = 1L shl min(tier, 10)
        return min(BASE_LOCKOUT_MS * factor, MAX_LOCKOUT_MS)
    }

    fun attemptsLeft(failCount: Int): Int = (FREE_ATTEMPTS - failCount).coerceAtLeast(0)
}

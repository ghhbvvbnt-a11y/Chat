package com.notchat.presentation.groups

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.ConversationHeader
import com.notchat.domain.model.GroupMember
import com.notchat.domain.model.MemberRole
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.ChatRepository
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class GroupInfoUiState(
    val loading: Boolean = true,
    val header: ConversationHeader? = null,
    val members: List<GroupMember> = emptyList(),
    val loadError: AuthError? = null,
    val busy: Boolean = false,
    val error: AuthError? = null,
    /** My contacts who are not in the group yet (for "add members"). */
    val candidates: List<Profile> = emptyList(),
) {
    val iAmAdmin: Boolean get() = header?.myRole == MemberRole.ADMIN
}

@HiltViewModel
class GroupInfoViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val chat: ChatRepository,
    private val users: UserRepository,
    auth: AuthRepository,
) : ViewModel() {

    private val conversationId = savedStateHandle.get<String>("conversationId").orEmpty()
    val myId: String = (auth.sessionState.value as? SessionState.SignedIn)?.userId.orEmpty()

    private val _ui = MutableStateFlow(GroupInfoUiState())
    val ui: StateFlow<GroupInfoUiState> = _ui.asStateFlow()

    private val _left = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val left: SharedFlow<Unit> = _left.asSharedFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, loadError = null) }
            val header = chat.conversationHeader(conversationId)
            val members = chat.members(conversationId)
            when {
                header is Outcome.Failure -> _ui.update { it.copy(loading = false, loadError = header.error) }
                members is Outcome.Failure -> _ui.update { it.copy(loading = false, loadError = members.error) }
                header is Outcome.Success && members is Outcome.Success ->
                    _ui.update { it.copy(loading = false, header = header.value, members = members.value) }
            }
        }
    }

    fun rename(name: String) = action { chat.renameGroup(conversationId, name) }

    fun remove(userId: String) = action { chat.removeMember(conversationId, userId) }

    fun add(userIds: List<String>) = action { chat.addMembers(conversationId, userIds) }

    fun leave() {
        if (_ui.value.busy) return
        _ui.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            when (val r = chat.leaveGroup(conversationId)) {
                is Outcome.Success -> {
                    _ui.update { it.copy(busy = false) }
                    _left.tryEmit(Unit)
                }
                is Outcome.Failure -> _ui.update { it.copy(busy = false, error = r.error) }
            }
        }
    }

    fun loadCandidates() {
        viewModelScope.launch {
            val r = users.contacts()
            if (r is Outcome.Success) {
                val inGroup = _ui.value.members.mapTo(HashSet()) { it.userId }
                _ui.update { it.copy(candidates = r.value.filterNot { p -> p.id in inGroup }) }
            }
        }
    }

    private fun action(block: suspend () -> Outcome<Unit>) {
        if (_ui.value.busy) return
        _ui.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            when (val r = block()) {
                is Outcome.Success -> {
                    _ui.update { it.copy(busy = false) }
                    load()
                }
                is Outcome.Failure -> _ui.update { it.copy(busy = false, error = r.error) }
            }
        }
    }
}

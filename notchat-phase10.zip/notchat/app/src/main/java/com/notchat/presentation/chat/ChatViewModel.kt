package com.notchat.presentation.chat

import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.data.media.MediaPreparer
import com.notchat.domain.ChatLogic
import com.notchat.domain.MediaRules
import com.notchat.domain.model.Attachment
import com.notchat.domain.model.AuthError
import com.notchat.data.local.ChatLockStore
import com.notchat.domain.model.ChatMessage
import com.notchat.domain.model.ConversationHeader
import com.notchat.domain.model.ConversationType
import com.notchat.domain.model.GroupMember
import com.notchat.domain.model.LocalMedia
import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.MessageStatus
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Presence
import com.notchat.domain.model.Receipts
import com.notchat.domain.model.TypingState
import com.notchat.domain.model.TypingUi
import com.notchat.domain.model.ViewOnceContent
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.ChatRepository
import com.notchat.domain.repository.PresenceRepository
import com.notchat.notify.ActiveChat
import com.notchat.notify.NotificationHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import javax.inject.Inject

data class ChatUiState(
    val loading: Boolean = true,
    val messages: List<ChatMessage> = emptyList(), // newest first
    val header: ConversationHeader? = null,
    val error: AuthError? = null,
    val sendError: AuthError? = null,
    val loadingOlder: Boolean = false,
    val endReached: Boolean = false,
    val preparingMedia: Boolean = false,
    val presence: Presence? = null,
    val typing: TypingUi? = null,
)

/** State of the full-screen "view once" viewer. */
sealed interface ViewOnceUi {
    data object None : ViewOnceUi
    data object Loading : ViewOnceUi
    data class Ready(val content: ViewOnceContent) : ViewOnceUi
    data class Failed(val error: AuthError) : ViewOnceUi
}

private data class Pending(val message: Message, val failed: Boolean, val local: LocalMedia?)

@OptIn(FlowPreview::class)
@HiltViewModel
class ChatViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val chat: ChatRepository,
    private val media: MediaPreparer,
    private val presenceRepo: PresenceRepository,
    private val chatLock: ChatLockStore,
    notificationHelper: NotificationHelper,
    auth: AuthRepository,
) : ViewModel() {

    val conversationId: String = savedStateHandle.get<String>("conversationId").orEmpty()
    private val myId = (auth.sessionState.value as? SessionState.SignedIn)?.userId.orEmpty()

    private var server: List<Message> = emptyList() // newest first
    private var pending: List<Pending> = emptyList() // newest first
    private var receipts: Receipts? = null
    private var members: Map<String, GroupMember> = emptyMap()
    private val hiddenIds = HashSet<String>() // "deleted for me" in this session
    private val typingMap = HashMap<String, Pair<TypingState, Long>>() // userId -> (state, last signal)
    private var composing = false
    private var lastTypingSent = 0L
    private var recordingJob: Job? = null
    private var lastReadMarkedMillis = 0L
    private var olderJobRunning = false

    private val _ui = MutableStateFlow(ChatUiState())
    val ui: StateFlow<ChatUiState> = _ui.asStateFlow()
    val connected: StateFlow<Boolean> = chat.realtimeConnected

    private val _viewOnce = MutableStateFlow<ViewOnceUi>(ViewOnceUi.None)
    val viewOnce: StateFlow<ViewOnceUi> = _viewOnce.asStateFlow()

    init {
        ActiveChat.id = conversationId
        notificationHelper.clear(conversationId)
        chat.startRealtime()
        chat.joinTyping(conversationId)
        loadHeader()
        viewModelScope.launch {
            chat.typingEvents.collect { e ->
                if (e.conversationId != conversationId || e.userId == myId) return@collect
                if (e.state == TypingState.IDLE) {
                    typingMap.remove(e.userId)
                } else {
                    typingMap[e.userId] = e.state to SystemClock.elapsedRealtime()
                }
                publishTyping()
            }
        }
        // A signal that stops arriving (phone died, app closed) must not leave "typing…" on screen.
        viewModelScope.launch {
            while (true) {
                delay(1_000L)
                val cutoff = SystemClock.elapsedRealtime() - TYPING_TTL_MS
                if (typingMap.values.removeAll { it.second < cutoff }) publishTyping()
            }
        }
        loadInitial()
        viewModelScope.launch { chat.changes.debounce(150).collect { refreshLatest() } }
        // Safety net in case the live connection is down or silently not delivering.
        viewModelScope.launch {
            while (true) {
                delay(if (chat.realtimeConnected.value) 30_000L else 5_000L)
                refreshLatest()
            }
        }
    }

    // ---- sending ---------------------------------------------------------

    fun send(raw: String) {
        val body = raw.trim()
        if (body.isEmpty() || body.length > MAX_LENGTH || myId.isEmpty()) return
        val clientId = UUID.randomUUID().toString()
        enqueue(newLocalMessage(clientId, body, MessageKind.TEXT, emptyList()), local = null)
    }

    /** Photo / video / file picked from the device. */
    fun sendMedia(uri: Uri, viewOnce: Boolean = false) {
        if (myId.isEmpty()) return
        _ui.update { it.copy(sendError = null, preparingMedia = true) }
        viewModelScope.launch {
            val r = media.prepare(uri)
            _ui.update { it.copy(preparingMedia = false) }
            when (r) {
                is Outcome.Success -> enqueueMedia(r.value, viewOnce)
                is Outcome.Failure -> _ui.update { it.copy(sendError = r.error) }
            }
        }
    }

    fun sendVoice(file: File, durationMs: Int) {
        if (myId.isEmpty()) return
        enqueueMedia(
            LocalMedia(file, MessageKind.AUDIO, "voice.m4a", "audio/mp4", file.length(), null, null, durationMs),
        )
    }

    /** Receiver taps a view-once bubble. The server allows this only once per receiver. */
    fun openViewOnce(messageId: String) {
        if (_viewOnce.value is ViewOnceUi.Loading) return
        _viewOnce.value = ViewOnceUi.Loading
        viewModelScope.launch {
            _viewOnce.value = when (val r = chat.openViewOnce(messageId)) {
                is Outcome.Success -> ViewOnceUi.Ready(r.value)
                is Outcome.Failure -> ViewOnceUi.Failed(r.error)
            }
        }
    }

    fun closeViewOnce() {
        _viewOnce.value = ViewOnceUi.None
        refreshLatest() // the bubble now shows "Opened"
    }

    /** "Delete for me" (or discard a message that was never sent). */
    fun deleteForMe(m: Message) {
        val isLocalOnly = m.createdAtRaw.isEmpty()
        if (isLocalOnly) {
            pending = pending.filterNot { it.message.clientId == m.clientId }
            publish()
            return
        }
        hiddenIds += m.id
        publish()
        viewModelScope.launch {
            val r = chat.hideMessage(m.id)
            if (r is Outcome.Failure) {
                hiddenIds -= m.id
                _ui.update { it.copy(sendError = r.error) }
                publish()
            }
        }
    }

    /** "Delete for everyone": shown as deleted right away, restored if the server refuses. */
    fun deleteForEveryone(m: Message) {
        if (m.createdAtRaw.isEmpty() || m.senderId != myId) return
        server = server.map {
            if (it.id == m.id) it.copy(deleted = true, body = "", attachments = emptyList()) else it
        }
        publish()
        viewModelScope.launch {
            val r = chat.deleteForEveryone(m.id)
            if (r is Outcome.Failure) {
                _ui.update { it.copy(sendError = r.error) }
                refreshLatest() // brings the real (not deleted) message back
            }
        }
    }

    fun toggleMute() {
        val header = _ui.value.header ?: return
        val muted = !header.muted
        _ui.update { it.copy(header = header.copy(muted = muted)) }
        viewModelScope.launch {
            val r = chat.setMuted(conversationId, myId, muted)
            if (r is Outcome.Failure) {
                _ui.update { it.copy(header = header, sendError = r.error) }
            }
        }
    }

    fun retry(clientId: String) {
        pending = pending.map { if (it.message.clientId == clientId) it.copy(failed = false) else it }
        _ui.update { it.copy(sendError = null) }
        publish()
        dispatch(clientId)
    }

    private fun enqueueMedia(m: LocalMedia, viewOnce: Boolean = false) {
        if (m.sizeBytes > MediaRules.MAX_BYTES) {
            _ui.update { it.copy(sendError = AuthError.FILE_TOO_LARGE) }
            return
        }
        val clientId = UUID.randomUUID().toString()
        val attachment = Attachment(
            id = clientId, kind = m.kind, storagePath = "", fileName = m.fileName,
            mimeType = m.mimeType, sizeBytes = m.sizeBytes, width = m.width, height = m.height,
            durationMs = m.durationMs, url = Uri.fromFile(m.file).toString(),
        )
        enqueue(newLocalMessage(clientId, "", m.kind, listOf(attachment), viewOnce), local = m)
    }

    private fun newLocalMessage(
        clientId: String,
        body: String,
        kind: MessageKind,
        attachments: List<Attachment>,
        viewOnce: Boolean = false,
    ) =
        Message(
            id = clientId, clientId = clientId, conversationId = conversationId, senderId = myId,
            body = body, createdAtRaw = "", createdAtMillis = System.currentTimeMillis(),
            replyTo = null, edited = false, deleted = false, kind = kind, attachments = attachments,
            viewOnce = viewOnce,
        )

    private fun enqueue(message: Message, local: LocalMedia?) {
        pending = listOf(Pending(message, failed = false, local = local)) + pending
        _ui.update { it.copy(sendError = null) }
        publish()
        dispatch(message.clientId)
    }

    private fun dispatch(clientId: String) {
        val p = pending.firstOrNull { it.message.clientId == clientId } ?: return
        viewModelScope.launch {
            val local = p.local
            if (local == null) {
                when (val r = chat.sendMessage(conversationId, myId, clientId, p.message.body)) {
                    is Outcome.Success -> {
                        r.value?.let { server = ChatLogic.mergeNewestFirst(server, listOf(it)) }
                        pending = pending.filterNot { it.message.clientId == clientId }
                        publish()
                        if (r.value == null) refreshLatest()
                    }
                    is Outcome.Failure -> markFailed(clientId, r.error)
                }
            } else {
                when (val r = chat.sendMedia(conversationId, clientId, local, p.message.viewOnce)) {
                    // The pending bubble stays until the stored message arrives (see refreshLatest).
                    is Outcome.Success -> refreshLatest()
                    is Outcome.Failure -> markFailed(clientId, r.error)
                }
            }
        }
    }

    private fun markFailed(clientId: String, error: AuthError) {
        pending = pending.map { if (it.message.clientId == clientId) it.copy(failed = true) else it }
        _ui.update { it.copy(sendError = error) }
        publish()
    }

    // ---- loading ---------------------------------------------------------

    fun loadOlder() {
        val state = _ui.value
        if (olderJobRunning || state.endReached || state.loading || server.isEmpty()) return
        olderJobRunning = true
        _ui.update { it.copy(loadingOlder = true) }
        viewModelScope.launch {
            when (val r = chat.messages(conversationId, server.last().createdAtRaw, PAGE_SIZE)) {
                is Outcome.Success -> {
                    server = ChatLogic.mergeNewestFirst(server, r.value)
                    _ui.update { it.copy(endReached = r.value.size < PAGE_SIZE) }
                }
                is Outcome.Failure -> Unit // user can scroll again to retry
            }
            olderJobRunning = false
            _ui.update { it.copy(loadingOlder = false) }
            publish()
        }
    }

    private fun loadInitial() {
        viewModelScope.launch {
            when (val r = chat.messages(conversationId, null, PAGE_SIZE)) {
                is Outcome.Success -> {
                    server = ChatLogic.mergeNewestFirst(emptyList(), r.value)
                    _ui.update { it.copy(loading = false, error = null, endReached = r.value.size < PAGE_SIZE) }
                    refreshReceipts()
                    publish()
                    markReadIfNeeded()
                }
                is Outcome.Failure -> _ui.update { it.copy(loading = false, error = r.error) }
            }
        }
    }

    private fun refreshLatest() {
        if (_ui.value.loading) return
        viewModelScope.launch {
            val r = chat.messages(conversationId, null, PAGE_SIZE)
            if (r is Outcome.Success) {
                server = ChatLogic.mergeNewestFirst(server, r.value)
                val stored = server.mapTo(HashSet()) { it.clientId }
                pending = pending.filterNot { it.message.clientId in stored }
                refreshReceipts()
                if (_ui.value.header?.type == ConversationType.GROUP) refreshMembers()
                publish()
                markReadIfNeeded()
            }
        }
    }

    private suspend fun refreshReceipts() {
        val r = chat.partnerReceipts(conversationId, myId)
        if (r is Outcome.Success) receipts = r.value
    }

    private suspend fun markReadIfNeeded() {
        val newest = server.firstOrNull { it.senderId != myId && !it.deleted } ?: return
        if (newest.createdAtMillis <= lastReadMarkedMillis) return
        if (chat.markRead(conversationId, newest.createdAtRaw) is Outcome.Success) {
            lastReadMarkedMillis = newest.createdAtMillis
        }
    }

    private fun loadHeader() {
        viewModelScope.launch {
            val r = chat.conversationHeader(conversationId)
            if (r is Outcome.Success) {
                _ui.update { it.copy(header = r.value) }
                if (r.value.type == ConversationType.GROUP) {
                    refreshMembers()
                } else {
                    startPresencePolling(r.value.otherUserId)
                }
            }
        }
    }

    private fun startPresencePolling(otherUserId: String?) {
        if (otherUserId == null) return
        viewModelScope.launch {
            while (true) {
                val r = presenceRepo.presenceOf(otherUserId)
                if (r is Outcome.Success) _ui.update { it.copy(presence = r.value) }
                delay(20_000L)
            }
        }
    }

    private fun publishTyping() {
        if (typingMap.isEmpty()) {
            _ui.update { it.copy(typing = null) }
            return
        }
        val state = if (typingMap.values.any { it.first == TypingState.RECORDING }) {
            TypingState.RECORDING
        } else {
            TypingState.TYPING
        }
        val isGroup = _ui.value.header?.type == ConversationType.GROUP
        val names = if (isGroup) typingMap.keys.mapNotNull { members[it]?.displayName } else emptyList()
        _ui.update { it.copy(typing = TypingUi(state, names)) }
    }

    /** Call whenever the composer text changes; tells the other side "typing" (at most every 2.5 s). */
    fun onTextChanged(text: String) {
        if (text.isBlank()) {
            if (composing) {
                composing = false
                chat.sendTyping(conversationId, myId, TypingState.IDLE)
            }
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (!composing || now - lastTypingSent > TYPING_RESEND_MS) {
            composing = true
            lastTypingSent = now
            chat.sendTyping(conversationId, myId, TypingState.TYPING)
        }
    }

    /** Call when voice recording starts or stops; tells the other side "recording". */
    fun setRecording(active: Boolean) {
        recordingJob?.cancel()
        if (active) {
            recordingJob = viewModelScope.launch {
                while (true) {
                    chat.sendTyping(conversationId, myId, TypingState.RECORDING)
                    delay(TYPING_RESEND_MS)
                }
            }
        } else {
            recordingJob = null
            chat.sendTyping(conversationId, myId, TypingState.IDLE)
        }
    }

    private suspend fun refreshMembers() {
        val r = chat.members(conversationId)
        if (r is Outcome.Success) {
            members = r.value.associateBy { it.userId }
            publish()
        }
    }

    private fun publish() {
        val storedClientIds = server.mapTo(HashSet()) { it.clientId }
        val local = pending
            .filter { it.message.clientId !in storedClientIds }
            .map { ChatMessage(it.message, if (it.failed) MessageStatus.FAILED else MessageStatus.SENDING, true) }
        val isGroup = _ui.value.header?.type == ConversationType.GROUP
        val stored = server.filter { it.id !in hiddenIds }.map { m ->
            val mine = m.senderId == myId
            ChatMessage(
                message = m,
                status = if (mine) ChatLogic.statusFor(m, receipts) else MessageStatus.SENT,
                mine = mine,
                viewedByMe = myId in m.viewedBy,
                viewedByOther = m.viewedBy.any { it != myId },
                senderName = if (isGroup && !mine) members[m.senderId]?.displayName else null,
            )
        }
        _ui.update { it.copy(messages = local + stored) }
    }

    override fun onCleared() {
        chatLock.relock(conversationId)
        if (ActiveChat.id == conversationId) ActiveChat.id = null
        chat.sendTyping(conversationId, myId, TypingState.IDLE)
        chat.leaveTyping(conversationId)
        chat.stopRealtime()
    }

    private companion object {
        const val PAGE_SIZE = 30
        const val TYPING_TTL_MS = 6_000L
        const val TYPING_RESEND_MS = 2_500L
        const val MAX_LENGTH = 4000
    }
}

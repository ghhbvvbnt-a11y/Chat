package com.notchat.presentation.chat

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.model.Message
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial

/** Pick up to 5 chats or contacts and forward a message to them. */
@Composable
fun ForwardDialog(
    message: Message,
    onDismiss: () -> Unit,
    onDone: () -> Unit,
    vm: ForwardViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    LaunchedEffect(Unit) { vm.done.collect { onDone() } }

    AlertDialog(
        onDismissRequest = { if (!ui.sending) onDismiss() },
        containerColor = NcCard,
        titleContentColor = NcTextPrimary,
        textContentColor = NcTextSecondary,
        title = { Text(stringResource(R.string.forward_to)) },
        text = {
            Column {
                when {
                    ui.loading -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NcPrimary)
                    }
                    ui.destinations.isEmpty() -> Text(
                        ui.error?.message() ?: stringResource(R.string.forward_empty),
                        color = if (ui.error != null) NcError else NcTextSecondary,
                    )
                    else -> Column(
                        Modifier
                            .heightIn(max = 360.dp)
                            .verticalScroll(rememberScrollState()),
                    ) {
                        ui.destinations.forEach { d ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !ui.sending) { vm.toggle(d.key) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                AvatarInitial(d.title, size = 36.dp, imageUrl = d.avatarUrl)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(d.title, color = NcTextPrimary, maxLines = 1)
                                    d.subtitle?.let {
                                        Text(it, color = NcSecondary, fontSize = 12.sp, maxLines = 1)
                                    }
                                }
                                Checkbox(
                                    checked = d.key in ui.selected,
                                    onCheckedChange = { vm.toggle(d.key) },
                                    enabled = !ui.sending,
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = NcPrimary,
                                        uncheckedColor = NcOutline,
                                    ),
                                )
                            }
                        }
                    }
                }
                if (ui.error != null && ui.destinations.isNotEmpty()) {
                    Text(
                        ui.error!!.message(), color = NcError, fontSize = 13.sp,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(enabled = ui.canSend, onClick = { vm.forward(message) }) {
                Text(
                    stringResource(if (ui.sending) R.string.forward_sending else R.string.forward_send),
                    color = NcSecondary,
                )
            }
        },
        dismissButton = {
            TextButton(enabled = !ui.sending, onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = NcTextPrimary)
            }
        },
    )
}

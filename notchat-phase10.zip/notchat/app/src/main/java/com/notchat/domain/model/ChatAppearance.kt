package com.notchat.domain.model

enum class BubbleTheme(val id: String) {
    GREEN("green"), OCEAN("ocean"), TEAL("teal"), VIOLET("violet"), ROSE("rose"), SUNSET("sunset"), MONO("mono"),
}

enum class BubbleShape(val id: String) {
    ROUNDED("rounded"), PILL("pill"), CLASSIC("classic"), SQUARE("square"),
}

enum class ChatBackground(val id: String) {
    GREEN_GLOW("green"), DARK("dark"), VIOLET_GLOW("violet"), TEAL_GLOW("teal"), DOTS("dots"), AURORA("aurora"),
}

/** How chats look on this device: bubble color, bubble shape and background. */
data class ChatAppearance(
    val theme: BubbleTheme = BubbleTheme.GREEN,
    val shape: BubbleShape = BubbleShape.ROUNDED,
    val background: ChatBackground = ChatBackground.GREEN_GLOW,
) {
    companion object {
        /** Unknown or missing values fall back to the defaults. */
        fun fromIds(theme: String?, shape: String?, background: String?) = ChatAppearance(
            theme = BubbleTheme.entries.firstOrNull { it.id == theme } ?: BubbleTheme.GREEN,
            shape = BubbleShape.entries.firstOrNull { it.id == shape } ?: BubbleShape.ROUNDED,
            background = ChatBackground.entries.firstOrNull { it.id == background } ?: ChatBackground.GREEN_GLOW,
        )
    }
}

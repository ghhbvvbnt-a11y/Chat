package com.notchat.presentation.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.notchat.domain.model.Attachment

/** Opens a received video/file in another app (browser, player, document viewer). */
fun openAttachment(context: Context, attachment: Attachment) {
    val url = attachment.url ?: return
    if (!url.startsWith("https://")) return // local pending files are never shared with other apps
    val typed = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(Uri.parse(url), attachment.mimeType)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
        context.startActivity(typed)
    } catch (e: ActivityNotFoundException) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e2: ActivityNotFoundException) {
            // No app can open it.
        }
    }
}

fun formatDuration(ms: Int): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

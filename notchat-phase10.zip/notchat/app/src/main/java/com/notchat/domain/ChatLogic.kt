package com.notchat.domain

import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageStatus
import com.notchat.domain.model.Receipts
import java.time.Instant
import java.time.ZoneId

/** What a view-once bubble should show. */
enum class ViewOnceDisplay { TAP_TO_VIEW, OPENED_BY_ME, SENT_NOT_OPENED, SENT_OPENED }

/** Pure chat rules, kept free of Android so they can be unit tested. */
object ChatLogic {
    /** Status of a message I sent, given how far the other person has received/read. */
    fun statusFor(message: Message, receipts: Receipts?): MessageStatus = when {
        receipts == null -> MessageStatus.SENT
        receipts.readAtMillis >= message.createdAtMillis -> MessageStatus.READ
        receipts.deliveredAtMillis >= message.createdAtMillis -> MessageStatus.DELIVERED
        else -> MessageStatus.SENT
    }

    /** Merges two lists by message id (incoming wins), newest first. */
    fun mergeNewestFirst(existing: List<Message>, incoming: List<Message>): List<Message> {
        val byId = LinkedHashMap<String, Message>()
        existing.forEach { byId[it.id] = it }
        incoming.forEach { byId[it.id] = it }
        return byId.values.sortedWith(
            compareByDescending<Message> { it.createdAtMillis }.thenByDescending { it.id },
        )
    }

    fun viewOnceDisplay(mine: Boolean, viewedByMe: Boolean, viewedByOther: Boolean): ViewOnceDisplay = when {
        mine -> if (viewedByOther) ViewOnceDisplay.SENT_OPENED else ViewOnceDisplay.SENT_NOT_OPENED
        viewedByMe -> ViewOnceDisplay.OPENED_BY_ME
        else -> ViewOnceDisplay.TAP_TO_VIEW
    }

    /** In a group a message counts as delivered/read only when everybody else got/read it. */
    fun combineReceipts(all: List<Receipts>): Receipts? =
        if (all.isEmpty()) null
        else Receipts(all.minOf { it.deliveredAtMillis }, all.minOf { it.readAtMillis })

    fun sameDay(a: Long, b: Long, zone: ZoneId = ZoneId.systemDefault()): Boolean =
        Instant.ofEpochMilli(a).atZone(zone).toLocalDate() ==
            Instant.ofEpochMilli(b).atZone(zone).toLocalDate()
}

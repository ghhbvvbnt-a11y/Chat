package com.notchat.notify

import kotlinx.coroutines.flow.MutableStateFlow

/** The chat currently open on screen (no notification is shown for it). */
object ActiveChat {
    @Volatile
    var id: String? = null
}

/** A conversation to open, requested by tapping a notification. */
object DeepLinks {
    val pending = MutableStateFlow<String?>(null)

    fun consume() {
        pending.value = null
    }
}

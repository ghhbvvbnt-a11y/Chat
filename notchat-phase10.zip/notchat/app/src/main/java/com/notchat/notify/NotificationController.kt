package com.notchat.notify

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Turns the background connection (and so message notifications) on and off. */
@Singleton
class NotificationController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val helper: NotificationHelper,
) {
    private val prefs = context.getSharedPreferences("notifications", Context.MODE_PRIVATE)
    private val _enabled = MutableStateFlow(prefs.getBoolean(K_ENABLED, true))
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()

    var permissionAsked: Boolean
        get() = prefs.getBoolean(K_ASKED, false)
        set(value) {
            prefs.edit().putBoolean(K_ASKED, value).apply()
        }

    fun setEnabled(value: Boolean) {
        prefs.edit().putBoolean(K_ENABLED, value).apply()
        _enabled.value = value
        if (value) start() else stop()
    }

    /** Starts the service if the user wants notifications and the system allows them. */
    fun start() {
        if (!_enabled.value || !helper.canNotify()) return
        try {
            ContextCompat.startForegroundService(context, Intent(context, MessageService::class.java))
        } catch (e: IllegalStateException) {
            // The system refused to start it from the background; it starts next time the app is opened.
        }
    }

    fun stop() {
        context.stopService(Intent(context, MessageService::class.java))
    }

    private companion object {
        const val K_ENABLED = "enabled"
        const val K_ASKED = "permission_asked"
    }
}

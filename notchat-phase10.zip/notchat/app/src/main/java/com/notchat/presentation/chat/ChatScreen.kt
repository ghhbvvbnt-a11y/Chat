@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.notchat.presentation.chat

import android.Manifest
import kotlinx.coroutines.launch
import com.notchat.presentation.lock.PinVerifyDialog
import com.notchat.presentation.lock.PinGate
import com.notchat.presentation.lock.PinCreateDialog
import com.notchat.core.theme.NcBackground
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Add
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.Canvas
import androidx.compose.animation.scaleOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.AnimatedVisibility
import android.content.ContextWrapper
import android.content.Context
import android.app.Activity
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.text.format.Formatter
import android.view.WindowManager
import android.widget.MediaController
import android.widget.VideoView
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import com.notchat.core.theme.NcOnPrimary
import com.notchat.domain.model.TypingState
import com.notchat.domain.model.TypingUi
import com.notchat.presentation.util.formatLastSeen
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Done
import androidx.compose.material.icons.outlined.DoneAll
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.LooksOne
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.NotificationsOff
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcSurface
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.ChatLogic
import com.notchat.domain.MediaRules
import com.notchat.domain.ViewOnceDisplay
import com.notchat.domain.model.Attachment
import com.notchat.domain.model.ChatAppearance
import com.notchat.domain.model.ChatMessage
import com.notchat.domain.model.ConversationType
import com.notchat.domain.model.Message
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.MessageStatus
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.util.formatClock
import com.notchat.presentation.util.formatDayHeader
import com.notchat.presentation.util.formatDuration
import com.notchat.presentation.util.openAttachment
import kotlinx.coroutines.delay

@Composable
fun ChatScreen(
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    onOpenGroupInfo: (String) -> Unit,
    vm: ChatViewModel = hiltViewModel(),
    appearanceVm: AppearanceViewModel = hiltViewModel(),
    lockVm: ChatLockViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val ui by vm.ui.collectAsState()
    val connected by vm.connected.collectAsState()
    val viewOnce by vm.viewOnce.collectAsState()
    val appearance by appearanceVm.appearance.collectAsState()
    var text by rememberSaveable { mutableStateOf("") }
    var viewerUrl by remember { mutableStateOf<String?>(null) }
    var showAppearance by remember { mutableStateOf(false) }
    var actionsFor by remember { mutableStateOf<ChatMessage?>(null) }
    var forwardMsg by remember { mutableStateOf<Message?>(null) }
    var confirmDelete by remember { mutableStateOf<Pair<Message, Boolean>?>(null) }
    val clipboard = LocalClipboardManager.current
    var sendNextAsViewOnce by remember { mutableStateOf(false) }
    var micDenied by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var recordMs by remember { mutableIntStateOf(0) }
    val listState = rememberLazyListState()
    val uiScope = rememberCoroutineScope()
    val lockedIds by lockVm.lockedIds.collectAsState()
    val unlockedIds by lockVm.unlockedIds.collectAsState()
    val isLockedChat = vm.conversationId in lockedIds
    val needsPin = isLockedChat && vm.conversationId !in unlockedIds
    var showCreatePin by remember { mutableStateOf(false) }
    var showVerifyRemove by remember { mutableStateOf(false) }
    val atBottom by remember { derivedStateOf { listState.firstVisibleItemIndex <= 1 } }
    var bottomKey by remember { mutableStateOf<String?>(null) }
    val activity = remember(context) { context.findActivity() }
    // A locked chat can not be screenshotted or shown in the recent-apps preview.
    DisposableEffect(isLockedChat) {
        if (isLockedChat) activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { if (isLockedChat) activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    val recorder = remember { VoiceRecorder(context) }

    DisposableEffect(Unit) { onDispose { recorder.cancel() } }
    LaunchedEffect(text) { vm.onTextChanged(text) }
    LaunchedEffect(recording) { vm.setRecording(recording) }

    fun finishRecording(send: Boolean) {
        recording = false
        if (send) recorder.stop()?.let { vm.sendVoice(it.file, it.durationMs) } else recorder.cancel()
    }

    fun startRecording() {
        micDenied = false
        if (recorder.start()) {
            recordMs = 0
            recording = true
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else micDenied = true
    }
    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) vm.sendMedia(uri, viewOnce = sendNextAsViewOnce)
        sendNextAsViewOnce = false
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.sendMedia(uri)
    }

    LaunchedEffect(recording) {
        while (recording) {
            delay(250)
            recordMs = recorder.elapsedMs()
            if (recordMs >= MediaRules.MAX_VOICE_MS) finishRecording(send = true)
        }
    }

    val nearOldest by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            ui.messages.isNotEmpty() && last >= ui.messages.size - 5
        }
    }
    LaunchedEffect(nearOldest, ui.messages.size) {
        if (nearOldest) vm.loadOlder()
    }
    val newestKey = ui.messages.firstOrNull()?.message?.clientId
    LaunchedEffect(atBottom, newestKey) { if (atBottom) bottomKey = newestKey }
    LaunchedEffect(newestKey) {
        if (listState.firstVisibleItemIndex <= 2) listState.animateScrollToItem(0)
    }

    Box(Modifier.fillMaxSize()) {
        ChatBackgroundLayer(appearance.background)
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding(),
        ) {
            val header = ui.header
            val isGroup = header?.type == ConversationType.GROUP
            val typing = ui.typing
            val presence = ui.presence
            val statusText = when {
                typing != null -> typingLabel(typing)
                !connected -> stringResource(R.string.chat_connecting)
                isGroup && header != null -> stringResource(R.string.members_count, header.memberCount)
                presence?.online == true -> stringResource(R.string.status_online)
                presence != null -> formatLastSeen(context, presence.lastSeenMillis)
                header?.otherUsername != null -> "@${header.otherUsername}"
                else -> ""
            }
            ChatTopBar(
                name = header?.title.orEmpty(),
                avatarUrl = header?.otherAvatarUrl,
                subtitle = statusText,
                subtitleColor = if (typing != null || presence?.online == true) NcPrimary else NcTextSecondary,
                online = !isGroup && presence?.online == true,
                onBack = onBack,
                onTitleClick = {
                    when {
                        header == null -> Unit
                        header.type == ConversationType.GROUP -> onOpenGroupInfo(vm.conversationId)
                        header.otherUsername != null -> onOpenProfile(header.otherUsername)
                    }
                },
                muted = header?.muted == true,
                locked = isLockedChat,
                onToggleLock = {
                    when {
                        isLockedChat -> showVerifyRemove = true
                        lockVm.hasPin() -> {
                            lockVm.lockChat(vm.conversationId)
                            Toast.makeText(context, R.string.chat_locked_toast, Toast.LENGTH_SHORT).show()
                        }
                        else -> showCreatePin = true
                    }
                },
                onToggleMute = vm::toggleMute,
                onAppearance = { showAppearance = true },
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NcPrimary)
                    }
                    ui.error != null && ui.messages.isEmpty() -> Column(
                        Modifier.fillMaxSize().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text(ui.error!!.message(), color = NcError, textAlign = TextAlign.Center)
                        TextButton(onClick = onBack) {
                            Text(stringResource(R.string.back), color = NcSecondary)
                        }
                    }
                    ui.messages.isEmpty() -> Box(
                        Modifier.fillMaxSize().padding(32.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            stringResource(R.string.chat_empty),
                            color = NcTextSecondary, textAlign = TextAlign.Center,
                        )
                    }
                    else -> LazyColumn(
                        state = listState,
                        reverseLayout = true,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(0.dp),
                    ) {
                        itemsIndexed(ui.messages, key = { _, m -> m.message.clientId }) { index, item ->
                            val older = ui.messages.getOrNull(index + 1)
                            val firstOfDay = older == null ||
                                !ChatLogic.sameDay(older.message.createdAtMillis, item.message.createdAtMillis)
                            val newer = ui.messages.getOrNull(index - 1)
                            val joinsOlder = older != null && !firstOfDay && sameRun(older, item)
                            val joinsNewer = newer != null && sameRun(item, newer)
                            Column(Modifier.fillMaxWidth().padding(top = if (joinsOlder) 2.dp else 10.dp)) {
                                if (firstOfDay) DayHeader(item.message.createdAtMillis)
                                MessageBubble(
                                    tail = !joinsNewer,
                                    showName = !joinsOlder,
                                    item = item,
                                    appearance = appearance,
                                    onRetry = { vm.retry(item.message.clientId) },
                                    onOpenImage = { viewerUrl = it },
                                    onOpenAttachment = { openAttachment(context, it) },
                                    onOpenViewOnce = { vm.openViewOnce(item.message.id) },
                                    onLongPress = { actionsFor = item },
                                )
                            }
                        }
                        if (ui.loadingOlder) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(
                                        color = NcPrimary, strokeWidth = 2.dp, modifier = Modifier.size(20.dp),
                                    )
                                }
                            }
                        }
                    }
                }
                            ScrollToLatest(
                    visible = !atBottom && ui.messages.isNotEmpty(),
                    unseen = if (atBottom) 0 else ui.messages.indexOfFirst { it.message.clientId == bottomKey }.coerceAtLeast(0),
                    onClick = { uiScope.launch { listState.animateScrollToItem(0) } },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 10.dp),
                )
            }
            if (typing != null) {
                TypingBubbleRow(typing, appearance)
            }
            val notice = when {
                micDenied -> stringResource(R.string.err_mic_permission)
                ui.sendError != null -> ui.sendError!!.message()
                else -> null
            }
            notice?.let {
                Text(
                    it,
                    color = NcError, fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
            if (ui.preparingMedia) {
                Text(
                    stringResource(R.string.media_preparing),
                    color = NcTextSecondary, fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                )
            }
            if (recording) {
                RecordingBar(
                    elapsedMs = recordMs,
                    onCancel = { finishRecording(send = false) },
                    onSend = { finishRecording(send = true) },
                )
            } else {
                MessageInput(
                    text = text,
                    onTextChange = { text = it.take(MAX_LENGTH) },
                    onSend = {
                        vm.send(text)
                        text = ""
                    },
                    onPickMedia = {
                        sendNextAsViewOnce = false
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    onPickViewOnce = {
                        sendNextAsViewOnce = true
                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    onPickFile = { pickFile.launch(arrayOf("*/*")) },
                    onMic = {
                        val granted = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.RECORD_AUDIO,
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) startRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                )
            }
        }
    }

    if (showAppearance) AppearanceDialog(onDismiss = { showAppearance = false })

    if (showCreatePin) {
        PinCreateDialog(
            onDismiss = { showCreatePin = false },
            onCreated = { pin ->
                showCreatePin = false
                uiScope.launch {
                    lockVm.setPin(pin)
                    lockVm.lockChat(vm.conversationId)
                }
                Toast.makeText(context, R.string.chat_locked_toast, Toast.LENGTH_SHORT).show()
            },
        )
    }
    if (showVerifyRemove) {
        PinVerifyDialog(
            title = stringResource(R.string.pin_enter_current),
            subtitle = stringResource(R.string.pin_remove_lock_hint),
            onDismiss = { showVerifyRemove = false },
            verify = lockVm::verify,
            remainingMillis = lockVm::lockoutRemainingMillis,
            onVerified = {
                showVerifyRemove = false
                lockVm.removeLock(vm.conversationId)
                Toast.makeText(context, R.string.chat_unlocked_toast, Toast.LENGTH_SHORT).show()
            },
        )
    }
    if (needsPin) {
        PinGate(
            onBack = onBack,
            verify = lockVm::verify,
            remainingMillis = lockVm::lockoutRemainingMillis,
            onUnlocked = { lockVm.markUnlocked(vm.conversationId) },
        )
    }

    actionsFor?.let { item ->
        MessageActionsSheet(
            item = item,
            onDismiss = { actionsFor = null },
            onCopy = {
                clipboard.setText(AnnotatedString(item.message.body))
                Toast.makeText(context, R.string.copied, Toast.LENGTH_SHORT).show()
                actionsFor = null
            },
            onForward = {
                forwardMsg = item.message
                actionsFor = null
            },
            onDeleteForMe = {
                confirmDelete = item.message to false
                actionsFor = null
            },
            onDeleteForEveryone = {
                confirmDelete = item.message to true
                actionsFor = null
            },
        )
    }

    forwardMsg?.let { msg ->
        ForwardDialog(
            message = msg,
            onDismiss = { forwardMsg = null },
            onDone = {
                forwardMsg = null
                Toast.makeText(context, R.string.forwarded_done, Toast.LENGTH_SHORT).show()
            },
        )
    }

    confirmDelete?.let { (msg, everyone) ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            textContentColor = NcTextSecondary,
            title = {
                Text(stringResource(if (everyone) R.string.delete_everyone_title else R.string.delete_me_title))
            },
            text = {
                Text(stringResource(if (everyone) R.string.delete_everyone_body else R.string.delete_me_body))
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = null
                    if (everyone) vm.deleteForEveryone(msg) else vm.deleteForMe(msg)
                }) { Text(stringResource(R.string.delete), color = NcError) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) {
                    Text(stringResource(R.string.cancel), color = NcTextPrimary)
                }
            },
        )
    }

    viewerUrl?.let { url ->
        Dialog(
            onDismissRequest = { viewerUrl = null },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Box(
                Modifier.fillMaxSize().background(Color.Black).clickable { viewerUrl = null },
                contentAlignment = Alignment.Center,
            ) {
                AsyncImage(
                    model = url,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }

    if (viewOnce !is ViewOnceUi.None) {
        ViewOnceViewer(state = viewOnce, onClose = vm::closeViewOnce)
    }
}

private const val MAX_LENGTH = 4000
private const val RUN_GAP_MS = 5 * 60 * 1000L

/** True when [newer] directly follows [older] from the same sender within a few minutes. */
private fun sameRun(older: ChatMessage, newer: ChatMessage): Boolean =
    older.message.senderId == newer.message.senderId &&
        newer.message.createdAtMillis - older.message.createdAtMillis < RUN_GAP_MS


@Composable
private fun ChatTopBar(
    name: String,
    avatarUrl: String?,
    subtitle: String,
    subtitleColor: Color,
    online: Boolean,
    onBack: () -> Unit,
    onTitleClick: () -> Unit,
    muted: Boolean,
    locked: Boolean,
    onToggleMute: () -> Unit,
    onToggleLock: () -> Unit,
    onAppearance: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcBackground.copy(alpha = 0.92f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RoundButton(onClick = onBack) {
            Icon(
                Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = stringResource(R.string.back),
                tint = NcTextPrimary,
            )
        }
        Spacer(Modifier.width(10.dp))
        Row(
            modifier = Modifier.weight(1f).clickable(onClick = onTitleClick),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                AvatarInitial(name.ifEmpty { "?" }, size = 42.dp, imageUrl = avatarUrl)
                if (online) {
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .size(13.dp)
                            .background(NcBackground, CircleShape)
                            .padding(2.dp)
                            .background(NcPrimary, CircleShape),
                    )
                }
            }
            Column(Modifier.padding(start = 12.dp)) {
                Text(name, color = NcTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(subtitle, color = subtitleColor, fontSize = 12.sp, maxLines = 1)
            }
        }
        Box {
            RoundButton(onClick = { menuOpen = true }) {
                Icon(Icons.Outlined.MoreHoriz, contentDescription = null, tint = NcTextPrimary)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(if (muted) R.string.unmute_chat else R.string.mute_chat)) },
                    leadingIcon = {
                        Icon(if (muted) Icons.Outlined.NotificationsOff else Icons.Outlined.Notifications, contentDescription = null)
                    },
                    onClick = {
                        menuOpen = false
                        onToggleMute()
                    },
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.chat_appearance)) },
                    leadingIcon = { Icon(Icons.Outlined.Palette, contentDescription = null) },
                    onClick = {
                        menuOpen = false
                        onAppearance()
                    },
                )
                DropdownMenuItem(
                    text = { Text(stringResource(if (locked) R.string.chat_unlock else R.string.chat_lock)) },
                    leadingIcon = {
                        Icon(if (locked) Icons.Outlined.LockOpen else Icons.Outlined.Lock, contentDescription = null)
                    },
                    onClick = {
                        menuOpen = false
                        onToggleLock()
                    },
                )
            }
        }
    }
}

@Composable
private fun RoundButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(NcCard)
            .border(1.dp, NcOutline, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun ScrollToLatest(visible: Boolean, unseen: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn() + scaleIn(),
        exit = fadeOut() + scaleOut(),
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                modifier = Modifier
                    .padding(top = 8.dp)
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(NcSurface)
                    .border(1.dp, NcOutline, CircleShape)
                    .clickable(onClick = onClick),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, tint = NcTextPrimary)
            }
            if (unseen > 0) {
                Box(
                    modifier = Modifier
                        .background(NcPrimary, CircleShape)
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                ) {
                    Text(
                        if (unseen > 99) "99+" else unseen.toString(),
                        color = NcOnPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun DayHeader(millis: Long) {
    val context = LocalContext.current
    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
        Text(
            formatDayHeader(context, millis),
            color = NcTextSecondary, fontSize = 12.sp,
            modifier = Modifier
                .background(NcCard, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun MessageBubble(
    item: ChatMessage,
    appearance: ChatAppearance,
    onRetry: () -> Unit,
    onOpenImage: (String) -> Unit,
    onOpenAttachment: (Attachment) -> Unit,
    onOpenViewOnce: () -> Unit,
    onLongPress: () -> Unit,
    tail: Boolean,
    showName: Boolean,
) {
    val mine = item.mine
    val failed = item.status == MessageStatus.FAILED
    val shape = appearance.shape.bubble(mine, tail)
    val fg = if (mine) appearance.theme.contentColor() else NcTextPrimary
    val fill = if (mine) appearance.theme.brush() else SolidColor(NcCard)
    val imageOnly = item.message.kind == MessageKind.IMAGE && !item.message.deleted &&
        !item.message.viewOnce && item.message.attachments.isNotEmpty()
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(fill, shape)
                .then(if (mine) Modifier else Modifier.border(1.dp, NcOutline, shape))
                .combinedClickable(onClick = { if (failed) onRetry() }, onLongClick = onLongPress)
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            item.senderName?.takeIf { showName }?.let {
                Text(
                    it,
                    color = NcSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 2.dp),
                )
            }
            if (item.message.forwarded && !item.message.deleted) {
                Text(
                    "↪ " + stringResource(R.string.forwarded_label),
                    color = fg.copy(alpha = 0.7f), fontSize = 11.sp,
                    fontStyle = FontStyle.Italic,
                    modifier = Modifier.padding(bottom = 2.dp),
                )
            }
            val attachment = item.message.attachments.firstOrNull()
            when {
                item.message.deleted -> Text(
                    stringResource(R.string.message_deleted),
                    color = fg.copy(alpha = 0.7f),
                    fontStyle = FontStyle.Italic, fontSize = 15.sp,
                )
                item.message.viewOnce -> ViewOnceBubble(item, onOpenViewOnce, onLongPress, fg)
                attachment == null && item.message.kind != MessageKind.TEXT -> Text(
                    stringResource(R.string.media_unavailable),
                    color = NcTextSecondary, fontStyle = FontStyle.Italic, fontSize = 14.sp,
                )
                attachment != null && item.message.kind == MessageKind.IMAGE ->
                    ImageContent(
                        a = attachment,
                        onOpen = { url -> if (failed) onRetry() else onOpenImage(url) },
                        onLongPress = onLongPress,
                    ) {
                        TimePill(item, Modifier.align(Alignment.BottomEnd).padding(6.dp))
                    }
                attachment != null && item.message.kind == MessageKind.AUDIO ->
                    AudioContent(attachment, fg)
                attachment != null && item.message.kind == MessageKind.VIDEO ->
                    FileContent(attachment, video = true, onOpen = { onOpenAttachment(attachment) }, onLongPress = onLongPress, fg = fg)
                attachment != null ->
                    FileContent(attachment, video = false, onOpen = { onOpenAttachment(attachment) }, onLongPress = onLongPress, fg = fg)
                else -> Text(item.message.body, color = fg, fontSize = 16.sp)
            }
            if (!imageOnly) Row(
                modifier = Modifier.align(Alignment.End).padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (failed) {
                    Text(stringResource(R.string.message_not_sent), color = fg, fontSize = 11.sp)
                } else if (item.message.createdAtRaw.isNotEmpty()) {
                    Text(
                        formatClock(item.message.createdAtMillis),
                        color = fg.copy(alpha = 0.7f), fontSize = 11.sp,
                    )
                }
                if (mine) {
                    Spacer(Modifier.size(4.dp))
                    StatusIcon(item.status, fg)
                }
            }
        }
    }
}

/** Bubble for a photo/video that can be opened only once. The content itself is never shown here. */
@Composable
private fun ViewOnceBubble(item: ChatMessage, onOpen: () -> Unit, onLongPress: () -> Unit, fg: Color) {
    val isVideo = item.message.kind == MessageKind.VIDEO
    val display = ChatLogic.viewOnceDisplay(item.mine, item.viewedByMe, item.viewedByOther)
    val label = stringResource(
        when (display) {
            ViewOnceDisplay.TAP_TO_VIEW ->
                if (isVideo) R.string.view_once_tap_video else R.string.view_once_tap_photo
            ViewOnceDisplay.OPENED_BY_ME -> R.string.view_once_opened
            ViewOnceDisplay.SENT_NOT_OPENED ->
                if (isVideo) R.string.view_once_sent_video else R.string.view_once_sent_photo
            ViewOnceDisplay.SENT_OPENED -> R.string.view_once_opened_by_other
        },
    )
    val opened = display == ViewOnceDisplay.OPENED_BY_ME || display == ViewOnceDisplay.SENT_OPENED
    Row(
        modifier = Modifier
            .widthIn(min = 180.dp)
            .combinedClickable(
                onClick = { if (display == ViewOnceDisplay.TAP_TO_VIEW) onOpen() },
                onLongClick = onLongPress,
            )
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (opened) Icons.Outlined.Done else Icons.Outlined.LooksOne,
            contentDescription = null,
            tint = fg.copy(alpha = if (opened) 0.6f else 1f),
            modifier = Modifier.size(28.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            label,
            color = fg.copy(alpha = if (opened) 0.6f else 1f),
            fontStyle = if (opened) FontStyle.Italic else FontStyle.Normal,
            fontSize = 15.sp,
        )
    }
}

/**
 * Full-screen viewer for a view-once photo/video.
 * Screenshots and screen recording are blocked while it is open (FLAG_SECURE), and the
 * image is never written to the disk or memory cache.
 */
@Composable
private fun ViewOnceViewer(state: ViewOnceUi, onClose: () -> Unit) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect { window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE) }

        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            when (state) {
                ViewOnceUi.None, ViewOnceUi.Loading -> CircularProgressIndicator(color = NcPrimary)
                is ViewOnceUi.Failed -> Text(
                    state.error.message(),
                    color = NcTextPrimary, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp),
                )
                is ViewOnceUi.Ready -> {
                    val content = state.content
                    if (content.kind == MessageKind.VIDEO) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    val controller = MediaController(ctx)
                                    controller.setAnchorView(this)
                                    setMediaController(controller)
                                    setVideoURI(Uri.parse(content.url))
                                    setOnPreparedListener { start() }
                                }
                            },
                            onRelease = { it.stopPlayback() },
                        )
                    } else {
                        val ctx = LocalContext.current
                        AsyncImage(
                            model = ImageRequest.Builder(ctx)
                                .data(content.url)
                                .diskCachePolicy(CachePolicy.DISABLED)
                                .memoryCachePolicy(CachePolicy.DISABLED)
                                .build(),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }
            IconButton(
                onClick = onClose,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 32.dp, end = 8.dp),
            ) {
                Icon(
                    Icons.Outlined.Close,
                    contentDescription = stringResource(R.string.close),
                    tint = NcTextPrimary,
                )
            }
            Text(
                stringResource(R.string.view_once_hint),
                color = NcTextSecondary, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
            )
        }
    }
}


@Composable
private fun ImageContent(
    a: Attachment,
    onOpen: (String) -> Unit,
    onLongPress: () -> Unit,
    overlay: @Composable BoxScope.() -> Unit,
) {
    val ratio = if (a.width != null && a.height != null && a.height > 0) {
        (a.width.toFloat() / a.height).coerceIn(0.6f, 1.8f)
    } else {
        1f
    }
    Box(
        modifier = Modifier
            .width(250.dp)
            .aspectRatio(ratio)
            .clip(RoundedCornerShape(16.dp))
            .background(NcSurface)
            .combinedClickable(onClick = { a.url?.let(onOpen) }, onLongClick = onLongPress),
        contentAlignment = Alignment.Center,
    ) {
        if (a.url != null) {
            AsyncImage(
                model = a.url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            CircularProgressIndicator(color = NcTextSecondary, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
        }
        overlay()
    }
}

@Composable
private fun TimePill(item: ChatMessage, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (item.message.createdAtRaw.isNotEmpty()) {
            Text(formatClock(item.message.createdAtMillis), color = Color.White, fontSize = 11.sp)
            Spacer(Modifier.width(4.dp))
        }
        if (item.mine) StatusIcon(item.status, Color.White)
    }
}

@Composable
private fun FileContent(a: Attachment, video: Boolean, onOpen: () -> Unit, onLongPress: () -> Unit, fg: Color) {
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .widthIn(min = 200.dp)
            .combinedClickable(onClick = { if (a.url != null) onOpen() }, onLongClick = onLongPress),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (video) Icons.Outlined.PlayCircle else Icons.Outlined.InsertDriveFile,
            contentDescription = null, tint = fg, modifier = Modifier.size(36.dp),
        )
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                a.fileName, color = fg, fontSize = 15.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            val details = buildList {
                add(Formatter.formatShortFileSize(context, a.sizeBytes))
                if (video && a.durationMs != null) add(formatDuration(a.durationMs))
            }.joinToString(" · ")
            Text(details, color = fg.copy(alpha = 0.7f), fontSize = 12.sp)
        }
    }
}


@Composable
private fun AudioContent(a: Attachment, fg: Color) {
    val context = LocalContext.current
    var playing by remember { mutableStateOf(false) }
    var prepared by remember(a.url) { mutableStateOf(false) }
    var positionMs by remember { mutableIntStateOf(0) }
    val player = remember { MediaPlayer() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(playing) {
        while (playing) {
            positionMs = try {
                player.currentPosition
            } catch (e: IllegalStateException) {
                0
            }
            delay(100)
        }
    }

    fun toggle() {
        val url = a.url ?: return
        if (!prepared) {
            try {
                player.reset()
                player.setDataSource(context, Uri.parse(url))
                player.setOnPreparedListener {
                    prepared = true
                    it.start()
                    playing = true
                }
                player.setOnCompletionListener {
                    playing = false
                    positionMs = 0
                    it.seekTo(0)
                }
                player.setOnErrorListener { _, _, _ ->
                    playing = false
                    prepared = false
                    true
                }
                player.prepareAsync()
            } catch (e: Exception) {
                playing = false
                prepared = false
            }
        } else if (playing) {
            player.pause()
            playing = false
        } else {
            player.start()
            playing = true
        }
    }

    val total = (a.durationMs ?: 0).coerceAtLeast(1)
    val progress = (positionMs.toFloat() / total).coerceIn(0f, 1f)
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.widthIn(min = 230.dp)) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(fg.copy(alpha = 0.2f))
                .clickable(enabled = a.url != null) { toggle() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                contentDescription = null, tint = fg, modifier = Modifier.size(26.dp),
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Waveform(seed = (a.sizeBytes xor (a.durationMs ?: 0).toLong()).toInt(), progress = progress, color = fg)
            Text(
                formatDuration(if (playing || positionMs > 0) positionMs else (a.durationMs ?: 0)),
                color = fg.copy(alpha = 0.7f), fontSize = 11.sp,
            )
        }
    }
}

/** Decorative bars (the real loudness is not stored); the played part is drawn brighter. */
@Composable
private fun Waveform(seed: Int, progress: Float, color: Color) {
    val bars = remember(seed) {
        val random = java.util.Random(seed.toLong())
        List(32) { 0.25f + random.nextFloat() * 0.75f }
    }
    Canvas(Modifier.fillMaxWidth().height(28.dp)) {
        val gap = 3.dp.toPx()
        val barWidth = (size.width - gap * (bars.size - 1)) / bars.size
        bars.forEachIndexed { i, h ->
            val barHeight = size.height * h
            val played = (i + 0.5f) / bars.size <= progress
            drawRoundRect(
                color = if (played) color else color.copy(alpha = 0.35f),
                topLeft = Offset(i * (barWidth + gap), (size.height - barHeight) / 2),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2),
            )
        }
    }
}

@Composable
private fun StatusIcon(status: MessageStatus, fg: Color) {
    val (icon, tint) = when (status) {
        MessageStatus.SENDING -> Icons.Outlined.Schedule to fg.copy(alpha = 0.65f)
        MessageStatus.FAILED -> Icons.Outlined.ErrorOutline to NcError
        MessageStatus.SENT -> Icons.Outlined.Done to fg.copy(alpha = 0.65f)
        MessageStatus.DELIVERED -> Icons.Outlined.DoneAll to fg.copy(alpha = 0.65f)
        MessageStatus.READ -> Icons.Outlined.DoneAll to Color(0xFF2F9BFF)
    }
    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
}

@Composable
private fun MessageInput(
    text: String,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onPickMedia: () -> Unit,
    onPickViewOnce: () -> Unit,
    onPickFile: () -> Unit,
    onMic: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcSurface)
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(
                    Icons.Outlined.Add,
                    contentDescription = stringResource(R.string.attach),
                    tint = NcTextSecondary,
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.attach_photo_video)) },
                    onClick = {
                        menuOpen = false
                        onPickMedia()
                    },
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.attach_photo_video_once)) },
                    leadingIcon = { Icon(Icons.Outlined.LooksOne, contentDescription = null) },
                    onClick = {
                        menuOpen = false
                        onPickViewOnce()
                    },
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.attach_file)) },
                    onClick = {
                        menuOpen = false
                        onPickFile()
                    },
                )
            }
        }
        OutlinedTextField(
            value = text,
            onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text(stringResource(R.string.chat_input_hint), color = NcTextSecondary) },
            maxLines = 4,
            shape = RoundedCornerShape(24.dp),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = NcTextPrimary,
                unfocusedTextColor = NcTextPrimary,
                focusedContainerColor = NcCard,
                unfocusedContainerColor = NcCard,
                cursorColor = NcPrimary,
                focusedBorderColor = NcPrimary,
                unfocusedBorderColor = NcOutline,
            ),
        )
        Spacer(Modifier.width(6.dp))
        if (text.isBlank()) {
            RoundAction(onClick = onMic, filled = false) {
                Icon(
                    Icons.Outlined.Mic,
                    contentDescription = stringResource(R.string.voice_record),
                    tint = NcPrimary,
                )
            }
        } else {
            RoundAction(onClick = onSend, filled = true) {
                Icon(
                    Icons.AutoMirrored.Outlined.Send,
                    contentDescription = stringResource(R.string.send),
                    tint = NcOnPrimary,
                )
            }
        }
        Spacer(Modifier.width(4.dp))
    }
}

@Composable
private fun RecordingBar(elapsedMs: Int, onCancel: () -> Unit, onSend: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NcSurface)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onCancel) {
            Icon(
                Icons.Outlined.Delete,
                contentDescription = stringResource(R.string.cancel),
                tint = NcError,
            )
        }
        Icon(Icons.Filled.FiberManualRecord, contentDescription = null, tint = NcError, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            stringResource(R.string.voice_recording) + "  " + formatDuration(elapsedMs),
            color = NcTextPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f),
        )
        IconButton(onClick = onSend) {
            Icon(
                Icons.AutoMirrored.Outlined.Send,
                contentDescription = stringResource(R.string.send),
                tint = NcPrimary,
            )
        }
    }
}

@Composable
private fun typingLabel(t: TypingUi): String {
    val recording = t.state == TypingState.RECORDING
    return when {
        t.names.isEmpty() ->
            stringResource(if (recording) R.string.chat_recording else R.string.chat_typing)
        t.names.size == 1 ->
            stringResource(if (recording) R.string.group_recording else R.string.group_typing, t.names[0])
        else -> stringResource(R.string.group_several_typing)
    }
}

/** Animated "typing…" / "recording…" bubble, shown just above the message box. */
@Composable
private fun TypingBubbleRow(typing: TypingUi, appearance: ChatAppearance) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .background(NcCard, appearance.shape.bubble(mine = false))
                .border(1.dp, NcOutline, appearance.shape.bubble(mine = false))
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            if (typing.state == TypingState.RECORDING) RecordingWave(NcPrimary) else TypingDots(NcPrimary)
        }
        Spacer(Modifier.width(8.dp))
        Text(typingLabel(typing), color = NcPrimary, fontSize = 12.sp)
    }
}

@Composable
private fun TypingDots(color: Color) {
    val transition = rememberInfiniteTransition(label = "typing")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val v by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(450),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 150),
                ),
                label = "dot$i",
            )
            Box(
                Modifier
                    .size(8.dp)
                    .graphicsLayer {
                        translationY = -6.dp.toPx() * v
                        alpha = 0.4f + 0.6f * v
                    }
                    .background(color, CircleShape),
            )
        }
    }
}

@Composable
private fun RecordingWave(color: Color) {
    val transition = rememberInfiniteTransition(label = "recording")
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Mic, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(2.dp))
        repeat(5) { i ->
            val h by transition.animateFloat(
                initialValue = 4f,
                targetValue = 18f,
                animationSpec = infiniteRepeatable(
                    animation = tween(420 + i * 60),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 90),
                ),
                label = "bar$i",
            )
            Box(Modifier.width(3.dp).height(h.dp).background(color, RoundedCornerShape(2.dp)))
        }
    }
}

@Composable
private fun RoundAction(onClick: () -> Unit, filled: Boolean, content: @Composable () -> Unit) {
    val fill = if (filled) Brush.horizontalGradient(listOf(NcPrimary, NcSecondary)) else SolidColor(NcCard)
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(fill)
            .then(if (filled) Modifier else Modifier.border(1.dp, NcOutline, CircleShape))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

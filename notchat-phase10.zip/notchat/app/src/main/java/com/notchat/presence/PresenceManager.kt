package com.notchat.presence

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.PresenceRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Sends an "I am here" heartbeat every 30 s while the app is on screen. When the app goes to
 * the background it stops, and the server considers the user offline after 75 s.
 */
@Singleton
class PresenceManager @Inject constructor(
    private val presence: PresenceRepository,
    private val auth: AuthRepository,
) : DefaultLifecycleObserver {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onStart(owner: LifecycleOwner) {
        job?.cancel()
        job = scope.launch {
            while (true) {
                if (auth.sessionState.value is SessionState.SignedIn) {
                    presence.touch()
                    delay(HEARTBEAT_MS)
                } else {
                    delay(2_000L) // not signed in yet (or signed out): check again shortly
                }
            }
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        job?.cancel()
        job = null
    }

    private companion object {
        const val HEARTBEAT_MS = 30_000L
    }
}

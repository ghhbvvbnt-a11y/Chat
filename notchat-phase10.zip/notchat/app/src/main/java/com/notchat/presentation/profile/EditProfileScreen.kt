package com.notchat.presentation.profile

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOnPrimary
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.model.Profile
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.NcTextField

private const val NAME_MAX = 50
private const val BIO_MAX = 200

@Composable
fun EditProfileScreen(
    onBack: () -> Unit,
    vm: EditProfileViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    LaunchedEffect(Unit) { vm.saved.collect { onBack() } }

    Scaffold(containerColor = NcBackground) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).systemBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = NcTextPrimary,
                    )
                }
                Text(
                    stringResource(R.string.edit_profile),
                    color = NcTextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                )
            }
            val profile = ui.profile
            when {
                profile != null -> EditForm(profile, ui, vm)
                ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NcPrimary)
                }
                else -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        ui.loadError?.message() ?: stringResource(R.string.profile_load_failed),
                        color = NcError,
                    )
                    TextButton(onClick = vm::load) {
                        Text(stringResource(R.string.retry), color = NcSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun EditForm(profile: Profile, ui: EditProfileUiState, vm: EditProfileViewModel) {
    var name by rememberSaveable(profile.id) { mutableStateOf(profile.displayName) }
    var bio by rememberSaveable(profile.id) { mutableStateOf(profile.bio) }
    var country by rememberSaveable(profile.id) { mutableStateOf(profile.country.orEmpty()) }
    var submitted by remember { mutableStateOf(false) }

    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setAvatar(uri)
    }

    val nameValid = name.isNotBlank() && name.trim().length <= NAME_MAX
    val countryValid = country.isEmpty() || country.length == 2
    val nameError = if (submitted && !nameValid) stringResource(R.string.err_required) else null
    val countryError = if (submitted && !countryValid) stringResource(R.string.err_country_format) else null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier.clickable(enabled = !ui.avatarBusy) {
                pickAvatar.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            contentAlignment = Alignment.BottomEnd,
        ) {
            AvatarInitial(name.ifBlank { profile.username }, size = 120.dp, imageUrl = profile.avatarUrl)
            Box(
                modifier = Modifier.size(36.dp).background(NcPrimary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (ui.avatarBusy) {
                    CircularProgressIndicator(
                        color = NcOnPrimary, strokeWidth = 2.dp, modifier = Modifier.size(18.dp),
                    )
                } else {
                    Icon(
                        Icons.Outlined.PhotoCamera, contentDescription = stringResource(R.string.change_photo),
                        tint = NcOnPrimary, modifier = Modifier.size(18.dp),
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.Center) {
            TextButton(
                onClick = { pickAvatar.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = !ui.avatarBusy,
            ) { Text(stringResource(R.string.change_photo), color = NcSecondary) }
            if (profile.avatarUrl != null) {
                TextButton(onClick = vm::removeAvatar, enabled = !ui.avatarBusy) {
                    Text(stringResource(R.string.remove_photo), color = NcError)
                }
            }
        }
        Text("@${profile.username}", color = NcTextSecondary, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))

        NcTextField(
            value = name,
            onValueChange = { name = it.take(NAME_MAX) },
            label = stringResource(R.string.display_name),
            leadingIcon = Icons.Outlined.Badge,
            error = nameError,
            hint = "${name.length}/$NAME_MAX",
        )
        NcTextField(
            value = bio,
            onValueChange = { bio = it.take(BIO_MAX) },
            label = stringResource(R.string.bio),
            singleLine = false,
            minLines = 3,
            maxLines = 5,
            imeAction = ImeAction.Default,
            hint = "${bio.length}/$BIO_MAX",
        )
        NcTextField(
            value = country,
            onValueChange = { country = it.uppercase().filter { c -> c in 'A'..'Z' }.take(2) },
            label = stringResource(R.string.country_code),
            leadingIcon = Icons.Outlined.Public,
            keyboardType = KeyboardType.Ascii,
            imeAction = ImeAction.Done,
            error = countryError,
        )
        ui.error?.let {
            Spacer(Modifier.height(4.dp))
            Text(it.message(), color = NcError, fontSize = 13.sp, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(16.dp))
        GradientButton(
            text = stringResource(R.string.save),
            loading = ui.saving,
            enabled = !ui.avatarBusy,
            onClick = {
                submitted = true
                if (nameValid && countryValid) vm.save(name, bio, country)
            },
        )
        Spacer(Modifier.height(24.dp))
    }
}

package com.notchat.presentation.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchUiState(
    val loading: Boolean = false,
    val results: List<Profile> = emptyList(),
    val error: AuthError? = null,
    /** True once a search for the current text has finished (to tell "no results" from "not searched"). */
    val searched: Boolean = false,
    /** True when the typed text is too short to search yet. */
    val tooShort: Boolean = false,
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val repo: UserRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(SearchUiState())
    val ui: StateFlow<SearchUiState> = _ui.asStateFlow()
    private var job: Job? = null

    fun onQueryChange(raw: String) {
        job?.cancel()
        val term = raw.trim().removePrefix("@").trim()
        if (term.isEmpty()) {
            _ui.value = SearchUiState()
            return
        }
        if (term.length < MIN_CHARS) {
            _ui.value = SearchUiState(tooShort = true)
            return
        }
        _ui.update { it.copy(loading = true, error = null, tooShort = false) }
        job = viewModelScope.launch {
            delay(DEBOUNCE_MS)
            when (val r = repo.searchProfiles(term)) {
                is Outcome.Success ->
                    _ui.value = SearchUiState(results = r.value, searched = true)
                is Outcome.Failure ->
                    _ui.value = SearchUiState(error = r.error, searched = true)
            }
        }
    }

    private companion object {
        const val MIN_CHARS = 2
        const val DEBOUNCE_MS = 350L
    }
}

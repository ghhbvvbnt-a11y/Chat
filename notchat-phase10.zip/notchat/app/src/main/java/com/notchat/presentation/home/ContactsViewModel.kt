package com.notchat.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Profile
import com.notchat.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ContactsUiState(
    val loading: Boolean = true,
    val items: List<Profile> = emptyList(),
    val error: AuthError? = null,
)

@HiltViewModel
class ContactsViewModel @Inject constructor(
    private val users: UserRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(ContactsUiState())
    val ui: StateFlow<ContactsUiState> = _ui.asStateFlow()

    init {
        load()
        viewModelScope.launch { users.contactsChanged.collect { load() } }
    }

    fun load() {
        viewModelScope.launch {
            when (val r = users.contacts()) {
                is Outcome.Success -> _ui.value = ContactsUiState(loading = false, items = r.value)
                is Outcome.Failure -> _ui.update { it.copy(loading = false, error = r.error) }
            }
        }
    }
}

package com.notchat.presentation.chat

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcTextPrimary
import com.notchat.domain.model.ChatMessage
import com.notchat.domain.model.MessageKind
import com.notchat.domain.model.MessageStatus

/** What can be done with a message, shown when it is long-pressed. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageActionsSheet(
    item: ChatMessage,
    onDismiss: () -> Unit,
    onCopy: () -> Unit,
    onForward: () -> Unit,
    onDeleteForMe: () -> Unit,
    onDeleteForEveryone: () -> Unit,
) {
    val m = item.message
    val stored = m.createdAtRaw.isNotEmpty() // false while sending or after a failed send
    val canCopy = m.kind == MessageKind.TEXT && !m.deleted && m.body.isNotBlank()
    val canForward = stored && !m.deleted && !m.viewOnce && item.status != MessageStatus.FAILED
    val canDeleteForEveryone = item.mine && stored && !m.deleted

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = NcCard) {
        Column(Modifier.padding(bottom = 24.dp)) {
            if (canCopy) ActionRow(Icons.Outlined.ContentCopy, stringResource(R.string.msg_copy), NcTextPrimary, onCopy)
            if (canForward) ActionRow(Icons.AutoMirrored.Outlined.Send, stringResource(R.string.msg_forward), NcTextPrimary, onForward)
            ActionRow(
                Icons.Outlined.Delete,
                stringResource(if (stored) R.string.msg_delete_me else R.string.msg_discard),
                NcError,
                onDeleteForMe,
            )
            if (canDeleteForEveryone) {
                ActionRow(Icons.Outlined.DeleteForever, stringResource(R.string.msg_delete_everyone), NcError, onDeleteForEveryone)
            }
        }
    }
}

@Composable
private fun ActionRow(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = tint)
        Spacer(Modifier.width(16.dp))
        Text(label, color = tint, fontSize = 16.sp)
    }
}

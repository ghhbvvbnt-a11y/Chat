package com.notchat.data.remote

import com.notchat.domain.model.Profile
import org.json.JSONArray
import org.json.JSONObject

internal fun JSONObject.optNullableString(key: String): String? =
    if (isNull(key)) null else getString(key)

internal fun JSONObject.toProfile(): Profile = Profile(
    id = getString("id"),
    username = getString("username"),
    displayName = getString("display_name"),
    avatarUrl = optNullableString("avatar_url"),
    bio = if (isNull("bio")) "" else optString("bio", ""),
    country = optNullableString("country"),
)

internal fun JSONArray.toProfiles(): List<Profile> =
    List(length()) { index -> getJSONObject(index).toProfile() }

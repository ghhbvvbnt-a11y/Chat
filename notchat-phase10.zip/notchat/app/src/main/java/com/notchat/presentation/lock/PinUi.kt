package com.notchat.presentation.lock

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Backspace
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.domain.PinPolicy
import com.notchat.domain.model.PinResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Four dots that fill as digits are typed. */
@Composable
fun PinDots(filled: Int, error: Boolean) {
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        repeat(PinPolicy.LENGTH) { i ->
            val on = i < filled
            Box(
                Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            error -> NcError
                            on -> NcPrimary
                            else -> NcOutline
                        },
                    ),
            )
        }
    }
}

@Composable
fun PinKeypad(enabled: Boolean, onDigit: (Char) -> Unit, onBackspace: () -> Unit) {
    val rows = listOf("123", "456", "789")
    Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                row.forEach { d -> KeyButton(d.toString(), enabled) { onDigit(d) } }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            Spacer(Modifier.size(72.dp))
            KeyButton("0", enabled) { onDigit('0') }
            Box(
                Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .clickable(enabled = enabled, onClick = onBackspace),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Outlined.Backspace,
                    contentDescription = stringResource(R.string.pin_backspace),
                    tint = NcTextSecondary,
                )
            }
        }
    }
}

@Composable
private fun KeyButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(72.dp)
            .alpha(if (enabled) 1f else 0.35f)
            .clip(CircleShape)
            .background(NcCard)
            .border(1.dp, NcOutline, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = NcTextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Medium)
    }
}

/** Lock icon, title, dots and keypad. Calls [onComplete] with the 4 digits, then clears itself. */
@Composable
fun PinEntry(
    title: String,
    subtitle: String?,
    error: String?,
    enabled: Boolean,
    onComplete: (String) -> Unit,
) {
    var pin by remember { mutableStateOf("") }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Outlined.Lock, contentDescription = null, tint = NcPrimary, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, color = NcTextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        if (subtitle != null) {
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = NcTextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        PinDots(filled = pin.length, error = error != null)
        Box(Modifier.height(44.dp).padding(top = 10.dp), contentAlignment = Alignment.Center) {
            if (error != null) Text(error, color = NcError, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(12.dp))
        PinKeypad(
            enabled = enabled,
            onDigit = { d ->
                if (pin.length < PinPolicy.LENGTH) {
                    pin += d
                    if (pin.length == PinPolicy.LENGTH) {
                        val entered = pin
                        pin = ""
                        onComplete(entered)
                    }
                }
            },
            onBackspace = { pin = pin.dropLast(1) },
        )
    }
}

@Composable
private fun PinFrame(onCancel: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(NcBackground).systemBarsPadding()) {
        IconButton(onClick = onCancel, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Icon(Icons.Outlined.Close, contentDescription = stringResource(R.string.cancel), tint = NcTextPrimary)
        }
        Box(Modifier.align(Alignment.Center).padding(horizontal = 24.dp)) { content() }
    }
}

/** Asks for the existing PIN; handles wrong attempts and the temporary lockout. */
@Composable
fun PinVerifyContent(
    title: String,
    subtitle: String?,
    onCancel: () -> Unit,
    verify: suspend (String) -> PinResult,
    remainingMillis: () -> Long,
    onSuccess: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    var waitSeconds by remember { mutableIntStateOf(((remainingMillis() + 999) / 1000).toInt()) }
    var showForgot by remember { mutableStateOf(false) }

    LaunchedEffect(waitSeconds > 0) {
        while (waitSeconds > 0) {
            delay(1_000L)
            waitSeconds = ((remainingMillis() + 999) / 1000).toInt()
        }
    }

    PinFrame(onCancel) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            PinEntry(
                title = title,
                subtitle = subtitle,
                error = if (waitSeconds > 0) context.getString(R.string.pin_locked_out, waitSeconds) else error,
                enabled = waitSeconds == 0,
            ) { pin ->
                scope.launch {
                    when (val r = verify(pin)) {
                        PinResult.Ok -> onSuccess()
                        is PinResult.Wrong -> error = context.getString(R.string.pin_wrong, r.attemptsLeft)
                        is PinResult.LockedOut -> {
                            error = null
                            waitSeconds = ((r.untilMillis - System.currentTimeMillis() + 999) / 1000).toInt()
                        }
                    }
                }
            }
            TextButton(onClick = { showForgot = true }) {
                Text(stringResource(R.string.pin_forgot), color = NcSecondary)
            }
        }
    }

    if (showForgot) {
        AlertDialog(
            onDismissRequest = { showForgot = false },
            containerColor = NcCard,
            titleContentColor = NcTextPrimary,
            textContentColor = NcTextSecondary,
            title = { Text(stringResource(R.string.pin_forgot)) },
            text = { Text(stringResource(R.string.pin_forgot_body)) },
            confirmButton = {
                TextButton(onClick = { showForgot = false }) {
                    Text(stringResource(R.string.done), color = NcSecondary)
                }
            },
        )
    }
}

/** Full-screen cover shown instead of a locked chat. */
@Composable
fun PinGate(
    onBack: () -> Unit,
    verify: suspend (String) -> PinResult,
    remainingMillis: () -> Long,
    onUnlocked: () -> Unit,
) {
    // Swallows touches so nothing underneath can be tapped.
    Box(Modifier.fillMaxSize().clickable(enabled = true, onClick = {})) {
        PinVerifyContent(
            title = stringResource(R.string.pin_chat_locked),
            subtitle = stringResource(R.string.pin_enter_to_open),
            onCancel = onBack,
            verify = verify,
            remainingMillis = remainingMillis,
            onSuccess = onUnlocked,
        )
    }
}

@Composable
private fun FullScreenDialog(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize()) { content() }
    }
}

@Composable
fun PinVerifyDialog(
    title: String,
    subtitle: String?,
    onDismiss: () -> Unit,
    verify: suspend (String) -> PinResult,
    remainingMillis: () -> Long,
    onVerified: () -> Unit,
) {
    FullScreenDialog(onDismiss) {
        PinVerifyContent(title, subtitle, onDismiss, verify, remainingMillis, onVerified)
    }
}

/** Two steps: enter a new PIN, then enter it again. */
@Composable
fun PinCreateDialog(onDismiss: () -> Unit, onCreated: (String) -> Unit) {
    val context = LocalContext.current
    var first by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    FullScreenDialog(onDismiss) {
        PinFrame(onDismiss) {
            PinEntry(
                title = stringResource(if (first == null) R.string.pin_create else R.string.pin_confirm),
                subtitle = stringResource(R.string.pin_create_hint),
                error = error,
                enabled = true,
            ) { pin ->
                val saved = first
                when {
                    saved == null -> {
                        first = pin
                        error = null
                    }
                    saved == pin -> onCreated(pin)
                    else -> {
                        first = null
                        error = context.getString(R.string.pin_mismatch)
                    }
                }
            }
        }
    }
}

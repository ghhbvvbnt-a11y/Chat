package com.notchat.presentation.chat

import androidx.lifecycle.ViewModel
import com.notchat.data.local.ChatAppearanceStore
import com.notchat.domain.model.ChatAppearance
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class AppearanceViewModel @Inject constructor(
    private val store: ChatAppearanceStore,
) : ViewModel() {
    val appearance: StateFlow<ChatAppearance> = store.appearance
    fun set(value: ChatAppearance) = store.update(value)
}

package com.notchat.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Conversation
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.SessionState
import com.notchat.domain.repository.AuthRepository
import com.notchat.domain.repository.ChatRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ConversationsUiState(
    val myId: String = "",
    val loading: Boolean = true,
    val items: List<Conversation> = emptyList(),
    val error: AuthError? = null,
)

@OptIn(FlowPreview::class)
@HiltViewModel
class ConversationsViewModel @Inject constructor(
    private val chat: ChatRepository,
    auth: AuthRepository,
) : ViewModel() {

    private val myId = (auth.sessionState.value as? SessionState.SignedIn)?.userId.orEmpty()
    private val _ui = MutableStateFlow(ConversationsUiState(myId = myId))
    val ui: StateFlow<ConversationsUiState> = _ui.asStateFlow()

    private var refreshJob: Job? = null
    private val reportedDelivered = HashMap<String, String>()

    init {
        chat.startRealtime()
        refresh()
        viewModelScope.launch { chat.changes.debounce(200).collect { refresh() } }
        // Safety net in case the live connection is down or silently not delivering.
        viewModelScope.launch {
            while (true) {
                delay(if (chat.realtimeConnected.value) 30_000L else 8_000L)
                refresh()
            }
        }
    }

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            when (val r = chat.conversations()) {
                is Outcome.Success -> {
                    _ui.update { it.copy(loading = false, items = r.value, error = null) }
                    reportDelivery(r.value)
                }
                is Outcome.Failure -> _ui.update { it.copy(loading = false, error = r.error) }
            }
        }
    }

    /** Tells the server this device has received the latest message of each conversation. */
    private suspend fun reportDelivery(list: List<Conversation>) {
        for (c in list) {
            if (!c.hasMessages || c.lastMessageSenderId == myId) continue
            if (reportedDelivered[c.id] == c.lastMessageAtRaw) continue
            if (chat.markDelivered(c.id, c.lastMessageAtRaw) is Outcome.Success) {
                reportedDelivered[c.id] = c.lastMessageAtRaw
            }
        }
    }

    override fun onCleared() {
        chat.stopRealtime()
    }
}

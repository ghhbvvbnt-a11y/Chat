package com.notchat.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.notchat.core.util.UsernameValidator
import com.notchat.domain.model.AuthError
import com.notchat.domain.model.Outcome
import com.notchat.domain.model.map
import com.notchat.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class AuthEvent { SIGNED_IN, CHECK_EMAIL, RESET_SENT }

enum class UsernameStatus { IDLE, CHECKING, AVAILABLE, TAKEN, ERROR }

data class AuthUiState(
    val loading: Boolean = false,
    val error: AuthError? = null,
    val event: AuthEvent? = null,
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repo: AuthRepository,
) : ViewModel() {

    private val _ui = MutableStateFlow(AuthUiState())
    val ui: StateFlow<AuthUiState> = _ui.asStateFlow()

    private val _username = MutableStateFlow(UsernameStatus.IDLE)
    val username: StateFlow<UsernameStatus> = _username.asStateFlow()

    fun signIn(email: String, password: String) = launchAuth {
        repo.signIn(email, password).map { AuthEvent.SIGNED_IN }
    }

    fun signUp(email: String, password: String, usernameInput: String, displayName: String) = launchAuth {
        repo.signUp(email, password, usernameInput, displayName).map { needsConfirmation ->
            if (needsConfirmation) AuthEvent.CHECK_EMAIL else AuthEvent.SIGNED_IN
        }
    }

    fun sendReset(email: String) = launchAuth {
        repo.sendPasswordReset(email).map { AuthEvent.RESET_SENT }
    }

    /** Called from a LaunchedEffect keyed on the typed username, so a new keystroke cancels this one. */
    suspend fun checkUsername(input: String) {
        if (input.isEmpty() || UsernameValidator.validate(input) != null) {
            _username.value = UsernameStatus.IDLE
            return
        }
        _username.value = UsernameStatus.CHECKING
        delay(400)
        _username.value = when (val r = repo.isUsernameAvailable(input)) {
            is Outcome.Success -> if (r.value) UsernameStatus.AVAILABLE else UsernameStatus.TAKEN
            is Outcome.Failure -> UsernameStatus.ERROR
        }
    }

    private fun launchAuth(block: suspend () -> Outcome<AuthEvent>) {
        if (_ui.value.loading) return
        _ui.update { it.copy(loading = true, error = null, event = null) }
        viewModelScope.launch {
            when (val r = block()) {
                is Outcome.Success -> _ui.update { it.copy(loading = false, event = r.value) }
                is Outcome.Failure -> _ui.update { it.copy(loading = false, error = r.error) }
            }
        }
    }
}

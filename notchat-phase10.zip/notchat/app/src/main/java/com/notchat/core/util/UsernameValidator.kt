package com.notchat.core.util

enum class UsernameError { EMPTY, BAD_START, BAD_CHARS, TOO_SHORT, TOO_LONG }

/**
 * Username rules: starts with an English letter or digit, then English letters,
 * digits or underscore. Length 3..32. Uniqueness is case-insensitive, so the
 * canonical stored form is [normalize] (lowercase).
 */
object UsernameValidator {
    const val MIN_LENGTH = 3
    const val MAX_LENGTH = 32

    private fun isAsciiLetterOrDigit(c: Char) =
        c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9'

    fun validate(input: String): UsernameError? {
        if (input.isEmpty()) return UsernameError.EMPTY
        if (!isAsciiLetterOrDigit(input.first())) return UsernameError.BAD_START
        if (input.any { !isAsciiLetterOrDigit(it) && it != '_' }) return UsernameError.BAD_CHARS
        if (input.length < MIN_LENGTH) return UsernameError.TOO_SHORT
        if (input.length > MAX_LENGTH) return UsernameError.TOO_LONG
        return null
    }

    fun normalize(input: String): String = input.lowercase()
}

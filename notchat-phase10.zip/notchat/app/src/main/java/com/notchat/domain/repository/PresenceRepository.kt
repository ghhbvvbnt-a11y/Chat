package com.notchat.domain.repository

import com.notchat.domain.model.Outcome
import com.notchat.domain.model.Presence

interface PresenceRepository {
    /** "I am here" heartbeat, sent while the app is open. */
    suspend fun touch(): Outcome<Unit>

    /** Success(null) when the person hides their status (or you hide yours, or you share no chat). */
    suspend fun presenceOf(userId: String): Outcome<Presence?>

    /** Whether I show my own online status to others. */
    suspend fun sharing(): Outcome<Boolean>

    suspend fun setSharing(share: Boolean): Outcome<Unit>
}

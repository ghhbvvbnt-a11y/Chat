package com.notchat.data.local

import android.content.Context
import com.notchat.domain.model.ChatAppearance
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Remembers the chat look on this device (not sensitive, so plain preferences). */
@Singleton
class ChatAppearanceStore @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val prefs = context.getSharedPreferences("chat_appearance", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val appearance: StateFlow<ChatAppearance> = _state.asStateFlow()

    fun update(value: ChatAppearance) {
        prefs.edit()
            .putString(K_THEME, value.theme.id)
            .putString(K_SHAPE, value.shape.id)
            .putString(K_BG, value.background.id)
            .apply()
        _state.value = value
    }

    private fun read() = ChatAppearance.fromIds(
        prefs.getString(K_THEME, null),
        prefs.getString(K_SHAPE, null),
        prefs.getString(K_BG, null),
    )

    private companion object {
        const val K_THEME = "theme"
        const val K_SHAPE = "shape"
        const val K_BG = "background"
    }
}

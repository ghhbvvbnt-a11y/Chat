package com.notchat.data.remote

import com.notchat.domain.model.AuthError
import org.json.JSONException
import org.json.JSONObject

/** Converts a Supabase Auth error response into an app-level [AuthError]. */
object AuthErrorMapper {
    fun fromResponse(status: Int, body: String): AuthError {
        val json = try {
            JSONObject(body)
        } catch (e: JSONException) {
            null
        }
        val code = json?.optString("error_code").orEmpty()
        val msg = listOf("msg", "message", "error_description")
            .map { json?.optString(it).orEmpty() }
            .firstOrNull { it.isNotEmpty() }
            .orEmpty()

        return when {
            code == "invalid_credentials" || msg.contains("Invalid login credentials", ignoreCase = true) ->
                AuthError.INVALID_CREDENTIALS
            code == "email_not_confirmed" || msg.contains("Email not confirmed", ignoreCase = true) ->
                AuthError.EMAIL_NOT_CONFIRMED
            code == "user_already_exists" || code == "email_exists" -> AuthError.EMAIL_TAKEN
            code == "weak_password" -> AuthError.WEAK_PASSWORD
            status == 429 || (code.startsWith("over_") && code.endsWith("rate_limit")) -> AuthError.RATE_LIMITED
            msg.contains("Database error saving new user", ignoreCase = true) -> AuthError.USERNAME_TAKEN
            else -> AuthError.UNKNOWN
        }
    }
}

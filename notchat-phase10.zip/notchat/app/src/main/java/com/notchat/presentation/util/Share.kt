package com.notchat.presentation.util

import android.content.Context
import android.content.Intent
import com.notchat.R

fun shareAccount(context: Context, username: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, context.getString(R.string.share_text, username))
    }
    context.startActivity(Intent.createChooser(intent, null))
}

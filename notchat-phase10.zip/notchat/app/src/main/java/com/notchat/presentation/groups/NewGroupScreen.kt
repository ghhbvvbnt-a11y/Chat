package com.notchat.presentation.groups

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcOutline
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.EmptyState
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.NcTextField

@Composable
fun NewGroupScreen(
    onBack: () -> Unit,
    onCreated: (conversationId: String) -> Unit,
    vm: NewGroupViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    LaunchedEffect(Unit) { vm.created.collect { onCreated(it) } }

    Scaffold(containerColor = NcBackground) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).systemBarsPadding().imePadding()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Outlined.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = NcTextPrimary,
                    )
                }
                Text(
                    stringResource(R.string.new_group),
                    color = NcTextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                )
            }
            Column(Modifier.padding(horizontal = 16.dp)) {
                NcTextField(
                    value = ui.name,
                    onValueChange = vm::onNameChange,
                    label = stringResource(R.string.group_name),
                    hint = "${ui.name.length}/60",
                )
                Text(
                    stringResource(R.string.select_members) + " (${ui.selected.size})",
                    color = NcTextSecondary, fontSize = 13.sp,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
                )
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        CircularProgressIndicator(color = NcPrimary, modifier = Modifier.padding(top = 32.dp))
                    }
                    ui.contacts.isEmpty() -> {
                        if (ui.error != null) {
                            Column(
                                Modifier.fillMaxSize().padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                            ) {
                                Text(ui.error!!.message(), color = NcError)
                                TextButton(onClick = vm::load) {
                                    Text(stringResource(R.string.retry), color = NcSecondary)
                                }
                            }
                        } else {
                            EmptyState(
                                icon = Icons.Outlined.Groups,
                                title = stringResource(R.string.group_need_contacts_title),
                                body = stringResource(R.string.group_need_contacts_body),
                            )
                        }
                    }
                    else -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(ui.contacts, key = { it.id }) { p ->
                            val checked = p.id in ui.selected
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NcCard, RoundedCornerShape(16.dp))
                                    .clickable { vm.toggle(p.id) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                AvatarInitial(p.displayName, size = 40.dp, imageUrl = p.avatarUrl)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        p.displayName, color = NcTextPrimary, fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold, maxLines = 1,
                                    )
                                    Text("@${p.username}", color = NcSecondary, fontSize = 12.sp, maxLines = 1)
                                }
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { vm.toggle(p.id) },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = NcPrimary,
                                        uncheckedColor = NcOutline,
                                    ),
                                )
                            }
                        }
                    }
                }
            }
            Column(Modifier.padding(16.dp)) {
                if (ui.error != null && ui.contacts.isNotEmpty()) {
                    Text(
                        ui.error!!.message(), color = NcError, fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                }
                GradientButton(
                    text = stringResource(R.string.create_group),
                    loading = ui.creating,
                    enabled = ui.canCreate || ui.creating,
                    onClick = vm::create,
                )
            }
        }
    }
}

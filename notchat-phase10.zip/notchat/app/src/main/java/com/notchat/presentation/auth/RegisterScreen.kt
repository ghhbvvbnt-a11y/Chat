package com.notchat.presentation.auth

import android.util.Patterns
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AlternateEmail
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MarkEmailRead
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.notchat.R
import com.notchat.core.theme.NcBackground
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.core.util.UsernameError
import com.notchat.core.util.UsernameValidator
import com.notchat.presentation.components.GradientButton
import com.notchat.presentation.components.NcTextField

@Composable
private fun usernameErrorText(error: UsernameError?): String? = when (error) {
    null -> null
    UsernameError.EMPTY -> stringResource(R.string.err_username_empty)
    UsernameError.BAD_START -> stringResource(R.string.err_username_start)
    UsernameError.BAD_CHARS -> stringResource(R.string.err_username_chars)
    UsernameError.TOO_SHORT -> stringResource(R.string.err_username_short)
    UsernameError.TOO_LONG -> stringResource(R.string.err_username_long)
}

@Composable
fun RegisterScreen(
    onBack: () -> Unit,
    onSignedIn: () -> Unit,
    vm: AuthViewModel = hiltViewModel(),
) {
    val ui by vm.ui.collectAsState()
    val usernameStatus by vm.username.collectAsState()
    var email by rememberSaveable { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    var displayName by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(username) { vm.checkUsername(username) }
    LaunchedEffect(ui.event) {
        if (ui.event == AuthEvent.SIGNED_IN) onSignedIn()
    }

    val emailValid = Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
    val usernameIssue = UsernameValidator.validate(username)
    val nameValid = displayName.isNotBlank()
    val passwordValid = password.length >= 8
    val confirmValid = confirm == password

    val takenError =
        if (usernameStatus == UsernameStatus.TAKEN) stringResource(R.string.username_taken) else null
    val usernameHint = when (usernameStatus) {
        UsernameStatus.CHECKING -> stringResource(R.string.username_checking)
        UsernameStatus.AVAILABLE -> stringResource(R.string.username_available)
        UsernameStatus.ERROR -> stringResource(R.string.username_check_failed)
        else -> null
    }
    val emailError = if (submitted && !emailValid) stringResource(R.string.err_email) else null
    val userError = (if (username.isNotEmpty() || submitted) usernameErrorText(usernameIssue) else null) ?: takenError
    val nameError = if (submitted && !nameValid) stringResource(R.string.err_required) else null
    val passError = if (submitted && !passwordValid) stringResource(R.string.err_password_short) else null
    val confirmError = if (submitted && !confirmValid) stringResource(R.string.err_password_mismatch) else null

    Scaffold(containerColor = NcBackground) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).systemBarsPadding().imePadding()) {
            if (ui.event == AuthEvent.CHECK_EMAIL) {
                CheckEmailContent(onBack = onBack)
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        stringResource(R.string.register_title),
                        color = NcTextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start),
                    )
                    Text(
                        stringResource(R.string.register_subtitle),
                        color = NcTextSecondary, fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.Start),
                    )
                    Spacer(Modifier.height(20.dp))
                    NcTextField(
                        value = email, onValueChange = { email = it },
                        label = stringResource(R.string.email),
                        leadingIcon = Icons.Outlined.Email,
                        keyboardType = KeyboardType.Email, error = emailError,
                    )
                    NcTextField(
                        value = username, onValueChange = { username = it.trim() },
                        label = stringResource(R.string.username),
                        leadingIcon = Icons.Outlined.AlternateEmail,
                        error = userError, hint = usernameHint,
                    )
                    NcTextField(
                        value = displayName, onValueChange = { displayName = it },
                        label = stringResource(R.string.display_name),
                        leadingIcon = Icons.Outlined.Badge, error = nameError,
                    )
                    NcTextField(
                        value = password, onValueChange = { password = it },
                        label = stringResource(R.string.password),
                        leadingIcon = Icons.Outlined.Lock, isPassword = true, error = passError,
                    )
                    NcTextField(
                        value = confirm, onValueChange = { confirm = it },
                        label = stringResource(R.string.confirm_password),
                        leadingIcon = Icons.Outlined.Lock, isPassword = true,
                        imeAction = ImeAction.Done, error = confirmError,
                    )
                    ui.error?.let { error ->
                        Spacer(Modifier.height(4.dp))
                        Text(
                            error.message(),
                            color = NcError, fontSize = 13.sp,
                            modifier = Modifier.align(Alignment.Start),
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    GradientButton(
                        text = stringResource(R.string.create_account),
                        loading = ui.loading,
                        onClick = {
                            submitted = true
                            val ok = emailValid && usernameIssue == null &&
                                usernameStatus == UsernameStatus.AVAILABLE &&
                                nameValid && passwordValid && confirmValid
                            if (ok) vm.signUp(email, password, username, displayName)
                        },
                    )
                    TextButton(onClick = onBack) {
                        Text(stringResource(R.string.have_account), color = NcSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckEmailContent(onBack: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            Icons.Outlined.MarkEmailRead, contentDescription = null,
            tint = NcPrimary, modifier = Modifier.height(72.dp),
        )
        Spacer(Modifier.height(16.dp))
        Text(
            stringResource(R.string.check_email_title),
            color = NcTextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.check_email_body),
            color = NcTextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        GradientButton(text = stringResource(R.string.back_to_login), onClick = onBack)
    }
}

package com.notchat.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GroupAdd
import androidx.compose.material.icons.outlined.People
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.notchat.R
import com.notchat.core.theme.NcCard
import com.notchat.core.theme.NcError
import com.notchat.core.theme.NcPrimary
import com.notchat.core.theme.NcSecondary
import com.notchat.core.theme.NcTextPrimary
import com.notchat.core.theme.NcTextSecondary
import com.notchat.presentation.auth.message
import com.notchat.presentation.components.AvatarInitial
import com.notchat.presentation.components.EmptyState
import com.notchat.presentation.components.SearchBarButton

@Composable
fun ContactsTab(
    state: ContactsUiState,
    onOpenProfile: (username: String) -> Unit,
    onNewGroup: () -> Unit,
    onOpenSearch: () -> Unit,
    onRetry: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        SearchBarButton(
            hint = stringResource(R.string.contacts_search_hint),
            onClick = onOpenSearch,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .fillMaxWidth()
                .background(NcCard, RoundedCornerShape(16.dp))
                .clickable(onClick = onNewGroup)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.GroupAdd, contentDescription = null, tint = NcPrimary)
            Spacer(Modifier.width(12.dp))
            Text(
                stringResource(R.string.new_group),
                color = NcTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            )
        }
        Box(Modifier.fillMaxSize()) {
            when {
                state.items.isNotEmpty() -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(state.items, key = { it.id }) { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NcCard, RoundedCornerShape(16.dp))
                                .clickable { onOpenProfile(p.username) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AvatarInitial(p.displayName, size = 48.dp, imageUrl = p.avatarUrl)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    p.displayName,
                                    color = NcTextPrimary, fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold, maxLines = 1,
                                )
                                Text("@${p.username}", color = NcSecondary, fontSize = 13.sp, maxLines = 1)
                            }
                        }
                    }
                }
                state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                    CircularProgressIndicator(color = NcPrimary, modifier = Modifier.padding(top = 48.dp))
                }
                state.error != null -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(state.error.message(), color = NcError, fontSize = 14.sp)
                    TextButton(onClick = onRetry) {
                        Text(stringResource(R.string.retry), color = NcSecondary)
                    }
                }
                else -> EmptyState(
                    icon = Icons.Outlined.People,
                    title = stringResource(R.string.contacts_empty_title),
                    body = stringResource(R.string.contacts_empty_body),
                )
            }
        }
    }
}

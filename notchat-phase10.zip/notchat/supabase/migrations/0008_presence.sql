-- =====================================================================
-- Chatro - Migration 0008: online status / last seen
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent). Requires 0001..0007 first.
--
-- How it works: the app tells the server "I am here" every 30 seconds while it is
-- open. Someone counts as online if that happened in the last 75 seconds.
-- Nobody can read this table directly; everything goes through the functions
-- below, which enforce privacy:
--   * you only see people you share a conversation with
--   * if a person hides their status, you do not see theirs
--   * if YOU hide your status, you do not see anybody else's (same rule as WhatsApp)
-- =====================================================================

create table if not exists public.user_presence (
  user_id        uuid primary key references auth.users (id) on delete cascade,
  last_seen_at   timestamptz not null default now(),
  share_presence boolean not null default true
);

alter table public.user_presence enable row level security;
revoke all on public.user_presence from anon, authenticated;
-- No policies on purpose: clients never read or write this table directly.

-- Heartbeat from the open app.
create or replace function public.touch_presence()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me uuid := (select auth.uid());
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  insert into public.user_presence (user_id, last_seen_at)
  values (v_me, now())
  on conflict (user_id) do update set last_seen_at = now();
end;
$$;

-- "Show my online status" switch.
create or replace function public.set_presence_sharing(p_share boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me uuid := (select auth.uid());
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  insert into public.user_presence (user_id, share_presence)
  values (v_me, coalesce(p_share, true))
  on conflict (user_id) do update set share_presence = coalesce(p_share, true);
end;
$$;

create or replace function public.get_my_presence_sharing()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(
    (select up.share_presence from public.user_presence up where up.user_id = (select auth.uid())),
    true
  );
$$;

-- Presence of one person, or no row when it must stay hidden.
create or replace function public.presence_of(p_user uuid)
returns table (online boolean, last_seen_at timestamptz)
language sql
stable
security definer
set search_path = ''
as $$
  select (up.last_seen_at > now() - interval '75 seconds'), up.last_seen_at
  from public.user_presence up
  where up.user_id = p_user
    and p_user <> (select auth.uid())
    and up.share_presence
    and coalesce(
          (select mine.share_presence from public.user_presence mine
            where mine.user_id = (select auth.uid())),
          true)
    and exists (
          select 1
          from public.conversation_members a
          join public.conversation_members b on b.conversation_id = a.conversation_id
          where a.user_id = (select auth.uid()) and b.user_id = p_user);
$$;

revoke all on function public.touch_presence() from public, anon;
revoke all on function public.set_presence_sharing(boolean) from public, anon;
revoke all on function public.get_my_presence_sharing() from public, anon;
revoke all on function public.presence_of(uuid) from public, anon;
grant execute on function public.touch_presence() to authenticated;
grant execute on function public.set_presence_sharing(boolean) to authenticated;
grant execute on function public.get_my_presence_sharing() to authenticated;
grant execute on function public.presence_of(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- Conversation list: adds the other person's online flag / last seen
-- (return type changes, so the old function is dropped first)
-- ---------------------------------------------------------------------
drop function if exists public.list_conversations();

create function public.list_conversations()
returns table (
  conversation_id uuid,
  conversation_type text,
  title text,
  other_user_id uuid,
  other_username text,
  other_avatar_url text,
  last_message_id uuid,
  last_message_body text,
  last_message_kind text,
  last_message_deleted boolean,
  last_message_sender_id uuid,
  last_message_sender_name text,
  last_message_at timestamptz,
  unread_count bigint,
  muted boolean,
  member_count bigint,
  other_online boolean,
  other_last_seen_at timestamptz
)
language sql
stable
security invoker
set search_path = ''
as $$
  select
    c.id,
    c.type,
    case when c.type = 'group' then c.name else p.display_name end,
    o.user_id,
    p.username,
    p.avatar_url,
    lm.id,
    lm.body,
    lm.kind,
    (lm.deleted_at is not null),
    lm.sender_id,
    sp.display_name,
    coalesce(lm.created_at, c.created_at),
    (select count(*) from public.messages m
       where m.conversation_id = c.id
         and m.sender_id <> me.user_id
         and m.deleted_at is null
         and m.created_at > me.last_read_at),
    me.muted,
    (select count(*) from public.conversation_members x where x.conversation_id = c.id),
    (select pr.online from public.presence_of(o.user_id) pr),
    (select pr.last_seen_at from public.presence_of(o.user_id) pr)
  from public.conversation_members me
  join public.conversations c on c.id = me.conversation_id
  left join public.conversation_members o
    on c.type = 'direct' and o.conversation_id = c.id and o.user_id <> me.user_id
  left join public.profiles p on p.id = o.user_id
  left join lateral (
    select m.* from public.messages m
    where m.conversation_id = c.id
    order by m.created_at desc, m.id desc
    limit 1
  ) lm on true
  left join public.profiles sp on sp.id = lm.sender_id
  where me.user_id = (select auth.uid())
    and (c.type = 'group' or lm.id is not null)
  order by coalesce(lm.created_at, c.created_at) desc;
$$;

revoke all on function public.list_conversations() from public, anon;
grant execute on function public.list_conversations() to authenticated;

-- =====================================================================
-- Quick checks (run separately after the migration):
--   select tablename, rowsecurity from pg_tables
--     where schemaname = 'public' and tablename = 'user_presence';  -- rowsecurity = true
-- =====================================================================

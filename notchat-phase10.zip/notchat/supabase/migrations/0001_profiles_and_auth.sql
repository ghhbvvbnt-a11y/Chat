-- =====================================================================
-- NOT CHAT - Migration 0001: profiles, usernames, RLS, avatars
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Reserved usernames (cannot be registered by users)
-- ---------------------------------------------------------------------
create table if not exists public.reserved_usernames (
  name text primary key check (name = lower(name))
);

insert into public.reserved_usernames (name) values
  ('admin'), ('administrator'), ('support'), ('help'), ('root'), ('system'),
  ('notchat'), ('not_chat'), ('official'), ('security'), ('moderator'),
  ('mod'), ('staff'), ('api'), ('www'), ('null'), ('undefined'), ('me')
on conflict do nothing;

alter table public.reserved_usernames enable row level security;
-- No policies on purpose: clients can never read or write this table directly.
revoke all on public.reserved_usernames from anon, authenticated;

-- ---------------------------------------------------------------------
-- 2) Profiles (one row per auth user). Email is NOT stored here:
--    it stays private inside auth.users.
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  username     text not null,
  display_name text not null,
  avatar_url   text,
  bio          text not null default '',
  country      text,                       -- ISO 3166-1 alpha-2, e.g. 'EG'
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),

  constraint profiles_username_format
    check (username ~ '^[A-Za-z0-9][A-Za-z0-9_]{2,31}$'),
  constraint profiles_display_name_len
    check (char_length(btrim(display_name)) between 1 and 50),
  constraint profiles_bio_len
    check (char_length(bio) <= 200),
  constraint profiles_country_format
    check (country is null or country ~ '^[A-Z]{2}$')
);

-- Case-insensitive uniqueness: @Mohammed and @mohammed are the same user.
create unique index if not exists profiles_username_lower_key
  on public.profiles (lower(username));

-- ---------------------------------------------------------------------
-- 3) Triggers
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

create or replace function public.profiles_block_reserved()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if exists (select 1 from public.reserved_usernames r where r.name = lower(new.username)) then
    raise exception 'username_reserved' using errcode = '23514';
  end if;
  return new;
end;
$$;

drop trigger if exists profiles_block_reserved_trg on public.profiles;
create trigger profiles_block_reserved_trg
  before insert on public.profiles
  for each row execute function public.profiles_block_reserved();

-- Creates the profile automatically when a user signs up.
-- The app passes username / display_name / country in signUp options.data.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_username text := new.raw_user_meta_data ->> 'username';
  v_display  text := coalesce(nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''), v_username);
  v_country  text := nullif(upper(new.raw_user_meta_data ->> 'country'), '');
begin
  insert into public.profiles (id, username, display_name, country)
  values (new.id, v_username, v_display, v_country);
  return new;
end;
$$;

revoke all on function public.handle_new_user() from public, anon, authenticated;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- 4) Row Level Security + grants for profiles
-- ---------------------------------------------------------------------
alter table public.profiles enable row level security;

revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
-- Only these columns can be edited by the user. Username change will come
-- later through a dedicated function; id / created_at are never editable.
grant update (display_name, avatar_url, bio, country) on public.profiles to authenticated;

drop policy if exists "profiles_select_authenticated" on public.profiles;
create policy "profiles_select_authenticated"
  on public.profiles for select
  to authenticated
  using (true);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
  on public.profiles for update
  to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- No INSERT policy (profiles are created by the trigger only)
-- and no DELETE policy (accounts are deleted via delete_my_account()).

-- ---------------------------------------------------------------------
-- 5) Functions called from the app
-- ---------------------------------------------------------------------

-- Live username check on the sign-up screen (before the account exists).
create or replace function public.is_username_available(p_username text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_username ~ '^[A-Za-z0-9][A-Za-z0-9_]{2,31}$'
     and not exists (select 1 from public.profiles p where lower(p.username) = lower(p_username))
     and not exists (select 1 from public.reserved_usernames r where r.name = lower(p_username));
$$;

revoke all on function public.is_username_available(text) from public;
grant execute on function public.is_username_available(text) to anon, authenticated;

-- Permanently deletes the caller's own account (profile cascades).
create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  delete from auth.users where id = (select auth.uid());
end;
$$;

revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- ---------------------------------------------------------------------
-- 6) Avatars storage bucket (2 MB, images only).
--    Files must live under a folder named after the user id:
--    avatars/<user-id>/avatar.jpg
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "avatars_insert_own" on storage.objects;
create policy "avatars_insert_own"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

drop policy if exists "avatars_update_own" on storage.objects;
create policy "avatars_update_own"
  on storage.objects for update
  to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  )
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

drop policy if exists "avatars_delete_own" on storage.objects;
create policy "avatars_delete_own"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

-- =====================================================================
-- Quick checks (run separately after the migration, they change nothing):
--   select public.is_username_available('mohammed123');  -- true
--   select public.is_username_available('admin');        -- false (reserved)
--   select public.is_username_available('_bad');         -- false (format)
--   select tablename, rowsecurity from pg_tables
--     where schemaname = 'public';                       -- rowsecurity = true
-- =====================================================================

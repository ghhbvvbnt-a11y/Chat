-- =====================================================================
-- NOT CHAT - Migration 0002: global user search
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent). Requires 0001 to be applied first.
-- =====================================================================

create extension if not exists pg_trgm with schema extensions;

-- Trigram indexes make "contains" searches fast even with many users.
create index if not exists profiles_username_trgm_idx
  on public.profiles using gin (lower(username) extensions.gin_trgm_ops);
create index if not exists profiles_display_name_trgm_idx
  on public.profiles using gin (lower(display_name) extensions.gin_trgm_ops);

-- Search by @username or display name.
-- SECURITY INVOKER: runs with the caller's rights, so RLS on profiles still applies.
-- Rules: query >= 2 chars, never returns yourself, max 30 rows,
-- ranked: exact username > username starts-with > name starts-with > contains.
-- LIKE wildcards typed by the user (% and _) are escaped.
create or replace function public.search_profiles(p_query text, p_limit int default 20)
returns table (
  id uuid,
  username text,
  display_name text,
  avatar_url text,
  bio text,
  country text
)
language sql
stable
security invoker
set search_path = ''
as $$
  with q as (
    select lower(btrim(regexp_replace(btrim(coalesce(p_query, '')), '^@', ''))) as t
  ),
  esc as (
    select t, replace(replace(replace(t, '\', '\\'), '%', '\%'), '_', '\_') as e from q
  )
  select p.id, p.username, p.display_name, p.avatar_url, p.bio, p.country
  from public.profiles p, esc
  where char_length(esc.t) >= 2
    and p.id <> (select auth.uid())
    and (
      lower(p.username) like '%' || esc.e || '%' escape '\'
      or lower(p.display_name) like '%' || esc.e || '%' escape '\'
    )
  order by
    (lower(p.username) = esc.t) desc,
    (lower(p.username) like esc.e || '%' escape '\') desc,
    (lower(p.display_name) like esc.e || '%' escape '\') desc,
    p.username
  limit least(greatest(coalesce(p_limit, 20), 1), 30);
$$;

revoke all on function public.search_profiles(text, int) from public, anon;
grant execute on function public.search_profiles(text, int) to authenticated;

-- Exact lookup by username (case-insensitive), used by the profile page.
create or replace function public.get_profile_by_username(p_username text)
returns table (
  id uuid,
  username text,
  display_name text,
  avatar_url text,
  bio text,
  country text
)
language sql
stable
security invoker
set search_path = ''
as $$
  select p.id, p.username, p.display_name, p.avatar_url, p.bio, p.country
  from public.profiles p
  where lower(p.username) = lower(p_username)
  limit 1;
$$;

revoke all on function public.get_profile_by_username(text) from public, anon;
grant execute on function public.get_profile_by_username(text) to authenticated;

-- =====================================================================
-- Quick checks (run separately; replace names with real ones):
--   select * from public.search_profiles('moha');
--   select * from public.get_profile_by_username('mohammed123');
-- Note: in the SQL Editor you run as an admin role, so auth.uid() is null
-- and "exclude myself" does not apply there. The app applies it for real.
-- =====================================================================

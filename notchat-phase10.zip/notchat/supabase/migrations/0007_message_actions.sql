-- =====================================================================
-- NOT CHAT - Migration 0007: delete messages, forward messages, mute chats
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent). Requires 0001..0006 first.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Forwarded flag (a forwarded message can never be view-once)
-- ---------------------------------------------------------------------
alter table public.messages
  add column if not exists forwarded boolean not null default false;

alter table public.messages drop constraint if exists messages_forwarded_not_view_once;
alter table public.messages add constraint messages_forwarded_not_view_once
  check (not (forwarded and view_once));

grant insert (forwarded) on public.messages to authenticated;

-- ---------------------------------------------------------------------
-- 2) "Delete for me": a per-user hidden list. The message stays for others.
-- ---------------------------------------------------------------------
create table if not exists public.message_hidden (
  user_id    uuid not null references auth.users (id) on delete cascade,
  message_id uuid not null references public.messages (id) on delete cascade,
  hidden_at  timestamptz not null default now(),
  primary key (user_id, message_id)
);

alter table public.message_hidden enable row level security;
revoke all on public.message_hidden from anon, authenticated;
grant select on public.message_hidden to authenticated;

drop policy if exists "hidden_select_own" on public.message_hidden;
create policy "hidden_select_own"
  on public.message_hidden for select to authenticated
  using (user_id = (select auth.uid()));

-- Hidden messages disappear from every read (history, list preview, unread counts).
drop policy if exists "messages_select_member" on public.messages;
create policy "messages_select_member"
  on public.messages for select to authenticated
  using (
    public.can_read_message(conversation_id, created_at)
    and not exists (
      select 1 from public.message_hidden h
      where h.message_id = messages.id and h.user_id = (select auth.uid())
    )
  );

create or replace function public.hide_message(p_message uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me      uuid := (select auth.uid());
  v_conv    uuid;
  v_created timestamptz;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  select m.conversation_id, m.created_at into v_conv, v_created
    from public.messages m where m.id = p_message;
  if not found or not public.can_read_message(v_conv, v_created) then
    raise exception 'not_found' using errcode = 'P0002';
  end if;
  insert into public.message_hidden (user_id, message_id)
  values (v_me, p_message)
  on conflict do nothing;
end;
$$;

revoke all on function public.hide_message(uuid) from public, anon;
grant execute on function public.hide_message(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 3) "Delete for everyone": only the sender. The text is erased (trigger),
--    attachment rows are removed, and the files to delete are returned so the
--    app can remove them from Storage.
-- ---------------------------------------------------------------------
create or replace function public.delete_message_for_everyone(p_message uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me    uuid := (select auth.uid());
  v_msg   record;
  v_files jsonb;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;

  select m.sender_id, m.deleted_at, m.view_once into v_msg
    from public.messages m where m.id = p_message;
  if not found or v_msg.sender_id <> v_me then
    raise exception 'not_found' using errcode = 'P0002';
  end if;
  if v_msg.deleted_at is not null then
    return '[]'::jsonb;
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
           'bucket', case when v_msg.view_once then 'chat-media-once' else 'chat-media' end,
           'path', a.storage_path)), '[]'::jsonb)
    into v_files
    from public.message_attachments a
   where a.message_id = p_message;

  delete from public.message_attachments where message_id = p_message;
  update public.messages set deleted_at = now() where id = p_message;
  return v_files;
end;
$$;

revoke all on function public.delete_message_for_everyone(uuid) from public, anon;
grant execute on function public.delete_message_for_everyone(uuid) to authenticated;

-- Uploaders may remove their own files (used by delete-for-everyone).
drop policy if exists "chat_media_delete_owner" on storage.objects;
create policy "chat_media_delete_owner"
  on storage.objects for delete to authenticated
  using (bucket_id = 'chat-media' and owner_id = (select auth.uid())::text);

drop policy if exists "once_delete_owner" on storage.objects;
create policy "once_delete_owner"
  on storage.objects for delete to authenticated
  using (bucket_id = 'chat-media-once' and owner_id = (select auth.uid())::text);

-- ---------------------------------------------------------------------
-- 4) Forwarding media: send_media_message learns p_forwarded
-- ---------------------------------------------------------------------
drop function if exists public.send_media_message(uuid, uuid, text, text, jsonb, boolean);

create or replace function public.send_media_message(
  p_conversation uuid,
  p_client_id uuid,
  p_kind text,
  p_body text,
  p_attachment jsonb,
  p_view_once boolean default false,
  p_forwarded boolean default false
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me uuid := (select auth.uid());
  v_id uuid;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if not public.is_conversation_member(p_conversation) then
    raise exception 'not_a_member' using errcode = '42501';
  end if;
  if p_kind not in ('image', 'video', 'audio', 'file') then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if coalesce(p_view_once, false) and p_kind not in ('image', 'video') then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if coalesce(p_view_once, false) and coalesce(p_forwarded, false) then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if (p_attachment ->> 'path') is null
     or (p_attachment ->> 'path') not like p_conversation::text || '/%' then
    raise exception 'invalid_path' using errcode = '22023';
  end if;

  insert into public.messages (conversation_id, sender_id, client_id, kind, body, view_once, forwarded)
  values (p_conversation, v_me, p_client_id, p_kind, coalesce(p_body, ''),
          coalesce(p_view_once, false), coalesce(p_forwarded, false))
  on conflict (sender_id, client_id) do nothing
  returning id into v_id;

  if v_id is null then            -- retry of a send that already succeeded
    select m.id into v_id from public.messages m
     where m.sender_id = v_me and m.client_id = p_client_id;
    return v_id;
  end if;

  insert into public.message_attachments
    (message_id, kind, storage_path, file_name, mime_type, size_bytes, width, height, duration_ms)
  values (
    v_id,
    p_kind,
    p_attachment ->> 'path',
    coalesce(nullif(left(p_attachment ->> 'file_name', 200), ''), 'file'),
    p_attachment ->> 'mime_type',
    coalesce((p_attachment ->> 'size_bytes')::bigint, 0),
    (p_attachment ->> 'width')::int,
    (p_attachment ->> 'height')::int,
    (p_attachment ->> 'duration_ms')::int
  );
  return v_id;
end;
$$;

revoke all on function public.send_media_message(uuid, uuid, text, text, jsonb, boolean, boolean) from public, anon;
grant execute on function public.send_media_message(uuid, uuid, text, text, jsonb, boolean, boolean) to authenticated;

-- ---------------------------------------------------------------------
-- 5) Conversation header now also reports whether I muted the chat
--    (return type changes, so the old function is dropped first)
-- ---------------------------------------------------------------------
drop function if exists public.get_conversation_header(uuid);

create function public.get_conversation_header(p_conversation uuid)
returns table (
  conversation_type text,
  title text,
  other_user_id uuid,
  other_username text,
  other_avatar_url text,
  member_count bigint,
  my_role text,
  muted boolean
)
language sql
stable
security invoker
set search_path = ''
as $$
  select
    c.type,
    case when c.type = 'group' then c.name else op.display_name end,
    o.user_id,
    op.username,
    op.avatar_url,
    (select count(*) from public.conversation_members x where x.conversation_id = c.id),
    me.role,
    me.muted
  from public.conversations c
  join public.conversation_members me
    on me.conversation_id = c.id and me.user_id = (select auth.uid())
  left join public.conversation_members o
    on c.type = 'direct' and o.conversation_id = c.id and o.user_id <> me.user_id
  left join public.profiles op on op.id = o.user_id
  where c.id = p_conversation;
$$;

revoke all on function public.get_conversation_header(uuid) from public, anon;
grant execute on function public.get_conversation_header(uuid) to authenticated;

-- =====================================================================
-- Quick checks (run separately after the migration):
--   select column_name from information_schema.columns
--     where table_name = 'messages' and column_name = 'forwarded';   -- 1 row
--   select tablename, rowsecurity from pg_tables
--     where schemaname = 'public' and tablename = 'message_hidden';  -- rowsecurity = true
-- =====================================================================

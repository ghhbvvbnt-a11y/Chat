-- =====================================================================
-- NOT CHAT - Migration 0005: profile photo rules + "view once" media
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent). Requires 0001..0004 first.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Profile photo: only our own avatar file may be referenced
-- ---------------------------------------------------------------------
alter table public.profiles drop constraint if exists profiles_avatar_url_format;
alter table public.profiles add constraint profiles_avatar_url_format
  check (
    avatar_url is null
    or avatar_url ~ (
      '^https://[a-z0-9.-]+/storage/v1/object/public/avatars/' || id::text || '/avatar\.jpg(\?v=[0-9]+)?$'
    )
  );

-- Replacing a photo is an upsert, which also needs SELECT on the user's own folder.
drop policy if exists "avatars_select_own" on storage.objects;
create policy "avatars_select_own"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

-- ---------------------------------------------------------------------
-- 2) View-once flag on messages (photos and videos only)
-- ---------------------------------------------------------------------
alter table public.messages
  add column if not exists view_once boolean not null default false;

alter table public.messages drop constraint if exists messages_view_once_kind;
alter table public.messages add constraint messages_view_once_kind
  check (not view_once or kind in ('image', 'video'));

-- ---------------------------------------------------------------------
-- 3) Who opened which view-once message (the sender can see "Opened")
-- ---------------------------------------------------------------------
create table if not exists public.message_views (
  message_id       uuid not null references public.messages (id) on delete cascade,
  viewer_id        uuid not null references auth.users (id) on delete cascade,
  viewed_at        timestamptz not null default now(),
  -- short window in which this viewer may fetch the file
  grant_expires_at timestamptz not null,
  primary key (message_id, viewer_id)
);

alter table public.message_views enable row level security;
revoke all on public.message_views from anon, authenticated;
grant select on public.message_views to authenticated;
-- No client writes: rows are created only by open_view_once_message().

drop policy if exists "views_select_viewer_or_sender" on public.message_views;
create policy "views_select_viewer_or_sender"
  on public.message_views for select to authenticated
  using (
    viewer_id = (select auth.uid())
    or exists (
      select 1 from public.messages m
      where m.id = message_id and m.sender_id = (select auth.uid())
    )
  );

-- ---------------------------------------------------------------------
-- 4) Separate private bucket for view-once files.
--    Receivers have NO read access by default: they can only fetch a file
--    during the short window created by open_view_once_message().
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'chat-media-once', 'chat-media-once', false, 26214400,
  array[
    'image/jpeg', 'image/png', 'image/webp', 'image/gif',
    'video/mp4', 'video/quicktime', 'video/3gpp', 'video/webm'
  ]
)
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

create or replace function public.has_view_once_grant(p_name text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.message_attachments a
    join public.message_views v on v.message_id = a.message_id
    where a.storage_path = p_name
      and v.viewer_id = (select auth.uid())
      and v.grant_expires_at > now()
  );
$$;

revoke all on function public.has_view_once_grant(text) from public, anon;
grant execute on function public.has_view_once_grant(text) to authenticated;

drop policy if exists "once_select_owner_or_granted" on storage.objects;
create policy "once_select_owner_or_granted"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'chat-media-once'
    and (
      owner_id = (select auth.uid())::text
      or public.has_view_once_grant(name)
    )
  );

drop policy if exists "once_insert_member" on storage.objects;
create policy "once_insert_member"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'chat-media-once'
    and public.is_conversation_member(public.chat_media_conversation(name))
  );

drop policy if exists "once_update_owner" on storage.objects;
create policy "once_update_owner"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'chat-media-once'
    and owner_id = (select auth.uid())::text
    and public.is_conversation_member(public.chat_media_conversation(name))
  )
  with check (
    bucket_id = 'chat-media-once'
    and owner_id = (select auth.uid())::text
    and public.is_conversation_member(public.chat_media_conversation(name))
  );

-- ---------------------------------------------------------------------
-- 5) send_media_message now accepts p_view_once (old signature removed)
-- ---------------------------------------------------------------------
drop function if exists public.send_media_message(uuid, uuid, text, text, jsonb);

create or replace function public.send_media_message(
  p_conversation uuid,
  p_client_id uuid,
  p_kind text,
  p_body text,
  p_attachment jsonb,
  p_view_once boolean default false
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me uuid := (select auth.uid());
  v_id uuid;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if not public.is_conversation_member(p_conversation) then
    raise exception 'not_a_member' using errcode = '42501';
  end if;
  if p_kind not in ('image', 'video', 'audio', 'file') then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if coalesce(p_view_once, false) and p_kind not in ('image', 'video') then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if (p_attachment ->> 'path') is null
     or (p_attachment ->> 'path') not like p_conversation::text || '/%' then
    raise exception 'invalid_path' using errcode = '22023';
  end if;

  insert into public.messages (conversation_id, sender_id, client_id, kind, body, view_once)
  values (p_conversation, v_me, p_client_id, p_kind, coalesce(p_body, ''), coalesce(p_view_once, false))
  on conflict (sender_id, client_id) do nothing
  returning id into v_id;

  if v_id is null then            -- retry of a send that already succeeded
    select m.id into v_id from public.messages m
     where m.sender_id = v_me and m.client_id = p_client_id;
    return v_id;
  end if;

  insert into public.message_attachments
    (message_id, kind, storage_path, file_name, mime_type, size_bytes, width, height, duration_ms)
  values (
    v_id,
    p_kind,
    p_attachment ->> 'path',
    coalesce(nullif(left(p_attachment ->> 'file_name', 200), ''), 'file'),
    p_attachment ->> 'mime_type',
    coalesce((p_attachment ->> 'size_bytes')::bigint, 0),
    (p_attachment ->> 'width')::int,
    (p_attachment ->> 'height')::int,
    (p_attachment ->> 'duration_ms')::int
  );
  return v_id;
end;
$$;

revoke all on function public.send_media_message(uuid, uuid, text, text, jsonb, boolean) from public, anon;
grant execute on function public.send_media_message(uuid, uuid, text, text, jsonb, boolean) to authenticated;

-- ---------------------------------------------------------------------
-- 6) Opening a view-once message: allowed once per receiver.
--    Re-calling within the 2-minute window returns the same file (so a
--    network hiccup does not burn the view); after that: already_viewed.
-- ---------------------------------------------------------------------
create or replace function public.open_view_once_message(p_message uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me   uuid := (select auth.uid());
  v_msg  record;
  v_att  record;
  v_view record;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;

  select m.conversation_id, m.sender_id, m.view_once, m.deleted_at
    into v_msg
    from public.messages m
   where m.id = p_message;
  if not found or not v_msg.view_once or v_msg.deleted_at is not null
     or not public.is_conversation_member(v_msg.conversation_id) then
    raise exception 'not_found' using errcode = 'P0002';
  end if;
  if v_msg.sender_id = v_me then
    raise exception 'own_message' using errcode = '22023';
  end if;

  select a.storage_path, a.mime_type, a.kind
    into v_att
    from public.message_attachments a
   where a.message_id = p_message
   limit 1;
  if not found then
    raise exception 'not_found' using errcode = 'P0002';
  end if;

  select v.grant_expires_at into v_view
    from public.message_views v
   where v.message_id = p_message and v.viewer_id = v_me;

  if found then
    if v_view.grant_expires_at <= now() then
      raise exception 'already_viewed';
    end if;
  else
    insert into public.message_views (message_id, viewer_id, grant_expires_at)
    values (p_message, v_me, now() + interval '2 minutes');
  end if;

  return jsonb_build_object(
    'path', v_att.storage_path,
    'kind', v_att.kind,
    'mime_type', v_att.mime_type
  );
end;
$$;

revoke all on function public.open_view_once_message(uuid) from public, anon;
grant execute on function public.open_view_once_message(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 7) Realtime: the sender learns instantly that a message was opened
-- ---------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_publication_tables
                 where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'message_views') then
    alter publication supabase_realtime add table public.message_views;
  end if;
end $$;

-- =====================================================================
-- Quick checks (run separately after the migration):
--   select id, public from storage.buckets
--     where id in ('chat-media', 'chat-media-once');   -- both public = false
--   select column_name from information_schema.columns
--     where table_name = 'messages' and column_name = 'view_once';  -- 1 row
--   select tablename from pg_publication_tables
--     where pubname = 'supabase_realtime';   -- includes message_views
-- =====================================================================

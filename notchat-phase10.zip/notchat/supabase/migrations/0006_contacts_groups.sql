-- =====================================================================
-- NOT CHAT - Migration 0006: contacts and group chats
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent). Requires 0001..0005 first.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Contacts (my saved people)
-- ---------------------------------------------------------------------
create table if not exists public.contacts (
  owner_id   uuid not null references auth.users (id) on delete cascade,
  contact_id uuid not null references public.profiles (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (owner_id, contact_id),
  constraint contacts_not_self check (owner_id <> contact_id)
);

alter table public.contacts enable row level security;
revoke all on public.contacts from anon, authenticated;
grant select, delete on public.contacts to authenticated;
grant insert (owner_id, contact_id) on public.contacts to authenticated;

drop policy if exists "contacts_select_own" on public.contacts;
create policy "contacts_select_own"
  on public.contacts for select to authenticated
  using (owner_id = (select auth.uid()));

drop policy if exists "contacts_insert_own" on public.contacts;
create policy "contacts_insert_own"
  on public.contacts for insert to authenticated
  with check (owner_id = (select auth.uid()));

drop policy if exists "contacts_delete_own" on public.contacts;
create policy "contacts_delete_own"
  on public.contacts for delete to authenticated
  using (owner_id = (select auth.uid()));

-- ---------------------------------------------------------------------
-- 2) Groups: columns on conversations and conversation_members
-- ---------------------------------------------------------------------
alter table public.conversations add column if not exists name text;
alter table public.conversations
  add column if not exists created_by uuid references auth.users (id) on delete set null;

alter table public.conversations drop constraint if exists conversations_type_check;
alter table public.conversations add constraint conversations_type_check
  check (type in ('direct', 'group'));

alter table public.conversations drop constraint if exists conversations_group_name;
alter table public.conversations add constraint conversations_group_name
  check (type <> 'group' or (name is not null and char_length(btrim(name)) between 1 and 60));

alter table public.conversation_members
  add column if not exists role text not null default 'member'
  check (role in ('admin', 'member'));

-- ---------------------------------------------------------------------
-- 3) Privacy: a member only sees messages sent after they joined
--    (new group members do not get the old history)
-- ---------------------------------------------------------------------
create or replace function public.can_read_message(p_conversation uuid, p_created_at timestamptz)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.conversation_members m
    where m.conversation_id = p_conversation
      and m.user_id = (select auth.uid())
      and p_created_at >= m.joined_at
  );
$$;

revoke all on function public.can_read_message(uuid, timestamptz) from public, anon;
grant execute on function public.can_read_message(uuid, timestamptz) to authenticated;

drop policy if exists "messages_select_member" on public.messages;
create policy "messages_select_member"
  on public.messages for select to authenticated
  using (public.can_read_message(conversation_id, created_at));

create or replace function public.is_message_visible(p_message uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.messages m
    where m.id = p_message
      and public.can_read_message(m.conversation_id, m.created_at)
  );
$$;

-- ---------------------------------------------------------------------
-- 4) Group administration (all checks happen here, on the server)
-- ---------------------------------------------------------------------
create or replace function public.is_group_admin(p_conversation uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.conversation_members m
    join public.conversations c on c.id = m.conversation_id
    where m.conversation_id = p_conversation
      and m.user_id = (select auth.uid())
      and m.role = 'admin'
      and c.type = 'group'
  );
$$;

revoke all on function public.is_group_admin(uuid) from public, anon;
grant execute on function public.is_group_admin(uuid) to authenticated;

create or replace function public.create_group(p_name text, p_members uuid[])
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me   uuid := (select auth.uid());
  v_name text := btrim(coalesce(p_name, ''));
  v_ids  uuid[];
  v_id   uuid;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if char_length(v_name) not between 1 and 60 then
    raise exception 'invalid_name' using errcode = '22023';
  end if;
  v_ids := array(select distinct u from unnest(p_members) u where u is not null and u <> v_me);
  if coalesce(array_length(v_ids, 1), 0) < 1 then
    raise exception 'no_members' using errcode = '22023';
  end if;
  if array_length(v_ids, 1) > 99 then
    raise exception 'too_many_members' using errcode = '22023';
  end if;
  if exists (select 1 from unnest(v_ids) u
             where not exists (select 1 from public.profiles p where p.id = u)) then
    raise exception 'user_not_found' using errcode = 'P0002';
  end if;

  insert into public.conversations (type, name, created_by)
  values ('group', v_name, v_me)
  returning id into v_id;

  insert into public.conversation_members (conversation_id, user_id, role)
  values (v_id, v_me, 'admin');
  insert into public.conversation_members (conversation_id, user_id)
  select v_id, u from unnest(v_ids) u;

  return v_id;
end;
$$;

create or replace function public.add_group_members(p_conversation uuid, p_members uuid[])
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_ids uuid[];
begin
  if not public.is_group_admin(p_conversation) then
    raise exception 'not_admin' using errcode = '42501';
  end if;
  v_ids := array(select distinct u from unnest(p_members) u where u is not null);
  if (select count(*) from public.conversation_members x where x.conversation_id = p_conversation)
       + coalesce(array_length(v_ids, 1), 0) > 100 then
    raise exception 'too_many_members' using errcode = '22023';
  end if;
  if exists (select 1 from unnest(v_ids) u
             where not exists (select 1 from public.profiles p where p.id = u)) then
    raise exception 'user_not_found' using errcode = 'P0002';
  end if;
  insert into public.conversation_members (conversation_id, user_id)
  select p_conversation, u from unnest(v_ids) u
  on conflict do nothing;
end;
$$;

create or replace function public.remove_group_member(p_conversation uuid, p_user uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_group_admin(p_conversation) then
    raise exception 'not_admin' using errcode = '42501';
  end if;
  if p_user = (select auth.uid()) then
    raise exception 'use_leave_group' using errcode = '22023';
  end if;
  delete from public.conversation_members
   where conversation_id = p_conversation and user_id = p_user;
end;
$$;

create or replace function public.leave_group(p_conversation uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me uuid := (select auth.uid());
  v_remaining int;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if not exists (
    select 1 from public.conversations c
    join public.conversation_members m on m.conversation_id = c.id
    where c.id = p_conversation and c.type = 'group' and m.user_id = v_me
  ) then
    raise exception 'not_found' using errcode = 'P0002';
  end if;

  delete from public.conversation_members
   where conversation_id = p_conversation and user_id = v_me;

  select count(*) into v_remaining
    from public.conversation_members where conversation_id = p_conversation;

  if v_remaining = 0 then
    delete from public.conversations where id = p_conversation;
  elsif not exists (select 1 from public.conversation_members
                    where conversation_id = p_conversation and role = 'admin') then
    -- the longest-standing member becomes admin
    update public.conversation_members
       set role = 'admin'
     where conversation_id = p_conversation
       and user_id = (select x.user_id from public.conversation_members x
                      where x.conversation_id = p_conversation
                      order by x.joined_at, x.user_id limit 1);
  end if;
end;
$$;

create or replace function public.rename_group(p_conversation uuid, p_name text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_name text := btrim(coalesce(p_name, ''));
begin
  if not public.is_group_admin(p_conversation) then
    raise exception 'not_admin' using errcode = '42501';
  end if;
  if char_length(v_name) not between 1 and 60 then
    raise exception 'invalid_name' using errcode = '22023';
  end if;
  update public.conversations set name = v_name where id = p_conversation;
end;
$$;

revoke all on function public.create_group(text, uuid[]) from public, anon;
revoke all on function public.add_group_members(uuid, uuid[]) from public, anon;
revoke all on function public.remove_group_member(uuid, uuid) from public, anon;
revoke all on function public.leave_group(uuid) from public, anon;
revoke all on function public.rename_group(uuid, text) from public, anon;
grant execute on function public.create_group(text, uuid[]) to authenticated;
grant execute on function public.add_group_members(uuid, uuid[]) to authenticated;
grant execute on function public.remove_group_member(uuid, uuid) to authenticated;
grant execute on function public.leave_group(uuid) to authenticated;
grant execute on function public.rename_group(uuid, text) to authenticated;

-- ---------------------------------------------------------------------
-- 5) Read helpers (SECURITY INVOKER: row level security still applies)
-- ---------------------------------------------------------------------
create or replace function public.list_conversation_members(p_conversation uuid)
returns table (
  user_id uuid,
  username text,
  display_name text,
  avatar_url text,
  role text,
  joined_at timestamptz
)
language sql
stable
security invoker
set search_path = ''
as $$
  select m.user_id, p.username, p.display_name, p.avatar_url, m.role, m.joined_at
  from public.conversation_members m
  join public.profiles p on p.id = m.user_id
  where m.conversation_id = p_conversation
  order by (m.role = 'admin') desc, lower(p.display_name);
$$;

create or replace function public.get_conversation_header(p_conversation uuid)
returns table (
  conversation_type text,
  title text,
  other_user_id uuid,
  other_username text,
  other_avatar_url text,
  member_count bigint,
  my_role text
)
language sql
stable
security invoker
set search_path = ''
as $$
  select
    c.type,
    case when c.type = 'group' then c.name else op.display_name end,
    o.user_id,
    op.username,
    op.avatar_url,
    (select count(*) from public.conversation_members x where x.conversation_id = c.id),
    me.role
  from public.conversations c
  join public.conversation_members me
    on me.conversation_id = c.id and me.user_id = (select auth.uid())
  left join public.conversation_members o
    on c.type = 'direct' and o.conversation_id = c.id and o.user_id <> me.user_id
  left join public.profiles op on op.id = o.user_id
  where c.id = p_conversation;
$$;

revoke all on function public.list_conversation_members(uuid) from public, anon;
revoke all on function public.get_conversation_header(uuid) from public, anon;
grant execute on function public.list_conversation_members(uuid) to authenticated;
grant execute on function public.get_conversation_header(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 6) Conversation list now covers groups too (return type changes,
--    so the previous function is dropped first)
-- ---------------------------------------------------------------------
drop function if exists public.list_conversations();

create function public.list_conversations()
returns table (
  conversation_id uuid,
  conversation_type text,
  title text,
  other_user_id uuid,
  other_username text,
  other_avatar_url text,
  last_message_id uuid,
  last_message_body text,
  last_message_kind text,
  last_message_deleted boolean,
  last_message_sender_id uuid,
  last_message_sender_name text,
  last_message_at timestamptz,
  unread_count bigint,
  muted boolean,
  member_count bigint
)
language sql
stable
security invoker
set search_path = ''
as $$
  select
    c.id,
    c.type,
    case when c.type = 'group' then c.name else p.display_name end,
    o.user_id,
    p.username,
    p.avatar_url,
    lm.id,
    lm.body,
    lm.kind,
    (lm.deleted_at is not null),
    lm.sender_id,
    sp.display_name,
    coalesce(lm.created_at, c.created_at),
    (select count(*) from public.messages m
       where m.conversation_id = c.id
         and m.sender_id <> me.user_id
         and m.deleted_at is null
         and m.created_at > me.last_read_at),
    me.muted,
    (select count(*) from public.conversation_members x where x.conversation_id = c.id)
  from public.conversation_members me
  join public.conversations c on c.id = me.conversation_id
  left join public.conversation_members o
    on c.type = 'direct' and o.conversation_id = c.id and o.user_id <> me.user_id
  left join public.profiles p on p.id = o.user_id
  left join lateral (
    select m.* from public.messages m
    where m.conversation_id = c.id
    order by m.created_at desc, m.id desc
    limit 1
  ) lm on true
  left join public.profiles sp on sp.id = lm.sender_id
  where me.user_id = (select auth.uid())
    and (c.type = 'group' or lm.id is not null)
  order by coalesce(lm.created_at, c.created_at) desc;
$$;

revoke all on function public.list_conversations() from public, anon;
grant execute on function public.list_conversations() to authenticated;

-- =====================================================================
-- Quick checks (run separately after the migration):
--   select tablename, rowsecurity from pg_tables
--     where schemaname = 'public' and tablename = 'contacts';  -- rowsecurity = true
--   select column_name from information_schema.columns
--     where table_name = 'conversation_members' and column_name = 'role';  -- 1 row
-- =====================================================================

-- =====================================================================
-- NOT CHAT - Migration 0004: media messages (images, video, voice, files)
-- Run in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run
-- Safe to re-run (idempotent). Requires 0001..0003 first.
--
-- Files live in a PRIVATE bucket. Only members of a conversation can read or
-- upload files under that conversation's folder: <conversation_id>/<message_client_id>/file.ext
-- The app reads files through short-lived signed URLs.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) messages.kind + relaxed body rule (media messages may have no text)
-- ---------------------------------------------------------------------
alter table public.messages
  add column if not exists kind text not null default 'text'
  check (kind in ('text', 'image', 'video', 'audio', 'file'));

alter table public.messages drop constraint if exists messages_body_len;
alter table public.messages add constraint messages_body_len
  check (
    char_length(body) <= 4000
    and (deleted_at is not null or kind <> 'text' or char_length(btrim(body)) >= 1)
  );

-- ---------------------------------------------------------------------
-- 2) Attachments
-- ---------------------------------------------------------------------
create table if not exists public.message_attachments (
  id           uuid primary key default gen_random_uuid(),
  message_id   uuid not null references public.messages (id) on delete cascade,
  kind         text not null check (kind in ('image', 'video', 'audio', 'file')),
  storage_path text not null unique,
  file_name    text not null default 'file',
  mime_type    text not null,
  size_bytes   bigint not null check (size_bytes >= 0 and size_bytes <= 26214400),
  width        int,
  height       int,
  duration_ms  int,
  created_at   timestamptz not null default now()
);
create index if not exists message_attachments_message_idx
  on public.message_attachments (message_id);

create or replace function public.is_message_visible(p_message uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.messages m
    where m.id = p_message
      and public.is_conversation_member(m.conversation_id)
  );
$$;

revoke all on function public.is_message_visible(uuid) from public, anon;
grant execute on function public.is_message_visible(uuid) to authenticated;

alter table public.message_attachments enable row level security;
revoke all on public.message_attachments from anon, authenticated;
grant select on public.message_attachments to authenticated;
-- No insert/update/delete for clients: rows are created only by send_media_message().

drop policy if exists "attachments_select_visible" on public.message_attachments;
create policy "attachments_select_visible"
  on public.message_attachments for select to authenticated
  using (public.is_message_visible(message_id));

-- ---------------------------------------------------------------------
-- 3) Atomic "message + attachment" insert (idempotent per client_id)
-- ---------------------------------------------------------------------
create or replace function public.send_media_message(
  p_conversation uuid,
  p_client_id uuid,
  p_kind text,
  p_body text,
  p_attachment jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_me uuid := (select auth.uid());
  v_id uuid;
begin
  if v_me is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if not public.is_conversation_member(p_conversation) then
    raise exception 'not_a_member' using errcode = '42501';
  end if;
  if p_kind not in ('image', 'video', 'audio', 'file') then
    raise exception 'invalid_kind' using errcode = '22023';
  end if;
  if (p_attachment ->> 'path') is null
     or (p_attachment ->> 'path') not like p_conversation::text || '/%' then
    raise exception 'invalid_path' using errcode = '22023';
  end if;

  insert into public.messages (conversation_id, sender_id, client_id, kind, body)
  values (p_conversation, v_me, p_client_id, p_kind, coalesce(p_body, ''))
  on conflict (sender_id, client_id) do nothing
  returning id into v_id;

  if v_id is null then            -- retry of a send that already succeeded
    select m.id into v_id from public.messages m
     where m.sender_id = v_me and m.client_id = p_client_id;
    return v_id;
  end if;

  insert into public.message_attachments
    (message_id, kind, storage_path, file_name, mime_type, size_bytes, width, height, duration_ms)
  values (
    v_id,
    p_kind,
    p_attachment ->> 'path',
    coalesce(nullif(left(p_attachment ->> 'file_name', 200), ''), 'file'),
    p_attachment ->> 'mime_type',
    coalesce((p_attachment ->> 'size_bytes')::bigint, 0),
    (p_attachment ->> 'width')::int,
    (p_attachment ->> 'height')::int,
    (p_attachment ->> 'duration_ms')::int
  );
  return v_id;
end;
$$;

revoke all on function public.send_media_message(uuid, uuid, text, text, jsonb) from public, anon;
grant execute on function public.send_media_message(uuid, uuid, text, text, jsonb) to authenticated;

-- ---------------------------------------------------------------------
-- 4) Conversation list now also reports the last message kind
--    (return type changes, so the old function is dropped first)
-- ---------------------------------------------------------------------
drop function if exists public.list_conversations();

create function public.list_conversations()
returns table (
  conversation_id uuid,
  other_user_id uuid,
  other_username text,
  other_display_name text,
  other_avatar_url text,
  last_message_id uuid,
  last_message_body text,
  last_message_kind text,
  last_message_deleted boolean,
  last_message_sender_id uuid,
  last_message_at timestamptz,
  unread_count bigint,
  muted boolean
)
language sql
stable
security invoker
set search_path = ''
as $$
  select
    c.id,
    o.user_id,
    p.username,
    p.display_name,
    p.avatar_url,
    lm.id,
    lm.body,
    lm.kind,
    (lm.deleted_at is not null),
    lm.sender_id,
    lm.created_at,
    (select count(*) from public.messages m
       where m.conversation_id = c.id
         and m.sender_id <> me.user_id
         and m.deleted_at is null
         and m.created_at > me.last_read_at),
    me.muted
  from public.conversation_members me
  join public.conversations c on c.id = me.conversation_id
  join public.conversation_members o
    on o.conversation_id = c.id and o.user_id <> me.user_id
  join public.profiles p on p.id = o.user_id
  join lateral (
    select m.* from public.messages m
    where m.conversation_id = c.id
    order by m.created_at desc, m.id desc
    limit 1
  ) lm on true
  where me.user_id = (select auth.uid())
  order by lm.created_at desc;
$$;

revoke all on function public.list_conversations() from public, anon;
grant execute on function public.list_conversations() to authenticated;

-- ---------------------------------------------------------------------
-- 5) Private storage bucket + policies (25 MB per file, allowed types only)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'chat-media', 'chat-media', false, 26214400,
  array[
    'image/jpeg', 'image/png', 'image/webp', 'image/gif',
    'video/mp4', 'video/quicktime', 'video/3gpp', 'video/webm',
    'audio/mp4', 'audio/aac', 'audio/mpeg', 'audio/ogg', 'audio/webm',
    'application/pdf', 'text/plain', 'text/csv', 'application/zip',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  ]
)
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- First path segment must be the conversation id (uuid), else NULL.
create or replace function public.chat_media_conversation(p_name text)
returns uuid
language sql
immutable
set search_path = ''
as $$
  select case
    when (storage.foldername(p_name))[1]
         ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    then ((storage.foldername(p_name))[1])::uuid
    else null
  end;
$$;

revoke all on function public.chat_media_conversation(text) from public, anon;
grant execute on function public.chat_media_conversation(text) to authenticated;

drop policy if exists "chat_media_select_member" on storage.objects;
create policy "chat_media_select_member"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'chat-media'
    and public.is_conversation_member(public.chat_media_conversation(name))
  );

drop policy if exists "chat_media_insert_member" on storage.objects;
create policy "chat_media_insert_member"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'chat-media'
    and public.is_conversation_member(public.chat_media_conversation(name))
  );

-- Re-uploading the same path (retry) must be allowed, but only for the uploader.
drop policy if exists "chat_media_update_owner" on storage.objects;
create policy "chat_media_update_owner"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'chat-media'
    and owner_id = (select auth.uid())::text
    and public.is_conversation_member(public.chat_media_conversation(name))
  )
  with check (
    bucket_id = 'chat-media'
    and owner_id = (select auth.uid())::text
    and public.is_conversation_member(public.chat_media_conversation(name))
  );

-- =====================================================================
-- Quick checks (run separately after the migration):
--   select id, public, file_size_limit from storage.buckets
--     where id = 'chat-media';                      -- public = false
--   select column_name from information_schema.columns
--     where table_name = 'messages' and column_name = 'kind';   -- 1 row
-- =====================================================================
